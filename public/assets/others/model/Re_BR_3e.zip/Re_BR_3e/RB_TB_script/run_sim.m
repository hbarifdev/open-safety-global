%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% run_sim.m     v3.1e
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov 
% 12 March 2008
%
% runs the RB_TB.mdl from "param.t_Initial" to "param.t_Final" time 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

function param = run_sim(param,handles,sim_state); 
global alarm pause_knob_state

if ~(get(handles.DepthInputManual,'Value') == 1 && get(handles.In_rate,'Value') == 1)
    % show depth_Final in GUI 
    NewVal = round(600*(param.depth_Final-param.depth_Initial)/(param.t_Final-param.t_Initial))/10;
    set(handles.RateAsc,'String',NewVal)
end

sim_loops = (param.t_Final - param.t_Initial)/0.1;
if sim_loops > 3000 % more than the max dive time
    set(handles.ModelTxtPanel,'String', ['>> Please wait. Simulating ' num2str(sim_loops) ' steps'])    
end  

if param.t_Final > 35999    % more than the max dive time
    param.t_Final = 35999; 
    sim_state = 'pause';
    param.ModelTxtPanel = '>> PAUSE. Final time is more than the max dive time of the handset';    
else 
    record_depth = get(handles.record_depth,'Value');
    if param.t_Initial == 0 &&  record_depth == 1
        param.record.depth = [param.depth_Initial];
        param.record.depth_time = [0];
    end   
    t = [param.t_Initial; param.t_Final];  
    set_param('RB_TB/disp_clock', 'Value', num2str(param.t_Final)) 
    
    % display individual PPO2 values
    PPO2_num = param.t_Initial - 6*floor(param.t_Initial/6) + 1;
    set_param('RB_TB/Controller/PPO2_switch', 'Value', num2str(PPO2_num))
    
    % even or odd clock: 0 or 1. to flash display
    clock = round(rem(param.t_Initial/2,1));
    delta_time = param.t_Final - param.t_Initial;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % run simulink model
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%

    sim('RB_TB', [param.t_Initial, param.t_Final], simset('InitialState', param.xInitial), [t, param.u]) 

    if strcmp(pause_knob_state, 'pressed')
        set(handles.ModelTxtPanel,'String', ['>> PAUSE']);
        set(handles.PauseButton, 'BackgroundColor', [0.9608 0.9569 0.9529])        
    end    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    % save sim output
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    param.t_Initial = param.t_Final;       
    param.xInitial = xFinal;   
    param.depth_Initial = param.depth_Final;
    param.yout = yout;

    %--------------------------
    % accumulating plot data
    %--------------------------
    if record_depth == 1
        param.record.depth = [param.record.depth param.depth_Final];
        param.record.depth_time = [param.record.depth_time param.t_Final];
    end 
    %-------------------------- 
    % MatLAB GUI output
    %--------------------------
    set(handles.cnc_O2, 'String', num2str(round(10000*cnc_O2(1,2))/100))
    set(handles.cnc_CO2, 'String', num2str(round(10000*cnc_CO2(1,2))/100))
    set(handles.cnc_N2, 'String', num2str(round(10000*cnc_N2(1,2))/100))
    set(handles.cnc_He, 'String', num2str(round(10000*cnc_He(1,2))/100))
    set(handles.cnc_res, 'String', num2str(round(10000*cnc_res(1,2))/100)) 
    cnc_total = cnc_O2 + cnc_CO2 + cnc_N2 + cnc_He + cnc_res;    
    set(handles.cnc_total, 'String', num2str(round(1000*cnc_total(1,2))/10))    
    set(handles.pr_BL, 'String', num2str(round(100*pr_BL(1,2))/100))
    
    param.discharge_bat = discharge_bat(1,2); % used for Fault of battery 
    param.sum_CO2 = sum_CO2(1,2); % used for Fault of Scrubber Exhausted     

    if ~(get(handles.DepthInputManual,'Value') == 1 && get(handles.In_depth,'Value') == 1)
        % show depth_Final in GUI 
        if strcmp(param.units, 'imperial')
            param.depth_Final = param.depth_Final/0.3048;
        end
        
        NewVal = round(10*param.depth_Final)/10;
        set(handles.Depth,'String',NewVal) 
    end

    if strcmp(sim_state,'pause') 
        rt_timer = timerfind;
        if strcmp(get(rt_timer, 'Running'),'on')
            stop(rt_timer);   
        end    
        set(handles.ModelTxtPanel,'String', [param.ModelTxtPanel])
        set(handles.RunButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
        set(handles.PauseButton, 'BackgroundColor', [0.9608 0.9569 0.9529])
        % sound
        wavplay(param.DING_sound.y,param.DING_sound.Fs)
    end  

    size_yout = size(yout,1);

    NewVal = yout(size_yout,1);           % T.T.S
    if get(handles.plot_TTS,'Value') == 1
        param.record.TTS = [param.record.TTS NewVal];
        param.record.TTS_time = [param.record.TTS_time param.t_Final];
    end 
    NewVal = round(NewVal);
    TTS = NewVal;
    time_s = sec2hms(NewVal);
    str_time = time2str(time_s,'24','hms','hms'); 
    time_d = str2num([str_time(1) str_time(2) str_time(4) str_time(5) str_time(7) str_time(8)]);
    disp_val(time_d, 0, 959, 'T.T.S', 3, 3, handles, clock);

    NewVal = yout(size_yout,2);           % CEILING TIME
    if get(handles.plot_ceil_t,'Value') == 1
        param.record.ceil_t = [param.record.ceil_t NewVal];
        param.record.ceil_t_time = [param.record.ceil_t_time param.t_Final];
    end 
    NewVal = round(NewVal);    
    time_s = sec2hms(NewVal);
    str_time = time2str(time_s,'24','hms','hms'); 
    time_d = str2num([str_time(1) str_time(2) str_time(4) str_time(5) str_time(7) str_time(8)]);
    disp_val(time_d, 0, 95959, 'CEILING TIME', 5, 8, handles, clock);  

    depth = yout(size_yout,4);           % DEPTH m/f
    NewVal = round(depth);
    disp_val(NewVal, 0, 600, 'DEPTH', 3, 14, handles, clock); 
    
       NewVal = yout(size_yout,3);           % CEILING  m/ft
    if NewVal > depth
        param.DCS = param.DCS + delta_time; % DeCompression Sickness (DCS)
    end 
    if get(handles.plot_ceil_d,'Value') == 1
        param.record.ceil_d = [param.record.ceil_d NewVal];
        param.record.ceil_d_time = [param.record.ceil_d_time param.t_Final];
    end
    NewVal = round(NewVal);
    if param.DCS > 1200 % 20 minutes
        disp_val(NewVal, 0, 0, 'CEILING', 3, 11, handles, clock);    
    else
        disp_val(NewVal, 0, 600, 'CEILING', 3, 11, handles, clock);
    end
 
    NewVal = round(yout(size_yout,5));           % DIVE TIME    
    % translate seconds into the HH:MM:SS
    time_s = sec2hms(NewVal);
    str_time = time2str(time_s,'24','hms','hms'); 
    time_d = str2num([str_time(1) str_time(2) str_time(4) str_time(5) str_time(7) str_time(8)]);
    disp_val(time_d, 0, 95959, 'DIVE TIME', 5, 19, handles, clock);

    NewVal = yout(size_yout,6);           % CNS, %
    if get(handles.plot_CNS,'Value') == 1
        param.record.CNS = [param.record.CNS NewVal];
        param.record.CNS_time = [param.record.CNS_time param.t_Final];
    end 
    NewVal = round(NewVal);
    disp_val(NewVal, 0, 100, 'CNS', 2, 21, handles, clock);

    NewVal = round(yout(size_yout,7));           % ASC RATE,  m/min   ft/min
    if NewVal > 0 
        set(handles.SignAscRate, 'String', '+');         
    elseif NewVal == 0     
        set(handles.SignAscRate, 'String', '');       
    else            
        set(handles.SignAscRate, 'String', '-');
    end   
    disp_val(NewVal, -100, 100, 'ASC RATE', 2, 23, handles, clock);    

    NewVal = yout(size_yout,8);           % O2, %
    if get(handles.plot_FO2,'Value') == 1
        param.record.cnc_O2 = [param.record.cnc_O2 NewVal];
        param.record.cnc_O2_time = [param.record.cnc_O2_time param.t_Final];
    end 
    NewVal = round(NewVal);
    disp_val(NewVal, 0, 100, 'O2', 2, 25, handles, clock);

    NewVal = yout(size_yout,9);           % He, %
    if get(handles.plot_FHe,'Value') == 1
        param.record.cnc_He = [param.record.cnc_He NewVal];
        param.record.cnc_He_time = [param.record.cnc_He_time param.t_Final];
    end 
    NewVal = round(NewVal);    
    disp_val(NewVal, 0, 100, 'He', 2, 27, handles, clock);

    NewVal = yout(size_yout,10);          % N2, %
    if get(handles.plot_FN2,'Value') == 1
        param.record.cnc_N2 = [param.record.cnc_N2 NewVal];
        param.record.cnc_N2_time = [param.record.cnc_N2_time param.t_Final];
    end 
    NewVal = round(NewVal);    
    disp_val(NewVal, 0, 100, 'N2', 2, 29, handles, clock);
    
    NewVal = yout(size_yout,11);          % SCRB, %
    if NewVal == 100
        NewVal = 99;
    end
    NewVal = round(NewVal);    
    disp_val(NewVal, 0, 100, 'SCRB', 2, 31, handles, clock);

    NewVal = yout(size_yout,12);          % BAT
    if NewVal == 100
        NewVal = 99;
    end
    NewVal = round(NewVal);    
    disp_val(NewVal, 10, 100, 'BAT', 2, 33, handles, clock);

    NewVal = yout(size_yout,13);          % HUM, %
    if get(handles.plot_hum,'Value') == 1
        param.record.hum = [param.record.hum NewVal];
        param.record.hum_time = [param.record.hum_time param.t_Final];
    end 
    NewVal = round(NewVal);    
    disp_val(NewVal, 0, 100, 'HUM', 2, 35, handles, clock);

    NewVal = yout(size_yout,14);          % TEMP, C/F
    if get(handles.plot_temp,'Value') == 1
        param.record.temp = [param.record.temp NewVal];
        param.record.temp_time = [param.record.temp_time param.t_Final];
    end 
    NewVal = round(NewVal);    
    disp_val(NewVal, 0, 100, 'TEMP', 2, 37, handles, clock);

    % PPO2 display
    NewVal = 100*yout(size_yout,15);      % 123PPO2        
    if PPO2_num < 5
        set(handles.PPO2_num,'String', ['PPO2  S' num2str(PPO2_num)])
    else
        set(handles.PPO2_num,'String', ['PPO2 Average'])
        if NewVal < 0.1
            set(handles.rate_met,'String','0')
            set_param('RB_TB/Breathing/rate_metabolic', 'Amplitude', '0')            
        end
    end
    if get(handles.plot_PPO2,'Value') == 1
        param.record.PPO2 = [param.record.PPO2 NewVal];
        param.record.PPO2_time = [param.record.PPO2_time param.t_Final];
    end 
    NewVal = round(NewVal);    
    disp_val(NewVal, 20, 160, '123PPO2', 3, 40, handles, clock);
    if ~(NewVal > 20)
        red_val = 1;
        green_val = 0;
    end
    if NewVal > 20 && NewVal < 100
        red_val = 1;
        green_val = (NewVal - 20)/80;
    end
    if ~(NewVal < 100) && NewVal < 160
        red_val = 1 - (NewVal - 100)/60;
        green_val = 1;
    end
    if ~(NewVal < 160)
        red_val = 0;
        green_val = 1;
    end    
    set(handles.LED_O2, 'BackgroundColor', [red_val green_val 0]) % GUI PPO2 LCD

    NewVal = 100*yout(size_yout,16);      % PPCO2
    if get(handles.plot_PPCO2,'Value') == 1
        param.record.PPCO2 = [param.record.PPCO2 NewVal];
        param.record.PPCO2_time = [param.record.PPCO2_time param.t_Final];
    end 
    NewVal = round(NewVal);    
    disp_val(NewVal, 0, 4, 'PPCO2', 2, 42, handles, clock);
    if ~(NewVal > 1)
        red_val = 0;
        green_val = 1;
    end
    if NewVal > 1 && NewVal < 3
        red_val = (NewVal - 1)/2;
        green_val = 1;
    end
    if ~(NewVal < 3) && NewVal < 10
        red_val = 1;
        green_val = 1 - (NewVal - 3)/7;
    end
    if ~(NewVal < 10)
        red_val = 1;
        green_val = 0;
    end    
    set(handles.LED_CO2, 'BackgroundColor', [red_val green_val 0]) % GUI PPCO2 LCD

    NewVal = yout(size_yout,17);          % EqND, m/ft
    if get(handles.plot_EqN,'Value') == 1
        param.record.EqN = [param.record.EqN NewVal];
        param.record.EqN_time = [param.record.EqN_time param.t_Final];
    end 
    NewVal = round(NewVal);    
    disp_val(NewVal, 0, 1000, 'EqND', 3, 45, handles, clock);

    NewVal = round(yout(size_yout,18));          % DIL CILINDER, BPASRI 
    if strcmp(param.units, 'metric') 
        limit = 20;
    else
        limit = 2;
    end
    disp_val(NewVal, limit, 1200, 'DIL CILINDER', 4, 49, handles, clock);
    
    NewVal = round(yout(size_yout,19));          % O2 CILINDER, BPASRI
    disp_val(NewVal, limit, 1200, 'O2 CILINDER', 4, 53, handles, clock);
    
    NewVal = yout(size_yout,20);                % BL size, litre
    if get(handles.plot_BL_size,'Value') == 1
        param.record.BL_size = [param.record.BL_size NewVal];
        param.record.BL_size_time = [param.record.BL_size_time param.t_Final];
    end     
       
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %        ALARMS:
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    if TTS > round(O2_bottle_time_life(1,2))
        if alarm.NoReturn == 0
            alarm.NoReturn = 1;
            if isempty(findstr(alarm.message_up,'Beyond Point of NoReturn'))            
                alarm.message_up   = [alarm.message_up   'Beyond Point of No Return' '    Turn Back Now       '];
                alarm.message_down = [alarm.message_down 'O2 empty before surface ' '                        '];
                set(handles.txtPanel1,'String', ['     Turn Back Now      ']);
                set(handles.txtPanel2,'String', ['                        ']);
            end
        end
    end     
    if CNS_setPPO2_control(1,2) < 0.5
        if alarm.CNS == 0
            alarm.CNS = 1;
            if isempty(findstr(alarm.message_up,'Adding an air break'))
                alarm.message_up   = [alarm.message_up   '  Adding an air break   '];
                alarm.message_down = [alarm.message_down '                        '];
                set(handles.txtPanel1,'String', ['  Adding an air break   ']);
                set(handles.txtPanel2,'String', ['                        ']);
            end
        end
    else
        alarm.CNS = 0;
    end
    
end   



% end of run_sim.m