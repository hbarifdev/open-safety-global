load('prof_91_840.mat');

n_time(1) = 0; 
n_depth(1) = 0;
a = size(profile.time,2);

for i = 1:a
    n_time(1+i) = profile.time(i)+30;
    n_depth(1+i) = profile.depth(i);
end 
profile.time = n_time;
profile.depth = n_depth;

%save('prof_91_840.mat', 'profile');
