%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% do_mode.m     v2.0 Beta A
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov 
% 28 January 2006
%
% run by GUI_Re_Br.m 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function do_mode
global param GUIparams sim_state

%tim_start = clock;       % bob tmp

handles = GUIparams;  

if param.t_Initial <= 0   
    param.xInitial(1:70) = 0;  %param.xInitial = [];   % The default of xInitial an empty matrix 
    param.depth_Initial = str2num(get(handles.Depth,'String'));
    param.yout = [];
    if ~(get(handles.DepthInputManual,'Value') == 1)
        param.depth_Initial = 0;
    end   
end

% profile mode
if get(handles.DepthInputProfile,'Value') == 1 
    [param,model_sim,sim_state] = do_profile(param,handles,sim_state);
    if strcmp(model_sim,'on')
        param = run_sim(param,handles,sim_state);        
    end
end

% manual mode 
if get(handles.DepthInputManual,'Value') == 1
    [param,model_sim,sim_state] = do_manual(param,handles,sim_state);
    if strcmp(model_sim,'on')
        param = run_sim(param,handles,sim_state);  
    end
end

% deco mode
if get(handles.DepthInputDeco,'Value') == 1
    [param,model_sim,sim_state] = do_deco(param,handles,sim_state);
    if strcmp(model_sim,'on')
        param = run_sim(param,handles,sim_state);
    end            
end




GUIparams = handles;


%tim_end = clock;       % bob tmp
%d_t = tim_end(6) - tim_start(6)    % bob tmp


%end of run_model

