%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% do_left_button.m     v3.1d
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov
% 18 December 2006
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function do_left_button(handles)
global sim_state param option

if ~strcmp(sim_state,'pause') && ~strcmp(sim_state,'run')
    switch param.scroll_cnt_opt
        case 2 
            if ~strcmp(param.predive,'on')
                param.predive = 'on';
                set(handles.txtPanel1,'String', ['Turn OFF DIL and O2 ON! '])  
                set(handles.txtPanel2,'String', ['                 Done ->'])  
            end
            if param.predive_num == 7
                set(handles.txtPanel1,'String', ['                        '])  
                set(handles.txtPanel2,'String', ['                        '])                      
            end
        case 6
            param.setPPO2 = param.setPPO2 + 0.1;
            if param.setPPO2 > 1.3001
                param.setPPO2 = 0.7;
            end
            option.setPPO2 = param.setPPO2;
            save(['../RB_TB_script/' 'RB_option' '.mat'], 'option'); 
            
            set(handles.txtPanel1,'String', ['PPO2 Setpoint = ' num2str(param.setPPO2)]) %             
            set_param('RB_TB/Controller/PPO2_set', 'InputValues',['[' num2str([0 round(((param.setPPO2/0.7)*10-10)*10)/10+0.0001 1000]) ']'])
            set_param('RB_TB/Controller/PPO2_set', 'OutputValues',['[' num2str([0.7 param.setPPO2+0.0001 param.setPPO2+0.0002]) ']'])
        case 7
            if strcmp(param.date_mode,'off')
                param.date_mode = 'change';
                set(handles.txtPanel2,'String', ['<- Incr Year     Next ->']) 
                param.date_index = 1;                
            else
                switch param.date_index
                    case 1 %year
                        k = findstr(param.date,'/');
                        year = str2num(param.date(k(2)+1:k(2)+4)) + 1;
                        if year > 2025
                            year = 2005;
                        end    
                        param.date = [param.date(1:k(2)) num2str(year) param.date(k(2)+5:size(param.date,2))];
                        option.date = param.date;
                        save(['../RB_TB_script/' 'RB_option' '.mat'], 'option'); 
                        set(handles.txtPanel1,'String', ['Date:  ' param.date]);
                    case 2 %month
                        month_v ='JANFEBMARAPRMAYJUNJULAUGSEPOCTNOVDEC';
                        k = findstr(param.date,'/');
                        month_name = param.date(k(1)+1:k(1)+3);
                        month_num = (findstr(month_v,month_name) - 1)/3+2;
                        if month_num > 12
                            month_num = 1;
                        end    
                        param.date = [param.date(1:k(1)) month_v(month_num*3-2:month_num*3) param.date(k(1)+4:size(param.date,2))];
                        option.date = param.date;
                        save(['../RB_TB_script/' 'RB_option' '.mat'], 'option'); 
                        set(handles.txtPanel1,'String', ['Date:  ' param.date]); 
                    case 3 % day 
                        day_max = [31 29 31 30 31 30 31 31 30 31 30 31];
                        month_v ='JANFEBMARAPRMAYJUNJULAUGSEPOCTNOVDEC';
                        k = findstr(param.date,'/');
                        month_name = param.date(k(1)+1:k(1)+3);
                        month_num = (findstr(month_v,month_name) - 1)/3+1;

                        day_num = str2num(param.date(1:k(1)-1))+1;
                        if day_num > day_max(month_num)
                            day_num = 1;
                        end    
                        param.date = [num2str(day_num) param.date(k(1):size(param.date,2))];

                        option.date = param.date;
                        save(['../RB_TB_script/' 'RB_option' '.mat'], 'option'); 
                        set(handles.txtPanel1,'String', ['Date:  ' param.date]); 
                    case 4
                        k_min = findstr(param.date,' ');
                        k_max = findstr(param.date,':');
                        hour_num = str2num(param.date(k_min+1:k_max-1))+1;
                        if hour_num > 24
                            hour_num = 1;
                        end    
                        param.date = [param.date(1:k_min) num2str(hour_num) param.date(k_max:size(param.date,2))];

                        option.date = param.date;
                        save(['../RB_TB_script/' 'RB_option' '.mat'], 'option'); 
                        set(handles.txtPanel1,'String', ['Date:  ' param.date]); 
                    case 5
                        k = findstr(param.date,':');
                        min_num = str2num(param.date(k+1:size(param.date,2)))+1;
                        if min_num > 60
                            min_num = 1;
                        end    
                        if min_num < 10
                            param.date = [param.date(1:k) '0' num2str(min_num)];
                        else
                            param.date = [param.date(1:k) num2str(min_num)];
                        end
                        option.date = param.date;
                        save(['../RB_TB_script/' 'RB_option' '.mat'], 'option'); 
                        set(handles.txtPanel1,'String', ['Date:  ' param.date]); 
                end
            end
        case 8 % Units are
            clock = 0; % bold symbols

            if strcmp(param.units, 'imperial')
                param.units = 'metric';
                
                option.units = param.units;
                save(['../RB_TB_script/' 'RB_option' '.mat'], 'option'); 

                %%%%%%%%%%%%%%%  m/ft > m
                set(handles.m_ft_depth,'String','m')
                set(handles.m_ft_ceiling, 'String', 'm')
                set(handles.m_ft_asc_rate, 'String', 'm/min')
                set(handles.m_ft_EqND, 'String', 'm')
                set(handles.m_ft_depth_down, 'String', '(m)')

                set(handles.RateAscSlider, 'Min', -110)
                set(handles.RateAscSlider, 'Max', 55) 
                set(handles.RateAscSlider, 'Value', 0)

                set(handles.m_ft_asc_rate_down, 'String', '(m/min)')
                set(handles.m_ft_asc_rate_max, 'String', '-110')
                set(handles.m_ft_des_rate_max, 'String', '55')

                set_param('RB_TB/Controller/ft_m_sw', 'Value', '0')

                %%%%%%%%%%%%%%%  C/F > C
                set(handles.C_F,'String','C')  
                set_param('RB_TB/Controller/C_F_sw', 'Value', '0')

                %%%%%%%%%%%%%%%  bar/psi > bar
                set(handles.bar_psi1, 'String','b')
                set(handles.bar_psi2, 'String','a')
                set(handles.bar_psi3, 'String','r')  

                set_param('RB_TB/Controller/bar_psi_sw', 'Value', '0')
            else
                param.units = 'imperial';

                option.units = param.units;
                save(['../RB_TB_script/' 'RB_option' '.mat'], 'option'); 

                %%%%%%%%%%%%%%%  m/ft > ft
                set(handles.m_ft_depth,'String','ft')
                set(handles.m_ft_ceiling, 'String', 'ft')    
                set(handles.m_ft_asc_rate, 'String', 'ft/min')
                set(handles.m_ft_EqND, 'String', 'ft')
                set(handles.m_ft_depth_down, 'String', '(ft)')

                NewVal = round(600/0.3048); 
                set(handles.depth_max_edit, 'String', num2str(NewVal));
                set(handles.DepthSlider, 'Max', NewVal)
                set(handles.DepthSlider, 'Value', 0)        

                set(handles.RateAscSlider, 'Min', -360)
                set(handles.RateAscSlider, 'Max', 180) 
                set(handles.RateAscSlider, 'Value', 0)

                set(handles.m_ft_asc_rate_down, 'String', '(ft/min)')
                set(handles.m_ft_asc_rate_max, 'String', '-360')
                set(handles.m_ft_des_rate_max, 'String', '180')

                set_param('RB_TB/Controller/ft_m_sw', 'Value', '1')

                %%%%%%%%%%%%%%%  C/F > F
                set(handles.C_F,'String','F')          
                set_param('RB_TB/Controller/C_F_sw', 'Value', '1')

                %%%%%%%%%%%%%%%  bar/psi > psi
                set(handles.bar_psi1, 'String','p')
                set(handles.bar_psi2, 'String','s')
                set(handles.bar_psi3, 'String','i')  

                set_param('RB_TB/Controller/bar_psi_sw', 'Value', '1')
            end 
            set(handles.txtPanel1,'String', ['  Units are ' param.units])
        case 11
            if strcmp(param.CNSmode, 'Conservative')
                param.CNSmode = 'Aggressive';
                set_param('RB_TB/Controller/CNS/add_PPO2', 'Value', '0.2')
            else
                param.CNSmode = 'Conservative';
                set_param('RB_TB/Controller/CNS/add_PPO2', 'Value', '0.3')                
            end
            option.CNSmode = param.CNSmode;
            save(['../RB_TB_script/' 'RB_option' '.mat'], 'option'); 
            
            set(handles.txtPanel1,'String', ['  CNS is in ' param.CNSmode ' mode'])
    end     
end

% end of do_left_button.m