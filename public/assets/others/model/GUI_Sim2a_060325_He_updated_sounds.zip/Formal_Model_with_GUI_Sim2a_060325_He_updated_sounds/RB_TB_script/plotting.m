function plotting(data_time, data_magnitude, param_name)

figure    
plot(data_time ./60, data_magnitude, 'r', 'linewidth',2');       
xlabel('Time, min');
ylabel('Magnitude');
title([strrep(param_name,'_',' ') ' of time']);
grid on
