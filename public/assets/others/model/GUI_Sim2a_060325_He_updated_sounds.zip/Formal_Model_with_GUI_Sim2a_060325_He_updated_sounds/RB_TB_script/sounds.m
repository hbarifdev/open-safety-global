if 1
load(['../Sounds/' 'DING_sound' '.mat'], 'y', 'Fs');     
%load(['DING_sound' '.mat'], 'y', 'Fs', 'bits');
wavplay(y,Fs)
end
% beep
% Blip
% CHIMES
% CHORD     OK
% click
% DING      OK
% TestSnd


if 0 
wavplay(param.DING_sound.y,param.DING_sound.Fs)

[y,Fs,bits] = wavread('TestSnd');
wavplay(y,Fs)
save(['TestSnd_sound' '.mat'], 'y', 'Fs', 'bits');
end


if 0 
%load audiotoolbaricons.mat
%load handel.mat
%load laughter.mat
%load splat.mat
%load train.mat
%load chirp;
%y1 = y; Fs1 = Fs;
%load gong;
%wavplay(y1,Fs1,'sync') % The chirp signal finishes before the 
%wavplay(y,Fs)          % gong signal begins playing.
end