%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plotting.m     v3.1d
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov 
% 23 October 2006
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function plotting(data_time, data_magnitude, param_name, magnitude)

figure    
plot(data_time ./60, data_magnitude, 'r', 'linewidth',2');       
xlabel('Time, min');
ylabel([param_name ',  ' magnitude]);
title([strrep(param_name,'_',' ') ' against Time']);
grid on

% end of plotting.m