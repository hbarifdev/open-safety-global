%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% main_RB_TB.m     v2.1 Beta A
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidovbottle
% 20 March 2006
%
% calculates 
% - Bang-bang control;
% - the Behlmann ZH16-L (N2 and He) decompression parameters
% - rebreather environment and breathibg loop parameters
% - GUI dispay parameters
%
% the main module runs by GUI via the console. 
% The model runs RB_TB.mdl and sends the results to GUI 
% each clock 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

% ------------------------------------------------------------
function varargout = main_RB_TB(varargin)
 
% Begin initialization code - DO NOT EDIT 
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @main_RB_TB_OpeningFcn, ...
                   'gui_OutputFcn',  @main_RB_TB_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1}); 
end 
 
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else 
    gui_mainfcn(gui_State, varargin{:});
end

% ------------------------------------------------------------
% --- Executes just before main_RB_TB is made visible.
% ------------------------------------------------------------
function main_RB_TB_OpeningFcn(hObject, eventdata, handles, varargin)

model_open(handles) 
handles.output = hObject; 
guidata(hObject, handles);

% ------------------------------------------------------------
% --- Outputs from this function are returned to the command line.
% ------------------------------------------------------------
function varargout = main_RB_TB_OutputFcn(hObject, eventdata, handles)
% Get default command line output from handles structure
varargout{1} = handles.output;

% ------------------------------------------------------------
function model_open(handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define param structure 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global param

% load profile data 
NewCell = get(handles.profile_list, 'String'); 
NewNum = get(handles.profile_list, 'Value');    % line number 
NewStruct = cell2struct(NewCell,'fields',size(NewCell,1));
param.profile_name = NewStruct(NewNum,1).fields;
load(['../Profiles/' param.profile_name '.mat'], 'profile'); 

param.profile = profile;
param.t_Initial = 0; 

% load sound data 
load(['../Sounds/' 'DING_sound' '.mat'], 'y', 'Fs');
param.DING_sound.y = y;
param.DING_sound.Fs = Fs;

% Remove all timer object from memory
% Find timer objects, including invisible objects
out = timerfindall;
% Remove a timer object from memory
delete(out) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define the RT timer 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
out = timerfindall;      % Find timer objects used before
delete(out);            % Remove a timer object from memory 

% Create new timer object
rt_timer = timer('TimerFcn', 'do_mode', 'ExecutionMode', 'FixedRate'); 
rt_timer.Period = 1;               % Specifies the delay, in seconds, between executions

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% GUI Initial State
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
disp_val(0, 0, 959, 'T.T.S', 3, 3,handles);                % T.T.S, h:mm:ss
disp_val(0, 0, 95959, 'CEILING TIME', 5, 8, handles);      % CEILING TIME, h:mm:ss 
disp_val(0, 0, 600, 'CEILING', 3, 11, handles);            % CEILING,  m/ft
disp_val(0, 0, 600, 'DEPTH', 3, 14, handles);              % DEPTH, m/f
disp_val(0, 0, 95959, 'DIVE TIME', 5, 19, handles);        % DIVE TIME, h:mm:ss
disp_val(0, 0, 100, 'CNS', 2, 21, handles);                 % CNS, %
disp_val(0, -60, 60, 'ASC RATE', 2, 23, handles);          % ASC RATE,  m/min   ft/min
disp_val(0, 0, 100, 'O2', 2, 25, handles);                  % O2, %
disp_val(0, 0, 100, 'He', 2, 27, handles);                  % He, %
disp_val(0, 0, 100, 'N2', 2, 29, handles);                  % N2, %
disp_val(0, 0, 100, 'SCRB', 2, 31, handles);             % SCRB, %
disp_val(0, 0, 100, 'BAT', 2, 33, handles);              % BAT, %
disp_val(0, 0, 100, 'HUM', 2, 35, handles);                % HUM, %
disp_val(0, 0, 45, 'TEMP', 2, 37, handles);               % TEMP, C/F
disp_val(0, 0, 159, '123PPO2', 3, 40, handles);            % 123PPO2, ATA
disp_val(0, 0, 3, 'PPCO2', 2, 42, handles);                % PPCO2, ATA
disp_val(0, 0, 999, 'EqND', 3, 45, handles);               % EqND, m/ft
disp_val(0, 0, 1200, 'DIL CILINDER', 4, 49, handles);       % DIL CILINDER, BPASRI 
disp_val(0, 0, 1200, 'O2 CILINDER', 4, 53, handles);        % O2 CILINDER, BPASRI   

cnc_O2_atm = 20.9476;               % cnc O2 sea level (101325 Pa, wed 15%) = 20.9476%;
cnc_CO2_atm = 0.0314;               % cnc CO2 sea level (101325 Pa, wed 15%) = 0.0314%;
cnc_N2_atm = 78.084;                % cnc N2 sea level (101325 Pa, wed 15%) = 78.084%;
cnc_He_atm = 0.000524;              % cnc He sea level (101325 Pa, wed 15%) = 0.000524;
cnc_res_atm = 0.9365;               % cnc Res sea level (101325 Pa, wed 15%) = 0.9365;
cnc_total_atm = cnc_O2_atm + cnc_CO2_atm + cnc_N2_atm + cnc_He_atm + cnc_res_atm;
% Note: 
% cnc_total_atm must be = 100%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Display atm parameters in GUI 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
set(handles.cnc_O2, 'String', num2str(round(100*cnc_O2_atm)/100)) 
set(handles.cnc_CO2, 'String', num2str(round(100*cnc_CO2_atm)/100))
set(handles.cnc_N2, 'String', num2str(round(100*cnc_N2_atm)/100))
set(handles.cnc_He, 'String', num2str(round(100*cnc_He_atm)/100))
set(handles.cnc_res, 'String', num2str(round(100*cnc_res_atm)/100))
set(handles.cnc_total, 'String', num2str(round(10*cnc_total_atm)/10))
set(handles.pr_BL, 'String', num2str(round(str2num(get(handles.prAmbient_ini,'String'))/10)/100))

if  isempty(find_system('Name', 'RB_TB')),
	open_system('RB_TB'); 
     
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Define ini model parameters of the RB_TB blocks    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    set_param('RB_TB/Environment/O2 balance/cnc_O2_atm', 'Value',...
        num2str(cnc_O2_atm/100))         % cnc O2 sea level (101325 Pa, wed 15%) = 20.9476%;
    set_param('RB_TB/Environment/CO2 balance/cnc_CO2_atm', 'Value',...
        num2str(cnc_CO2_atm/100))         % cnc CO2 sea level (101325 Pa, wed 15%) = 0.0314%;
    set_param('RB_TB/Controller/deco_N2/Palveola/cnc_N2_atm', 'Value',...
        num2str(cnc_N2_atm/100))         % cnc N2 sea level (101325 Pa, wed 15%) = 78.084%;
    set_param('RB_TB/Controller/deco_He/Palveola/cnc_He_atm', 'Value',...
        num2str(cnc_He_atm/100))         % cnc He sea level (101325 Pa, wed 15%) = 0.000524;
    set_param('RB_TB/Environment/Residual gas balance/cnc_res_atm', 'Value',...
        num2str(cnc_res_atm/100))         % cnc Res sea level (101325 Pa, wed 15%) = 0.9365;
   
    set_param('RB_TB/Controller/RT delay1', 'SampleTime', '0.1')        % RT_CLK = 0.1;
    set_param('RB_TB/Controller/RT delay2', 'SampleTime', '0.1')        % RT_CLK = 0.1;
    set_param('RB_TB/Controller/RT delay3', 'SampleTime', '0.1')        % RT_CLK = 0.1;    
    set_param('RB_TB/Controller/temp_breathing', 'Value', '33')         % temp_air_sea_level = 37;        
    set_param('RB_TB/Environment/temp_water_handset', 'Value', '24')    % temp_water_handset = 24;
    set_param('RB_TB/Environment/wet', 'Value', '0.23')                   % wet = 23%;
    set_param('RB_TB/Controller/deco_N2/RQ', 'Value', '0.9')            % RQ = 0.9;    
    
    set_param('RB_TB/Controller/add_bat_discharge', 'Value', '0')         % add battery discharge    
    
    param.deco_rate_asc = -9/60;     % m/s
    % following two params must be equal to each other
    set_param('RB_TB/Controller/deco_N2/While_Iterator/rate_asc_deco', 'Value',...
        num2str(-6*param.deco_rate_asc))            % rate_asc_deco = 0.9; % -9 meter/min
    set_param('RB_TB/Controller/deco_He/While_Iterator/rate_asc_deco', 'Value',...
        num2str(-6*param.deco_rate_asc))            % rate_asc_deco = 0.9; % -9 meter/min
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Put  values from the GUI into the Block dialogs
    % and define model parameters    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    set_param('RB_TB/Controller/pr_ambient_sea_level', 'Value',... 
        get(handles.prAmbient_ini,'String'))          % (mbar)
    set_param('RB_TB/Environment/O2 bottle injection/size_O2_bottle', 'Value',...
        get(handles.sizeO2bottle,'String'))     % (bar)
    set_param('RB_TB/Environment/O2 bottle injection/pr_O2_bottle_ini', 'Value',...
        get(handles.prO2bottle,'String'))       % (bar)
    set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/size_dil_bottle1', 'Value',...
        get(handles.sizeDILbottle1,'String'))   % (litre)
    set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/size_dil_bottle2', 'Value',...
        get(handles.sizeDILbottle1,'String'))   % (litre)    
    set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/size_dil_bottle3', 'Value',...
        get(handles.sizeDILbottle1,'String'))   % (litre)    
    set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/pr_dil_bottle1_ini', 'Value',...
        get(handles.prDILbottle1,'String'))     % (bar)
    set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/pr_dil_bottle2_ini', 'Value',...
        get(handles.prDILbottle1,'String'))     % (bar)
    set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/pr_dil_bottle3_ini', 'Value',...
        get(handles.prDILbottle1,'String'))     % (bar)
    set_param('RB_TB/Environment/Diluent injection/cnc_O2_dil_bottle1', 'Value',...
        get(handles.cncO2DILbottle1,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_O2_dil_bottle2', 'Value',...
        get(handles.cncO2DILbottle2,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_O2_dil_bottle3', 'Value',...
        get(handles.cncO2DILbottle3,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle1', 'Value',...
        get(handles.cncHeDILbottle1,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle2', 'Value',...
        get(handles.cncHeDILbottle2,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle3', 'Value',...
        get(handles.cncHeDILbottle3,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle1', 'Value',...
        get(handles.cncN2DILbottle1,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle2', 'Value',...
        get(handles.cncN2DILbottle2,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle3', 'Value',...
        get(handles.cncN2DILbottle3,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/gas_mix_num', 'Value',...
        get(handles.GasMix,'String'))           % 1, 2, or 3
    set_param('RB_TB/Breathing/rate_metabolic', 'Value',...
        get(handles.RateMet,'String'))          % (l/min)
    set_param('RB_TB/Environment/CO2 balance/rate_respiratory', 'Value',...
        get(handles.RateResp,'String'))         % (l/min)
    set_param('RB_TB/Environment/vol_tidal', 'Value',...
        get(handles.VolTidal,'String'))         % (litre) 
    set_param('RB_TB/Controller/capacity_bat', 'Value',...
        num2str(str2num(get(handles.capacity_bat,'String'))*3600))  % mAsecond 
    set_param('RB_TB/Environment/discharge_bat', 'Value',...
        get(handles.discharge_bat,'String'))        % mA     
    set_param('RB_TB/Environment/CO2 balance/SCRB_LT', 'Value',...
        get(handles.lifetime_scrb,'String'))        % hour       
    set_param('RB_TB/Controller/deco_mode', 'Value',...
        num2str(get(handles.presize_deco,'Value')+1))           % deco precize mode ON/OFF   
    set_param('RB_TB/Controller/O2_set', 'Value',...
        num2str(get(handles.O2control_step_set,'Value')+1))     % O2 set Relay/Analogue       
    set_param('RB_TB/Environment/O2 bottle injection/valve_mode', 'Value',...
        num2str(get(handles.O2NotCompValve,'Value')))     % mode of the O2 pressure reduction valve
    set_param('RB_TB/Environment/O2 bottle injection/diam_orifice', 'Value',...
        num2str(get(handles.orifice_size,'String')))     % orifice size
    valve_pressure = str2num(get(handles.ADV,'String'))/1000;
    set_param('RB_TB/Environment/Diluent injection/Automatic Diluent Valve', 'InputValues', mat2str([-10000 valve_pressure valve_pressure+0.01 10000]))
    valve_pressure = str2num(get(handles.OPV,'String'))/1000; 
    set_param('RB_TB/Environment/Overpressure/OverPressure Valve', 'InputValues', mat2str([-10000 valve_pressure valve_pressure+0.03 10000]))
    %[-10000 0.025 0.03 10000]  
    %[0 0 3000 3000]
    set_param('RB_TB/Environment/O2 bottle injection/pr_IM_O2_valve', 'Value',...
        get(handles.IMprO2valve,'String'))          % (bar)
    set_param('RB_TB/Environment/Diluent injection/pr_IM_Dil_valve', 'Value',...
        get(handles.IMprDiluentValve,'String'))     % (bar)
    set_param('RB_TB/Sensors/Pressure_ambient Sensor/depth_range', 'Value',...
        get(handles.depth_max_edit,'String'))       % (bar)  
    
    % reset manual O2 and Dil control
    set(handles.O2_button,'Value',0);
    set(handles.Dil_button,'Value',0);    
    set_param('RB_TB/Environment/O2 bottle injection/O2_in_manual', 'Value', '0')
    set_param('RB_TB/Environment/Diluent injection/Dil_in_manual', 'Value', '0')    
    
    % reset faults and O2 control mode   
    do_none_fault(handles) 
end

% ------------------------------------------------------------
% Callback of configuration
% ------------------------------------------------------------
function prAmbient_ini_Callback(h, eventdata, handles) % Ambient sea level pressure

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 1010;     % default, (mbar) 
elseif NewVal< 850
    NewVal = 850;     
elseif  NewVal>1100
    NewVal = 1100; 
end   

set(h,'String',NewVal)
set_param('RB_TB/Controller/pr_ambient_sea_level', 'Value', num2str(NewVal))   % mbar


% ------------------------------------------------------------
function sizeO2bottle_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 3;     % default, (litre)
elseif NewVal< 1
    NewVal = 1;
elseif NewVal>20
    NewVal = 20;	
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/O2 bottle injection/size_O2_bottle', 'Value', num2str(NewVal))
    
% ------------------------------------------------------------
function prO2bottle_Callback(h, eventdata, handles)
 
NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 230;     % default, (bar)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 300
    NewVal = 300; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/O2 bottle injection/pr_O2_bottle_ini', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function cncO2DILbottle1_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 20;     % default, (%)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 100
    NewVal = 100; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Diluent injection/cnc_O2_dil_bottle1', 'Value', num2str(NewVal))

cnc_He_dil_bottle1 = str2num(get(handles.cncHeDILbottle1,'String'));
cnc_N2_dil_bottle1 = str2num(get(handles.cncN2DILbottle1,'String'));

if  (NewVal+cnc_He_dil_bottle1>100),	
    cnc_He_dil_bottle1 = 100 - NewVal;
    set(handles.cncHeDILbottle1,'String',cnc_He_dil_bottle1) 
    set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle1', 'Value', num2str(cnc_He_dil_bottle1))    
    cnc_N2_dil_bottle1 = 0;    
    set(handles.cncN2DILbottle1,'String',cnc_N2_dil_bottle1)    
else    
    cnc_N2_dil_bottle1 = 100 - NewVal - cnc_He_dil_bottle1;
    set(handles.cncN2DILbottle1,'String',cnc_N2_dil_bottle1)    
end

set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle1', 'Value', num2str(cnc_N2_dil_bottle1))

% ------------------------------------------------------------
function cncHeDILbottle1_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

cnc_O2_dil_bottle1 = str2num(get(handles.cncO2DILbottle1,'String'));
cnc_N2_dil_bottle1 = str2num(get(handles.cncN2DILbottle1,'String'));

if  isempty(NewVal) || isnan(NewVal) || (NewVal< 0) || (NewVal>100-cnc_O2_dil_bottle1),
	NewVal = 0;         % default (%)
    cnc_N2_dil_bottle1 = 100 - cnc_O2_dil_bottle1;
else
    cnc_N2_dil_bottle1 = 100 - cnc_O2_dil_bottle1 - NewVal;    
end

set(h,'String',NewVal)
set(handles.cncN2DILbottle1,'String',cnc_N2_dil_bottle1)
set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle1', 'Value', num2str(NewVal))
set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle1', 'Value', num2str(cnc_N2_dil_bottle1))

% ------------------------------------------------------------
function cncN2DILbottle1_Callback(h, eventdata, handles)

cnc_O2_dil_bottle1 = str2num(get(handles.cncO2DILbottle1,'String'));
cnc_He_dil_bottle1 = str2num(get(handles.cncHeDILbottle1,'String'));

NewVal = 100 - cnc_O2_dil_bottle1 - cnc_He_dil_bottle1;

set(h,'String',NewVal)       

% ------------------------------------------------------------
function prDILbottle1_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 230;     % default, (bar)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 300
    NewVal = 300; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/pr_dil_bottle1_ini', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function sizeDILbottle1_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 3;     % default, (litre)
elseif NewVal< 1
    NewVal = 1;     
elseif  NewVal > 20
    NewVal = 20; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/size_dil_bottle1', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function cncO2DILbottle2_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 32;     % default, (%)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 100
    NewVal = 100; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Diluent injection/cnc_O2_dil_bottle2', 'Value', num2str(NewVal))


cnc_He_dil_bottle2 = str2num(get(handles.cncHeDILbottle2,'String'));
cnc_N2_dil_bottle2 = str2num(get(handles.cncN2DILbottle2,'String'));

if  (NewVal+cnc_He_dil_bottle2>100),	
    cnc_He_dil_bottle2 = 100 - NewVal;
    set(handles.cncHeDILbottle2,'String',cnc_He_dil_bottle2) 
    set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle2', 'Value', num2str(cnc_He_dil_bottle2))    
    cnc_N2_dil_bottle2 = 0;    
    set(handles.cncN2DILbottle2,'String',cnc_N2_dil_bottle2)    
else    
    cnc_N2_dil_bottle2 = 100 - NewVal - cnc_He_dil_bottle2;
    set(handles.cncN2DILbottle2,'String',cnc_N2_dil_bottle2)    
end

set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle2', 'Value', num2str(cnc_N2_dil_bottle2))

% ------------------------------------------------------------
function cncHeDILbottle2_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

cnc_O2_dil_bottle2 = str2num(get(handles.cncO2DILbottle2,'String'));
cnc_N2_dil_bottle2 = str2num(get(handles.cncN2DILbottle2,'String'));

if  isempty(NewVal) || isnan(NewVal) || (NewVal< 0) || (NewVal>100-cnc_O2_dil_bottle2),
	NewVal = 0;         % default (%)
    cnc_N2_dil_bottle2 = 100 - cnc_O2_dil_bottle2;
else
    cnc_N2_dil_bottle2 = 100 - cnc_O2_dil_bottle2 - NewVal;    
end

set(h,'String',NewVal)
set(handles.cncN2DILbottle2,'String',cnc_N2_dil_bottle2)
set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle2', 'Value', num2str(NewVal))
set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle2', 'Value', num2str(cnc_N2_dil_bottle2))

% ------------------------------------------------------------
function cncN2DILbottle2_Callback(h, eventdata, handles)

cnc_O2_dil_bottle2 = str2num(get(handles.cncO2DILbottle2,'String'));
cnc_He_dil_bottle2 = str2num(get(handles.cncHeDILbottle2,'String'));

NewVal = 100 - cnc_O2_dil_bottle2 - cnc_He_dil_bottle2;

set(h,'String',NewVal) 

% ------------------------------------------------------------
function prDILbottle2_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 230;     % default, (bar)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 300
    NewVal = 300; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/pr_dil_bottle2_ini', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function sizeDILbottle2_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 3;     % default, (litre)
elseif NewVal< 1
    NewVal = 1;     
elseif  NewVal > 20
    NewVal = 20; 
end

set(h,'String',NewVal)
set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/size_dil_bottle2', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function cncO2DILbottle3_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 20;     % default, (%)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 100
    NewVal = 100; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Diluent injection/cnc_O2_dil_bottle3', 'Value', num2str(NewVal))

cnc_He_dil_bottle3 = str2num(get(handles.cncHeDILbottle3,'String'));
cnc_N2_dil_bottle3 = str2num(get(handles.cncN2DILbottle3,'String'));

if  (NewVal+cnc_He_dil_bottle3>100),	
    cnc_He_dil_bottle3 = 100 - NewVal;
    set(handles.cncHeDILbottle3,'String',cnc_He_dil_bottle3) 
    set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle3', 'Value', num2str(cnc_He_dil_bottle3))    
    cnc_N2_dil_bottle3 = 0;    
    set(handles.cncN2DILbottle3,'String',cnc_N2_dil_bottle3)    
else    
    cnc_N2_dil_bottle3 = 100 - NewVal - cnc_He_dil_bottle3;
    set(handles.cncN2DILbottle3,'String',cnc_N2_dil_bottle3)    
end

set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle3', 'Value', num2str(cnc_N2_dil_bottle3))

% ------------------------------------------------------------
function cncHeDILbottle3_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

cnc_O2_dil_bottle3 = str2num(get(handles.cncO2DILbottle3,'String'));
cnc_N2_dil_bottle3 = str2num(get(handles.cncN2DILbottle3,'String'));

if  isempty(NewVal) || isnan(NewVal) || (NewVal< 0) || (NewVal>100-cnc_O2_dil_bottle3),
	NewVal = 0;         % default (%)
    cnc_N2_dil_bottle3 = 100 - cnc_O2_dil_bottle3;
else
    cnc_N2_dil_bottle3 = 100 - cnc_O2_dil_bottle3 - NewVal;    
end

set(h,'String',NewVal)
set(handles.cncN2DILbottle3,'String',cnc_N2_dil_bottle3)
set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle3', 'Value', num2str(NewVal))
set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle3', 'Value', num2str(cnc_N2_dil_bottle3))

% ------------------------------------------------------------
function cncN2DILbottle3_Callback(h, eventdata, handles)

cnc_O2_dil_bottle3 = str2num(get(handles.cncO2DILbottle3,'String'));
cnc_He_dil_bottle3 = str2num(get(handles.cncHeDILbottle3,'String'));
NewVal = 100 - cnc_O2_dil_bottle3 - cnc_He_dil_bottle3;

set(h,'String',NewVal) 

% ------------------------------------------------------------
function prDILbottle3_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 230;     % default, (bar)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 300
    NewVal = 300; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/pr_dil_bottle3_ini', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function sizeDILbottle3_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 3;     % default, (litre)
elseif NewVal< 1
    NewVal = 1;     
elseif  NewVal > 20
    NewVal = 20; 
end

set(h,'String',NewVal)
set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/size_dil_bottle3', 'Value', num2str(NewVal))


% ------------------------------------------------------------
% Callback of input dive parameters
% ------------------------------------------------------------
function RateAsc_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal); 

if  isempty(NewVal) || isnan(NewVal)
    NewVal = get(handles.RateAscSlider,'Value'); 	
elseif NewVal < -15
    NewVal = -15;     
elseif  NewVal > 60
    NewVal = 60; 
end 

NewVal = round(10*NewVal)/10;
set(h,'String',NewVal)
set(handles.RateAscSlider,'Value',NewVal)	
  
% ------------------------------------------------------------
function RateAscSlider_Callback(h, eventdata, handles)

NewVal = round(10*get(h,'Value'))/10; 
set(handles.RateAsc,'String',NewVal)

% ------------------------------------------------------------
function Depth_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);

depthMAX = str2num(get(handles.depth_max_edit, 'String'));
if  isempty(NewVal) || isnan(NewVal)
	NewVal = get(handles.DepthSlider,'Value'); 	
elseif NewVal < 0
    NewVal = 0;     
elseif  NewVal > depthMAX
    NewVal = depthMAX; 
end

NewVal = round(10*NewVal)/10; 
set(h,'String',NewVal)
set(handles.DepthSlider,'Value',NewVal)

% ------------------------------------------------------------
function DepthSlider_Callback(h, eventdata, handles)

NewVal = round(10*get(h,'Value'))/10;

set(handles.Depth,'String',NewVal)

% ------------------------------------------------------------
function RateMet_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);     % l/min

if  isempty(NewVal) || isnan(NewVal)
	NewVal = get(handles.RateMetSlider,'Value'); 	
elseif NewVal < 0
    NewVal = 0;     
elseif  NewVal > 6
    NewVal = 6; 
end

NewVal = round(100*NewVal)/100
set(h,'String',NewVal)
set(handles.RateMetSlider,'Value',NewVal)
set_param('RB_TB/Breathing/rate_metabolic', 'Value', num2str(NewVal))   % l/min 

% ------------------------------------------------------------
function RateMetSlider_Callback(h, eventdata, handles)
 
NewVal = round(100*get(h,'Value'))/100;   % l/min

set(handles.RateMet,'String',NewVal)
set_param('RB_TB/Breathing/rate_metabolic', 'Value', num2str(NewVal)) % l/min

% ------------------------------------------------------------
function RateResp_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
    NewVal = get(handles.RateRespSlider,'Value'); 	
elseif NewVal < 0
    NewVal = 0;     
elseif  NewVal > 100
    NewVal = 100; 
end

NewVal = round(10*NewVal)/10
set(h,'String',NewVal)
set(handles.RateRespSlider,'Value',NewVal)
set_param('RB_TB/Environment/CO2 balance/rate_respiratory', 'Value', num2str(NewVal)) % l/min    

% ------------------------------------------------------------
function RateRespSlider_Callback(h, eventdata, handles)

NewVal = round(10*get(h,'Value'))/10;
set(handles.RateResp,'String',NewVal)

set_param('RB_TB/Environment/CO2 balance/rate_respiratory', 'Value', num2str(NewVal)) % l/min

% ------------------------------------------------------------
function VolTidal_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2double(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
    NewVal = get(handles.VolTidalSlider,'Value'); 	
elseif NewVal < 0
    NewVal = 0;     
elseif  NewVal > 90
    NewVal = 90; 
end

NewVal = round(10*NewVal)/10
set(h,'String',NewVal)
set(handles.VolTidalSlider,'Value',NewVal)
set_param('RB_TB/Environment/vol_tidal', 'Value', NewStrVal)   

% ------------------------------------------------------------
function VolTidalSlider_Callback(h, eventdata, handles)

NewVal = round(10*get(h,'Value'))/10;
set(handles.VolTidal,'String',NewVal)
set_param('RB_TB/Environment/vol_tidal', 'Value', num2str(NewVal))   

% ------------------------------------------------------------
function GasMix_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
    NewVal = get(handles.GasMixPopupmenu,'Value'); 	
elseif NewVal < 1
    NewVal = 1;     
elseif  NewVal > 3
    NewVal = 3; 
end

NewVal = round(NewVal)
set(h,'String',NewVal)
set(handles.GasMixPopupmenu,'Value',NewVal)
set_param('RB_TB/Environment/Diluent injection/gas_mix_num', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function GasMixPopupmenu_Callback(h, eventdata, handles)

NewVal = get(h,'Value');

set(handles.GasMix,'String',NewVal)
set_param('RB_TB/Environment/Diluent injection/gas_mix_num', 'Value', num2str(NewVal))


% ------------------------------------------------------------
% Callback of GUI and model message panels
% ------------------------------------------------------------
function txtPanel1_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function txtPanel2_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function ModelTxtPanel_Callback(h, eventdata, handles)


% ------------------------------------------------------------
% Callback of not connected object
% ------------------------------------------------------------
function LeftButton_Callback(h, eventdata, handles)
global param
disp('Note: Left Button is not connected');
set(handles.ModelTxtPanel,'String', ['>> Left Button is not connected']);
wavplay(param.DING_sound.y,param.DING_sound.Fs)

% ------------------------------------------------------------
function RightButton_Callback(h, eventdata, handles)
global param
disp('Note: Right Button is not connected');
set(handles.ModelTxtPanel,'String', ['>> Right Button is not connected']);
wavplay(param.DING_sound.y,param.DING_sound.Fs)

% ------------------------------------------------------------
function TankUnloadButton_Callback(h, eventdata, handles)
global param
disp('Note: Tank Unload Button is not connected');
set(handles.ModelTxtPanel,'String', ['>> Tank Unload Button is not connected']);
wavplay(param.DING_sound.y,param.DING_sound.Fs)

function LED_Callback(h, eventdata, handles)
global param
disp('Note: LED mode selector is not connected');
set(handles.ModelTxtPanel,'String', ['>> LED mode selector is not connected']);
wavplay(param.DING_sound.y,param.DING_sound.Fs)


% ------------------------------------------------------------
% Callback of Device Fault Simulation panel
% ------------------------------------------------------------
function DeviceFaultpopupmenu_Callback(h, eventdata, handles)
global param

NewCell = get(h, 'String'); 
NewNum = get(h, 'Value');
NewStruct = cell2struct(NewCell,'fields',33);
fault_name = NewStruct(NewNum,1).fields;

do_fault(fault_name, param, handles)

% ------------------------------------------------------------
% Callback of control
% ------------------------------------------------------------
function O2control_step_set_Callback(h, eventdata, handles)
NewVal = get(h,'Value');
set_param('RB_TB/Controller/O2_set', 'Value', num2str(NewVal+1))         % O2 set: Relay/Analogue   

% ------------------------------------------------------------
function O2control_Callback(h, eventdata, handles)

O2controlMode(handles)

% ------------------------------------------------------------
function CO2control_Callback(h, eventdata, handles)
global param
disp('Note: CO2 control is not connected');
set(handles.ModelTxtPanel,'String', ['>> CO2 control is not connected']);
wavplay(param.DING_sound.y,param.DING_sound.Fs)

% ------------------------------------------------------------
function O2_button_Callback(h, eventdata, handles)
% O2 income of 20% of tidal volume per second
NewVal = get(h,'Value');
set_param('RB_TB/Environment/O2 bottle injection/O2_in_manual', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function Dil_button_Callback(h, eventdata, handles)
% Dil income manual flow is ADV flow max
NewVal = get(h,'Value');
set_param('RB_TB/Environment/Diluent injection/Dil_in_manual', 'Value', num2str(NewVal))


% ------------------------------------------------------------
% Callback of BAT and SCRB panels
% ------------------------------------------------------------
function capacity_bat_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(100*str2num(NewStrVal))/100; 

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 2200;     % default, (mAh)
elseif NewVal< 500
    NewVal = 500;     
elseif  NewVal > 6000
    NewVal = 6000; 
end

set(h,'String',NewVal)    
set_param('RB_TB/Controller/capacity_bat', 'Value', num2str(NewVal*3600)) % (mA)*(second)
 
% ------------------------------------------------------------
function discharge_bat_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 30;     % default, (mA)
elseif NewVal< 5
    NewVal = 5;     
elseif  NewVal > 100
    NewVal = 100; 
end

set(h,'String',NewVal)    
set_param('RB_TB/Environment/discharge_bat', 'Value', num2str(NewVal)) % mA 


% ------------------------------------------------------------
function lifetime_scrb_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(10*str2num(NewStrVal))/10; 

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 5;     % default, (hour)
elseif NewVal< 1
    NewVal = 1;     
elseif  NewVal > 99
    NewVal = 99; 
end

set(h,'String',NewVal)    
set_param('RB_TB/Environment/CO2 balance/SCRB_LT', 'Value', num2str(NewVal*3600))

% ------------------------------------------------------------
% Callback of reduction valve panels
% ------------------------------------------------------------
function O2NotCompValve_Callback(h, eventdata, handles)
NewVal = get(h,'Value');
set_param('RB_TB/Environment/O2 bottle injection/valve_mode', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function IMprO2valve_Callback(h, eventdata, handles) 

NewStrVal = get(h,'String');
NewVal = round(10*str2num(NewStrVal))/10; 

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 25;     % default, (litre)
elseif NewVal< 5
    NewVal = 5;     
elseif  NewVal > 50
    NewVal = 50; 
end

set(h,'String',NewVal)    

set_param('RB_TB/Environment/O2 bottle injection/pr_IM_O2_valve', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function orifice_size_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 200;     % default, (um)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 1000
    NewVal = 1000; 
end

% O2 flow through the orific must not be less than the metabolic rate
rate_metabolic = str2double(get(handles.RateMet,'String'));  % l/min
pr_intermediate_sea_level = str2double(get(handles.IMprO2valve,'String'));  % bar

orifice_metabolic = round(1000*sqrt(rate_metabolic/(pr_intermediate_sea_level*8.65))); % um

if NewVal < orifice_metabolic
    NewVal = orifice_metabolic;
    disp('Note: Orifice is increased to provide the sonic flow as the metabolic rate');
    set(handles.ModelTxtPanel,'String', ['>> Orifice is increased to provide the sonic flow as the metabolic rate']);    
end

set(h,'String',NewVal)    

set_param('RB_TB/Environment/O2 bottle injection/diam_orifice', 'Value', num2str(NewVal))


% ------------------------------------------------------------
function DiluentNotCompValve_Callback(h, eventdata, handles)
NewVal = get(h,'Value');
set_param('RB_TB/Environment/Diluent injection/valve_mode', 'Value', num2str(NewVal)) 

% ------------------------------------------------------------
function IMprDiluentValve_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(10*str2num(NewStrVal))/10; 

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 25;     % default, (litre)
elseif NewVal< 5
    NewVal = 5;     
elseif  NewVal > 50
    NewVal = 50; 
end

set(h,'String',NewVal)    

set_param('RB_TB/Environment/Diluent injection/pr_IM_Dil_valve', 'Value', num2str(NewVal))

% ------------------------------------------------------------
% Callback of profile objects
% ------------------------------------------------------------
function DepthInputProfile_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function DepthInputManual_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function DepthInputDeco_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function presize_deco_Callback(h, eventdata, handles)
NewVal = get(h,'Value');
set_param('RB_TB/Controller/deco_mode', 'Value', num2str(NewVal+1))   


% ------------------------------------------------------------
% Callback of Depth/Rate input for the manual mode
% ------------------------------------------------------------
function In_depth_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function In_rate_Callback(h, eventdata, handles)

% ------------------------------------------------------------
% Callback of sim mode panel
% ------------------------------------------------------------
function SimModeRT_Callback(h, eventdata, handles)
global sim_state param

if strcmp(sim_state,'run') 
    sim_state = 'pause'; 
    set(handles.ModelTxtPanel,'String', ['>> PAUSE']);
    set(handles.RunButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
    set(handles.PauseButton, 'BackgroundColor', [0.9608 0.9569 0.9529])    
    wavplay(param.DING_sound.y,param.DING_sound.Fs)     
end

% ------------------------------------------------------------
function SimModeAc_Callback(h, eventdata, handles)
global sim_state param
 
if strcmp(sim_state,'run') 
    % stop RT mode
    rt_timer = timerfind;  
    if strcmp(get(rt_timer, 'Running'),'on') 
        stop(rt_timer);  
    end
    sim_state = 'pause'; 
    set(handles.ModelTxtPanel,'String', ['>> PAUSE']); 
    set(handles.RunButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
    set(handles.PauseButton, 'BackgroundColor', [0.9608 0.9569 0.9529])  
    wavplay(param.DING_sound.y,param.DING_sound.Fs)     
end 

% ------------------------------------------------------------
% Callback of RUN, PAUSE, STOP buttons
% ------------------------------------------------------------
function RunButton_Callback(h, eventdata, handles)
global param GUIparams sim_state

set(handles.RunButton, 'BackgroundColor', [0.9608 0.9569 0.9529])
set(handles.PauseButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
set(handles.StopButton, 'BackgroundColor', [0.835294 0.815686 0.784314])

GUIparams = handles;   

if strcmp(sim_state,'stop')    
    param.t_Initial = 0;
end

sim_state = 'run'; 

if get(handles.SimModeRT,'Value') == 1   
    % RT sim mode
    rt_timer = timerfind;
    rt_timer.TasksToExecute = 36000;  % Specifies max possible number of times  
    
    if strcmp(get(rt_timer, 'Running'),'off')
        start(rt_timer)    % start timer
    end
else  
    % accelerated sim mode            
    while strcmp(sim_state,'run') 
        do_mode         
    end 
end       
 

% ------------------------------------------------------------
function PauseButton_Callback(h, eventdata, handles)
global sim_state

set(handles.RunButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
set(handles.PauseButton, 'BackgroundColor', [0.9608 0.9569 0.9529])
set(handles.StopButton, 'BackgroundColor', [0.835294 0.815686 0.784314])

rt_timer = timerfind;  
if strcmp(get(rt_timer, 'Running'),'on') 
    stop(rt_timer);   
end

if ~strcmp(sim_state, 'stop')
    set(handles.ModelTxtPanel,'String', ['>> PAUSE']);
    sim_state = 'pause';    
end

% ------------------------------------------------------------
function StopButton_Callback(h, eventdata, handles)
global sim_state param

set(handles.RunButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
set(handles.PauseButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
set(handles.StopButton, 'BackgroundColor', [0.9608 0.9569 0.9529])

sim_state = 'stop'; 
 
rt_timer = timerfind;
if strcmp(get(rt_timer, 'Running'),'on')
    stop(rt_timer);      
end

set(handles.ModelTxtPanel,'String', ['>> STOP']);

% ------------------------------------------------------------
function varargout = HelpButton_Callback(h, eventdata, handles)
HelpPath = which('RB_TB_help.html');
web(HelpPath); 

 
% ------------------------------------------------------------
% Callback of "pause" panel
% ------------------------------------------------------------
function pause_depth_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function pause_depth_edit_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(10*str2num(NewStrVal))/10; 

GUI_Depth_Slider_Max = get(handles.DepthSlider, 'Max');
if  isempty(NewVal) || isnan(NewVal) 
	NewVal = 0;     % default, (m)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > GUI_Depth_Slider_Max
    NewVal = GUI_Depth_Slider_Max; 
end

set(h,'String',NewVal)    

% ------------------------------------------------------------
function pause_time_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function pause_time_edit_h_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal) 
	NewVal = 0;    
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 9
    NewVal = 9;
end

set(h,'String',NewVal)

% ------------------------------------------------------------
function pause_time_edit_mm_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal) 
    set(h,'String','00')
elseif NewVal< 0
    set(h,'String','00')
elseif  NewVal > 59
    set(h,'String','59')
elseif  ~(NewVal < 0) && ~(NewVal > 9)
    set(h,'String',['0' num2str(NewVal)])
else
    set(h,'String', NewVal)    
end

% ------------------------------------------------------------
function pause_time_edit_ss_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal) 
    set(h,'String','00')
elseif NewVal< 0
    set(h,'String','00')
elseif  NewVal > 59
    set(h,'String','59')
elseif  ~(NewVal < 0) && ~(NewVal > 9)
    set(h,'String',['0' num2str(NewVal)])
else
    set(h,'String', NewVal)    
end

% ------------------------------------------------------------
function depth_max_edit_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(10*str2num(NewStrVal))/10; 

if  isempty(NewVal) || isnan(NewVal) 
	NewVal = 40;    
elseif NewVal< 40
    NewVal = 40;     
elseif  NewVal > 600
    NewVal = 600;
end

set(h,'String',NewVal)
set_param('RB_TB/Sensors/Pressure_ambient Sensor/depth_range', 'Value',num2str(NewVal)) 

depth = str2num(get(handles.Depth, 'String'));

if (depth > NewVal) 
    set(handles.Depth,'String',NewVal)
    set(handles.DepthSlider,'Value',NewVal)    
    set(handles.DepthSlider, 'Max', NewVal);    
else
    set(handles.DepthSlider, 'Max', NewVal); 
end

depth = str2num(get(handles.pause_depth_edit, 'String'));

if (depth > NewVal) 
    set(handles.pause_depth_edit,'String',NewVal)
end

% ------------------------------------------------------------
% Callback of "record" panel
% ------------------------------------------------------------
function record_depth_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.depth = [];
    param.record.depth_time = [];
end

% ------------------------------------------------------------
function record_plot_Callback(h, eventdata, handles)
global param

if get(handles.record_depth,'Value') == 1 && size(param.record.depth,2) > 1;
    figure    
    plot(param.record.depth_time ./60, param.record.depth, 'r', 'linewidth',2');       
    xlabel('Time, min');
    ylabel('Depth, m');
    title(['Depth data']);
    grid on
else
    disp('Note: no accumulated data')
    set(handles.ModelTxtPanel,'String', ['>> no accumulated data']);        
end    

% ------------------------------------------------------------
function record_file_name_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function record_save_Callback(h, eventdata, handles)
global param 

if get(handles.record_depth,'Value') == 1 && size(param.record.depth,2) > 1;
    profile = param.record;
    file_name = get(handles.record_file_name,'String');
    if  isempty(file_name)
        save(['../Profiles/' 'empty_name' '.mat'], 'profile'); 
    else
        save(['../Profiles/' file_name '.mat'], 'profile'); 
    end
else
    disp('Note: no accumulated data')
    set(handles.ModelTxtPanel,'String', ['>> no accumulated data']);
end    


% ------------------------------------------------------------
% Callback of "plotting" panel
% ------------------------------------------------------------
function plot_TTS_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.TTS = [];
    param.record.TTS_time = [];
end

% ------------------------------------------------------------
function plot_push_TTS_Callback(h, eventdata, handles)
global param

if get(handles.plot_TTS,'Value') == 1 && size(param.record.TTS,2) > 1;
    plotting(param.record.TTS_time, param.record.TTS, 'TTS')    
else
    disp(['Note: no TTS data'])
    set(handles.ModelTxtPanel,'String', ['>> no TTS data']);        
end    

% ------------------------------------------------------------
function plot_ceil_t_Callback(h, eventdata, handles) 
global param

if get(h,'Value') == 1
    param.record.ceil_t = [];
    param.record.ceil_t_time = [];
end

% ------------------------------------------------------------
function plot_push_ceil_t_Callback(h, eventdata, handles)
global param

if get(handles.plot_ceil_t,'Value') == 1 && size(param.record.ceil_t,2) > 1;
    plotting(param.record.ceil_t_time, param.record.ceil_t, 'ceilling time')    
else
    disp(['Note: no ceilling time data'])
    set(handles.ModelTxtPanel,'String', ['>> no ceilling time data']);        
end    

% ------------------------------------------------------------
function plot_ceil_d_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.ceil_d = [];
    param.record.ceil_d_time = [];
end

% ------------------------------------------------------------
function plot_push_ceil_d_Callback(h, eventdata, handles)
global param

if get(handles.plot_ceil_d,'Value') == 1 && size(param.record.ceil_d,2) > 1;
    plotting(param.record.ceil_d_time, param.record.ceil_d, 'ceilling depth')
else
    disp(['Note: no ceilling depth data'])
    set(handles.ModelTxtPanel,'String', ['>> no ceilling depth data']);        
end    

% ------------------------------------------------------------
function plot_cnc_O2_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.cnc_O2 = [];
    param.record.cnc_O2_time = [];
end

% ------------------------------------------------------------
function plot_push_cnc_O2_Callback(h, eventdata, handles)
global param

if get(handles.plot_cnc_O2,'Value') == 1 && size(param.record.cnc_O2,2) > 1;
    plotting(param.record.cnc_O2_time, param.record.cnc_O2, 'O2 concentration')
else
    disp(['Note: no O2 concentration data'])
    set(handles.ModelTxtPanel,'String', ['>> no O2 concentration data']);        
end    

% ------------------------------------------------------------
function plot_cnc_He_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.cnc_He = [];
    param.record.cnc_He_time = [];
end

% ------------------------------------------------------------
function plot_push_cnc_He_Callback(h, eventdata, handles)
global param

if get(handles.plot_cnc_He,'Value') == 1 && size(param.record.cnc_He,2) > 1;
    plotting(param.record.cnc_He_time, param.record.cnc_He, 'He concentration')
else
    disp(['Note: no He concentration data'])
    set(handles.ModelTxtPanel,'String', ['>> no He concentration data']);        
end    

% ------------------------------------------------------------
function plot_cnc_N2_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.cnc_N2 = [];
    param.record.cnc_N2_time = [];
end

% ------------------------------------------------------------
function plot_push_cnc_N2_Callback(h, eventdata, handles)
global param

if get(handles.plot_cnc_N2,'Value') == 1 && size(param.record.cnc_N2,2) > 1;
    plotting(param.record.cnc_N2_time, param.record.cnc_N2, 'N2 concentration')
else
    disp(['Note: no N2 concentration data'])
    set(handles.ModelTxtPanel,'String', ['>> no N2 concentration data']);        
end    

% ------------------------------------------------------------
function plot_hum_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.hum = [];
    param.record.hum_time = [];
end

% ------------------------------------------------------------
function plot_push_hum_Callback(h, eventdata, handles)
global param

if get(handles.plot_hum,'Value') == 1 && size(param.record.hum,2) > 1;
    plotting(param.record.hum_time, param.record.hum, 'humidity')
else
    disp(['Note: no humidity data'])
    set(handles.ModelTxtPanel,'String', ['>> no humidity data']);        
end    

% ------------------------------------------------------------
function plot_temp_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.temp = [];
    param.record.temp_time = [];
end

% ------------------------------------------------------------
function plot_push_temp_Callback(h, eventdata, handles)
global param

if get(handles.plot_temp,'Value') == 1 && size(param.record.temp,2) > 1;
    plotting(param.record.temp_time, param.record.temp, 'temperature')
else
    disp(['Note: no temperature data'])
    set(handles.ModelTxtPanel,'String', ['>> no temperature data']);        
end    

% ------------------------------------------------------------
function plot_PPO2_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.PPO2 = [];
    param.record.PPO2_time = [];
end

% ------------------------------------------------------------
function plot_push_PPO2_Callback(h, eventdata, handles)
global param

if get(handles.plot_PPO2,'Value') == 1 && size(param.record.PPO2,2) > 1;
    plotting(param.record.PPO2_time, param.record.PPO2, 'PPO2')
else
    disp(['Note: no PPO2 data'])
    set(handles.ModelTxtPanel,'String', ['>> no PPO2 data']);        
end    

% ------------------------------------------------------------
function plot_PPCO2_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.PPCO2 = [];
    param.record.PPCO2_time = [];
end

% ------------------------------------------------------------
function plot_push_PPCO2_Callback(h, eventdata, handles)
global param

if get(handles.plot_PPCO2,'Value') == 1 && size(param.record.PPCO2,2) > 1;
    plotting(param.record.PPCO2_time, param.record.PPCO2, 'PPCO2')
else
    disp(['Note: no PPCO2 data'])
    set(handles.ModelTxtPanel,'String', ['>> no PPCO2 data']);        
end    

% ------------------------------------------------------------
function plot_EqN_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.EqN = [];
    param.record.EqN_time = [];
end

% ------------------------------------------------------------
function plot_push_EqN_Callback(h, eventdata, handles)
global param

if get(handles.plot_EqN,'Value') == 1 && size(param.record.EqN,2) > 1;
    plotting(param.record.EqN_time, param.record.EqN, 'EqN')
else
    disp(['Note: no EqN data'])
    set(handles.ModelTxtPanel,'String', ['>> no EqN data']);        
end    


% ------------------------------------------------------------
% Callback of "cnc: O2 He N2 CO2 res Total" panel
% ------------------------------------------------------------
function cnc_O2_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function cnc_He_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function cnc_N2_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function cnc_CO2_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function cnc_res_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function cnc_total_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function pr_BL_Callback(h, eventdata, handles)


% ------------------------------------------------------------
% Callback of "profiles" panel
% ------------------------------------------------------------
function profile_list_Callback(h, eventdata, handles)
global param
NewCell = get(h, 'String'); 
NewNum = get(h, 'Value');           % line number 
NewStruct = cell2struct(NewCell,'fields',size(NewCell,1));
param.profile_name = NewStruct(NewNum,1).fields;
load(['../Profiles/' param.profile_name '.mat'], 'profile');
param.profile = profile;

% ------------------------------------------------------------
function profile_plot_Callback(h, eventdata, handles)
global param

figure    
plot(param.profile.time ./60, param.profile.depth, 'r', 'linewidth',2');       
xlabel('Time, min');
ylabel('Depth, m');
title(['Profile of ../Profiles/' strrep(param.profile_name,'_',' ') '.mat']);
grid on


% ------------------------------------------------------------
% Callback of Automatic Diluent Valve (ADV) and Overpressure Valve (OPV)
% ------------------------------------------------------------
function ADV_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal) 
	NewVal = 25;    % default, (mbar)
elseif NewVal< 5
    NewVal = 5;     
elseif  NewVal > 50
    NewVal = 50;
end

set(h,'String',NewVal)
NewVal = NewVal/1000;
set_param('RB_TB/Environment/Diluent injection/Automatic Diluent Valve', 'InputValues', mat2str([-10000 NewVal NewVal+0.01 10000]))


% ------------------------------------------------------------
function OPV_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal) 
	NewVal = 25;    % default, (mbar)
elseif NewVal< 5
    NewVal = 5;     
elseif  NewVal > 50
    NewVal = 50;
end

set(h,'String',NewVal)

NewVal = NewVal/1000;
set_param('RB_TB/Environment/Overpressure/OverPressure Valve', 'InputValues', mat2str([-10000 NewVal NewVal+0.03 10000]))


% ------------------------------------------------------------
% Callback of "LEDs" panel
% ------------------------------------------------------------
function LED_O2_Callback(h, eventdata, handles)

function LED_CO2_Callback(h, eventdata, handles)


% end of main_RB_TB.m
