%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% disp_val.m     v2.0 Beta A
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov 
% 28 January 2006
%
% sends symbols to the MatLAB GUI > GUI_Re_Br_x.fig > panel: HANDSET
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function disp_val(value, treshold_min, treshold_max, alarm_text, order, last_symbol, handles) 

if  value > 10^order - 1     % overflow
    value = 10^order -1;    
    disp(['ALARM: ' alarm_text ' OVERFLOW']);    
    set(handles.txtPanel1,'String', ['ALARM: ' alarm_text ' OVERFLOW']);    
elseif value > treshold_max
    disp(['ALARM: ' alarm_text ' > MAX']);    
    set(handles.txtPanel1,'String', ['ALARM: ' alarm_text ' > MAX']);   
elseif value < treshold_min
    disp(['ALARM: ' alarm_text ' < MIN']);    
    set(handles.txtPanel1,'String', ['ALARM: ' alarm_text ' < MIN']);
end    

value = abs(value);
value_code = uint8(num2str(value));
value_str = int2str(value);

s = size(value_str, 2);
for i = 0:s-1
    do_switch(last_symbol-i, value_str(s-i), handles);
end

% reset the higher symbols 
if s < order 
    for i = s:order-1
        do_switch(last_symbol-i, 0, handles);
    end    
end

function do_switch(symbol_num, symbol, handles) 
switch symbol_num
    case 1
        set(handles.symbol1, 'String', symbol);       
    case 2
        set(handles.symbol2, 'String', symbol);            
    case 3
        set(handles.symbol3, 'String', symbol);       
    case 4
        set(handles.symbol4, 'String', symbol);       
    case 5
        set(handles.symbol5, 'String', symbol);       
    case 6
        set(handles.symbol6, 'String', symbol);       
    case 7
        set(handles.symbol7, 'String', symbol);       
    case 8
        set(handles.symbol8, 'String', symbol);       
    case 9
        set(handles.symbol9, 'String', symbol);       
    case 10
        set(handles.symbol10, 'String', symbol);       
    case 11
        set(handles.symbol11, 'String', symbol);       
    case 12
        set(handles.symbol12, 'String', symbol);       
    case 13
        set(handles.symbol13, 'String', symbol);       
    case 14
        set(handles.symbol14, 'String', symbol);       
    case 15
        set(handles.symbol15, 'String', symbol);       
    case 16
        set(handles.symbol16, 'String', symbol);       
    case 17
        set(handles.symbol17, 'String', symbol);       
    case 18
        set(handles.symbol18, 'String', symbol);       
    case 19
        set(handles.symbol19, 'String', symbol);       
    case 20
        set(handles.symbol20, 'String', symbol);       
    case 21
        set(handles.symbol21, 'String', symbol);       
    case 22
        set(handles.symbol22, 'String', symbol);       
    case 23
        set(handles.symbol23, 'String', symbol);       
    case 24
        set(handles.symbol24, 'String', symbol);       
    case 25
        set(handles.symbol25, 'String', symbol);       
    case 26
        set(handles.symbol26, 'String', symbol);       
    case 27
        set(handles.symbol27, 'String', symbol);       
    case 28
        set(handles.symbol28, 'String', symbol);       
    case 29
        set(handles.symbol29, 'String', symbol);       
    case 30
        set(handles.symbol30, 'String', symbol);       
    case 31
        set(handles.symbol31, 'String', symbol);       
    case 32
        set(handles.symbol32, 'String', symbol);       
    case 33
        set(handles.symbol33, 'String', symbol);       
    case 34
        set(handles.symbol34, 'String', symbol);       
    case 35
        set(handles.symbol35, 'String', symbol);       
    case 36
        set(handles.symbol36, 'String', symbol);       
    case 37
        set(handles.symbol37, 'String', symbol);       
    case 38
        set(handles.symbol38, 'String', symbol);       
    case 39
        set(handles.symbol39, 'String', symbol);       
    case 40
        set(handles.symbol40, 'String', symbol);       
    case 41
        set(handles.symbol41, 'String', symbol);       
    case 42
        set(handles.symbol42, 'String', symbol);       
    case 43
        set(handles.symbol43, 'String', symbol);       
    case 44
        set(handles.symbol44, 'String', symbol);       
    case 45
        set(handles.symbol45, 'String', symbol);       
    case 46
        set(handles.symbol46, 'String', symbol);       
    case 47
        set(handles.symbol47, 'String', symbol);       
    case 48
        set(handles.symbol48, 'String', symbol);       
    case 49
        set(handles.symbol49, 'String', symbol);       
    case 50
        set(handles.symbol50, 'String', symbol);       
    case 51
        set(handles.symbol51, 'String', symbol);       
    case 52
        set(handles.symbol52, 'String', symbol);       
    case 53
        set(handles.symbol53, 'String', symbol); 
    otherwise
        disp('Unknown GUI symbol number.')                
end

% end of disp_val.m