%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% read_depth_profile.m     v1.0 Beta A
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov 
% 8 January 2006
%
% loads Depth Profile table date for accelerated sim mode
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 


FILEIN = fopen('prof_txt_91_810.m'); 
line = fgets(FILEIN);

reading = 1;
last_line = 0;
index=1;
while(reading == 1)
    reading = reading - last_line;
    % read the first column with frequency data
    [s,f] = regexp(line, '^\s*[^\s]+\s+', 'once');
    profile.time(index)=sscanf(line(s(1):f(1)),'%e');
    % shift the line to start at first s-parameter entry
    line  = line(f+1:size(line,2));
    % scan the remaining s-parameter entried
    %[s,f] = regexp(line, '[^\s]+\s+[^\s]+\s+');
    [s,f] = regexp(line, '[^\s]+\s');
    a = sscanf(line(s(1):f(1)-2), '%e %e');
    
    profile.depth(index) =  a(1);     
    s=[];
    while(isempty(s) && ~feof(FILEIN))
        line=fgets(FILEIN);
        [s,f] = regexp(line, '[^\s]+\s+[^\s]+\s+');
        if feof(FILEIN)
            if max(size(s,2)) == 0
                reading = 0;
            else
                last_line = 1;
            end
        end
    end   
    index=index+1;
end

if 1 
    % Store all variable for later use
    save(['prof_91_810' '.mat'], 'profile');
end

% end of read_depth_profile






