%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% disp_val.m     v3.1d
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov 
% 23 October 2006
%
% sends symbols to the MatLAB GUI > GUI_Re_Br_x.fig > panel: HANDSET
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function disp_val(value, treshold_min, treshold_max, alarm_text, order, last_symbol, handles, clock) 

alarm = 0;
if  value > 10^order - 1     % overflow
    value = 10^order -1;    
    alarm = 1;
elseif value >= treshold_max
    alarm = 1;
elseif value < treshold_min
    alarm = 1;
end  

value = abs(value);
value_code = uint8(num2str(value));
value_str = int2str(value);

s = size(value_str, 2);
for i = 0:s-1
    do_switch(last_symbol-i, value_str(s-i), handles, alarm, clock);
end

% reset the higher symbols 
if strcmp(alarm_text,'123PPO2') || strcmp(alarm_text,'PPCO2')
    if strcmp(alarm_text,'123PPO2') || strcmp(alarm_text,'PPCO2')
        if s < order 
            for i = s:order-1
                do_switch(last_symbol-i, 0, handles, alarm, clock); 
            end    
        end
    end
else
    if strcmp(alarm_text,'T.T.S') || strcmp(alarm_text,'CEILING TIME') || strcmp(alarm_text,'DIVE TIME')
        if s == 1
            do_switch(last_symbol-s, '0', handles, alarm, clock);             
            s = 2;
        end
    end    
    if s < order 
        for i = s:order-1
            do_switch(last_symbol-i, ' ', handles, alarm, clock); 
        end    
    end    
end
function do_switch(symbol_num, symbol, handles, alarm, clock) 
switch symbol_num 
    case 1
        if alarm == 1
            if clock == 0
                set(handles.symbol1, 'FontWeight', 'bold')
            else
                set(handles.symbol1, 'FontWeight', 'light')
            end
        else
            set(handles.symbol1, 'FontWeight', 'bold')            
        end
        set(handles.symbol1, 'String', symbol)
    case 2
        if alarm == 1
            if clock == 0
                set(handles.symbol2, 'FontWeight', 'bold')
            else
                set(handles.symbol2, 'FontWeight', 'light')
            end
        else
            set(handles.symbol2, 'FontWeight', 'bold')            
        end
        set(handles.symbol2, 'String', symbol)
    case 3
        if alarm == 1
            if clock == 0
                set(handles.symbol3, 'FontWeight', 'bold')
            else
                set(handles.symbol3, 'FontWeight', 'light')
            end
        else
            set(handles.symbol3, 'FontWeight', 'bold')            
        end
        set(handles.symbol3, 'String', symbol)
    case 4
        if alarm == 1
            if clock == 0
                set(handles.symbol4, 'FontWeight', 'bold')
            else
                set(handles.symbol4, 'FontWeight', 'light')
            end
        else
            set(handles.symbol4, 'FontWeight', 'bold')            
        end
        set(handles.symbol4, 'String', symbol)
    case 5
        if alarm == 1
            if clock == 0
                set(handles.symbol5, 'FontWeight', 'bold')
            else
                set(handles.symbol5, 'FontWeight', 'light')
            end
        else
            set(handles.symbol5, 'FontWeight', 'bold')            
        end
        set(handles.symbol5, 'String', symbol)
    case 6
        if alarm == 1
            if clock == 0
                set(handles.symbol6, 'FontWeight', 'bold')
            else
                set(handles.symbol6, 'FontWeight', 'light')
            end
        else
            set(handles.symbol6, 'FontWeight', 'bold')            
        end
        set(handles.symbol6, 'String', symbol)
    case 7
        if alarm == 1
            if clock == 0
                set(handles.symbol7, 'FontWeight', 'bold')
            else
                set(handles.symbol7, 'FontWeight', 'light')
            end
        else
            set(handles.symbol7, 'FontWeight', 'bold')            
        end
        set(handles.symbol7, 'String', symbol)
    case 8
        if alarm == 1
            if clock == 0
                set(handles.symbol8, 'FontWeight', 'bold')
            else
                set(handles.symbol8, 'FontWeight', 'light')
            end
        else
            set(handles.symbol8, 'FontWeight', 'bold')            
        end
        set(handles.symbol8, 'String', symbol)
    case 9
        if alarm == 1
            if clock == 0
                set(handles.symbol9, 'FontWeight', 'bold')
            else
                set(handles.symbol9, 'FontWeight', 'light')
            end
        else
            set(handles.symbol9, 'FontWeight', 'bold')            
        end
        set(handles.symbol9, 'String', symbol)
    case 10
        if alarm == 1
            if clock == 0
                set(handles.symbol10, 'FontWeight', 'bold')
            else
                set(handles.symbol10, 'FontWeight', 'light')
            end
        else
            set(handles.symbol10, 'FontWeight', 'bold')            
        end
        set(handles.symbol10, 'String', symbol)
    case 11
        if alarm == 1
            if clock == 0
                set(handles.symbol11, 'FontWeight', 'bold')
            else
                set(handles.symbol11, 'FontWeight', 'light')
            end
        else
            set(handles.symbol11, 'FontWeight', 'bold')            
        end
        set(handles.symbol11, 'String', symbol)
    case 12
        if alarm == 1
            if clock == 0
                set(handles.symbol12, 'FontWeight', 'bold')
            else
                set(handles.symbol12, 'FontWeight', 'light')
            end
        else
            set(handles.symbol12, 'FontWeight', 'bold')            
        end
        set(handles.symbol12, 'String', symbol)
    case 13
        if alarm == 1
            if clock == 0
                set(handles.symbol13, 'FontWeight', 'bold')
            else
                set(handles.symbol13, 'FontWeight', 'light')
            end
        else
            set(handles.symbol13, 'FontWeight', 'bold')            
        end
        set(handles.symbol13, 'String', symbol)
    case 14
        if alarm == 1
            if clock == 0
                set(handles.symbol14, 'FontWeight', 'bold')
            else
                set(handles.symbol14, 'FontWeight', 'light')
            end
        else
            set(handles.symbol14, 'FontWeight', 'bold')            
        end
        set(handles.symbol14, 'String', symbol)
    case 15
        if alarm == 1
            if clock == 0
                set(handles.symbol15, 'FontWeight', 'bold')
            else
                set(handles.symbol15, 'FontWeight', 'light')
            end
        else
            set(handles.symbol15, 'FontWeight', 'bold')            
        end
        set(handles.symbol15, 'String', symbol)
    case 16
        if alarm == 1
            if clock == 0
                set(handles.symbol16, 'FontWeight', 'bold')
            else
                set(handles.symbol16, 'FontWeight', 'light')
            end
        else
            set(handles.symbol16, 'FontWeight', 'bold')            
        end
        set(handles.symbol16, 'String', symbol)
    case 17
        if alarm == 1
            if clock == 0
                set(handles.symbol17, 'FontWeight', 'bold')
            else
                set(handles.symbol17, 'FontWeight', 'light')
            end
        else
            set(handles.symbol17, 'FontWeight', 'bold')            
        end
        set(handles.symbol17, 'String', symbol)
    case 18
        if alarm == 1
            if clock == 0
                set(handles.symbol18, 'FontWeight', 'bold')
            else
                set(handles.symbol18, 'FontWeight', 'light')
            end
        else
            set(handles.symbol18, 'FontWeight', 'bold')            
        end
        set(handles.symbol18, 'String', symbol)
    case 19
        if alarm == 1
            if clock == 0
                set(handles.symbol19, 'FontWeight', 'bold')
            else
                set(handles.symbol19, 'FontWeight', 'light')
            end
        else
            set(handles.symbol19, 'FontWeight', 'bold')            
        end
        set(handles.symbol19, 'String', symbol)
    case 20
        if alarm == 1
            if clock == 0
                set(handles.symbol20, 'FontWeight', 'bold')
            else
                set(handles.symbol20, 'FontWeight', 'light')
            end
        else
            set(handles.symbol20, 'FontWeight', 'bold')            
        end
        set(handles.symbol20, 'String', symbol)
    case 21
        if alarm == 1
            if clock == 0
                set(handles.symbol21, 'FontWeight', 'bold')
            else
                set(handles.symbol21, 'FontWeight', 'light')
            end
        else
            set(handles.symbol21, 'FontWeight', 'bold')            
        end
        set(handles.symbol21, 'String', symbol)
    case 22
        if alarm == 1
            if clock == 0
                set(handles.symbol22, 'FontWeight', 'bold')
            else
                set(handles.symbol22, 'FontWeight', 'light')
            end
        else
            set(handles.symbol22, 'FontWeight', 'bold')            
        end
        set(handles.symbol22, 'String', symbol)
    case 23
        if alarm == 1
            if clock == 0
                set(handles.symbol23, 'FontWeight', 'bold')
            else
                set(handles.symbol23, 'FontWeight', 'light')
            end
        else
            set(handles.symbol23, 'FontWeight', 'bold')            
        end
        set(handles.symbol23, 'String', symbol)
    case 24
        if alarm == 1
            if clock == 0
                set(handles.symbol24, 'FontWeight', 'bold')
            else
                set(handles.symbol24, 'FontWeight', 'light')
            end
        else
            set(handles.symbol24, 'FontWeight', 'bold')            
        end
        set(handles.symbol24, 'String', symbol)
    case 25
        if alarm == 1
            if clock == 0
                set(handles.symbol25, 'FontWeight', 'bold')
            else
                set(handles.symbol25, 'FontWeight', 'light')
            end
        else
            set(handles.symbol25, 'FontWeight', 'bold')            
        end
        set(handles.symbol25, 'String', symbol)
    case 26
        if alarm == 1
            if clock == 0
                set(handles.symbol26, 'FontWeight', 'bold')
            else
                set(handles.symbol26, 'FontWeight', 'light')
            end
        else
            set(handles.symbol26, 'FontWeight', 'bold')            
        end
        set(handles.symbol26, 'String', symbol)
    case 27
        if alarm == 1
            if clock == 0
                set(handles.symbol27, 'FontWeight', 'bold')
            else
                set(handles.symbol27, 'FontWeight', 'light')
            end
        else
            set(handles.symbol27, 'FontWeight', 'bold')            
        end
        set(handles.symbol27, 'String', symbol)
    case 28
        if alarm == 1
            if clock == 0
                set(handles.symbol28, 'FontWeight', 'bold')
            else
                set(handles.symbol28, 'FontWeight', 'light')
            end
        else
            set(handles.symbol28, 'FontWeight', 'bold')            
        end
        set(handles.symbol28, 'String', symbol)
    case 29
        if alarm == 1
            if clock == 0
                set(handles.symbol29, 'FontWeight', 'bold')
            else
                set(handles.symbol29, 'FontWeight', 'light')
            end
        else
            set(handles.symbol29, 'FontWeight', 'bold')            
        end
        set(handles.symbol29, 'String', symbol)
    case 30
        if alarm == 1
            if clock == 0
                set(handles.symbol30, 'FontWeight', 'bold')
            else
                set(handles.symbol30, 'FontWeight', 'light')
            end
        else
            set(handles.symbol30, 'FontWeight', 'bold')            
        end
        set(handles.symbol30, 'String', symbol)
    case 31
        if alarm == 1
            if clock == 0
                set(handles.symbol31, 'FontWeight', 'bold')
            else
                set(handles.symbol31, 'FontWeight', 'light')
            end
        else
            set(handles.symbol31, 'FontWeight', 'bold')            
        end
        set(handles.symbol31, 'String', symbol)
    case 32
        if alarm == 1
            if clock == 0
                set(handles.symbol32, 'FontWeight', 'bold')
            else
                set(handles.symbol32, 'FontWeight', 'light')
            end
        else
            set(handles.symbol32, 'FontWeight', 'bold')            
        end
        set(handles.symbol32, 'String', symbol)
    case 33
        if alarm == 1
            if clock == 0
                set(handles.symbol33, 'FontWeight', 'bold')
            else
                set(handles.symbol33, 'FontWeight', 'light')
            end
        else
            set(handles.symbol33, 'FontWeight', 'bold')            
        end
        set(handles.symbol33, 'String', symbol)
    case 34
        if alarm == 1
            if clock == 0
                set(handles.symbol34, 'FontWeight', 'bold')
            else
                set(handles.symbol34, 'FontWeight', 'light')
            end
        else
            set(handles.symbol34, 'FontWeight', 'bold')            
        end
        set(handles.symbol34, 'String', symbol)
    case 35
        if alarm == 1
            if clock == 0
                set(handles.symbol35, 'FontWeight', 'bold')
            else
                set(handles.symbol35, 'FontWeight', 'light')
            end
        else
            set(handles.symbol35, 'FontWeight', 'bold')            
        end
        set(handles.symbol35, 'String', symbol)
    case 36
        if alarm == 1
            if clock == 0
                set(handles.symbol36, 'FontWeight', 'bold')
            else
                set(handles.symbol36, 'FontWeight', 'light')
            end
        else
            set(handles.symbol36, 'FontWeight', 'bold')            
        end
        set(handles.symbol36, 'String', symbol)
    case 37
        if alarm == 1
            if clock == 0
                set(handles.symbol37, 'FontWeight', 'bold')
            else
                set(handles.symbol37, 'FontWeight', 'light')
            end
        else
            set(handles.symbol37, 'FontWeight', 'bold')            
        end
        set(handles.symbol37, 'String', symbol)
    case 38
        if alarm == 1
            if clock == 0
                set(handles.symbol38, 'FontWeight', 'bold')
            else
                set(handles.symbol38, 'FontWeight', 'light')
            end
        else
            set(handles.symbol38, 'FontWeight', 'bold')            
        end
        set(handles.symbol38, 'String', symbol)
    case 39
        if alarm == 1
            if clock == 0
                set(handles.symbol39, 'FontWeight', 'bold')
            else
                set(handles.symbol39, 'FontWeight', 'light')
            end
        else
            set(handles.symbol39, 'FontWeight', 'bold')            
        end
        set(handles.symbol39, 'String', symbol)
    case 40
        if alarm == 1
            if clock == 0
                set(handles.symbol40, 'FontWeight', 'bold')
            else
                set(handles.symbol40, 'FontWeight', 'light')
            end
        else
            set(handles.symbol40, 'FontWeight', 'bold')            
        end
        set(handles.symbol40, 'String', symbol)
    case 41
        if alarm == 1
            if clock == 0
                set(handles.symbol41, 'FontWeight', 'bold')
            else
                set(handles.symbol41, 'FontWeight', 'light')
            end
        else
            set(handles.symbol41, 'FontWeight', 'bold')            
        end
        set(handles.symbol41, 'String', symbol)
    case 42
        if alarm == 1
            if clock == 0
                set(handles.symbol42, 'FontWeight', 'bold')
            else
                set(handles.symbol42, 'FontWeight', 'light')
            end
        else
            set(handles.symbol42, 'FontWeight', 'bold')            
        end
        set(handles.symbol42, 'String', symbol)
    case 43
        if alarm == 1
            if clock == 0
                set(handles.symbol43, 'FontWeight', 'bold')
            else
                set(handles.symbol43, 'FontWeight', 'light')
            end
        else
            set(handles.symbol43, 'FontWeight', 'bold')            
        end
        set(handles.symbol43, 'String', symbol)
    case 44
        if alarm == 1
            if clock == 0
                set(handles.symbol44, 'FontWeight', 'bold')
            else
                set(handles.symbol44, 'FontWeight', 'light')
            end
        else
            set(handles.symbol44, 'FontWeight', 'bold')            
        end
        set(handles.symbol44, 'String', symbol)
    case 45
        if alarm == 1
            if clock == 0
                set(handles.symbol45, 'FontWeight', 'bold')
            else
                set(handles.symbol45, 'FontWeight', 'light')
            end
        else
            set(handles.symbol45, 'FontWeight', 'bold')            
        end
        set(handles.symbol45, 'String', symbol)
    case 46
        if alarm == 1
            if clock == 0
                set(handles.symbol46, 'FontWeight', 'bold')
            else
                set(handles.symbol46, 'FontWeight', 'light')
            end
        else
            set(handles.symbol46, 'FontWeight', 'bold')            
        end
        set(handles.symbol46, 'String', symbol)
    case 47
        if alarm == 1
            if clock == 0
                set(handles.symbol47, 'FontWeight', 'bold')
            else
                set(handles.symbol47, 'FontWeight', 'light')
            end
        else
            set(handles.symbol47, 'FontWeight', 'bold')            
        end
        set(handles.symbol47, 'String', symbol)
    case 48
        if alarm == 1
            if clock == 0
                set(handles.symbol48, 'FontWeight', 'bold')
            else
                set(handles.symbol48, 'FontWeight', 'light')
            end
        else
            set(handles.symbol48, 'FontWeight', 'bold')            
        end
        set(handles.symbol48, 'String', symbol)
    case 49
        if alarm == 1
            if clock == 0
                set(handles.symbol49, 'FontWeight', 'bold')
            else
                set(handles.symbol49, 'FontWeight', 'light')
            end
        else
            set(handles.symbol49, 'FontWeight', 'bold')            
        end
        set(handles.symbol49, 'String', symbol)
    case 50
        if alarm == 1
            if clock == 0
                set(handles.symbol50, 'FontWeight', 'bold')
            else
                set(handles.symbol50, 'FontWeight', 'light')
            end
        else
            set(handles.symbol50, 'FontWeight', 'bold')            
        end
        set(handles.symbol50, 'String', symbol)
    case 51
        if alarm == 1
            if clock == 0
                set(handles.symbol51, 'FontWeight', 'bold')
            else
                set(handles.symbol51, 'FontWeight', 'light')
            end
        else
            set(handles.symbol51, 'FontWeight', 'bold')            
        end
        set(handles.symbol51, 'String', symbol)
    case 52
        if alarm == 1
            if clock == 0
                set(handles.symbol52, 'FontWeight', 'bold')
            else
                set(handles.symbol52, 'FontWeight', 'light')
            end
        else
            set(handles.symbol52, 'FontWeight', 'bold')            
        end
        set(handles.symbol52, 'String', symbol)
    case 53
        if alarm == 1
            if clock == 0
                set(handles.symbol53, 'FontWeight', 'bold')
            else
                set(handles.symbol53, 'FontWeight', 'light')
            end
        else
            set(handles.symbol53, 'FontWeight', 'bold')            
        end
        set(handles.symbol53, 'String', symbol)
    otherwise
        disp('Unknown GUI symbol number.')                
end

% end of disp_val.m