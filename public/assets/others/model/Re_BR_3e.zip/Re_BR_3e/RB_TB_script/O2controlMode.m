%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% O2controlMode.m     v3.0c 
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov 
% 03 May 2006
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function O2controlMode(handles)
global param

NewCell = get(handles.O2control, 'String'); 
NewNum = get(handles.O2control, 'Value');
NewStruct = cell2struct(NewCell,'fields',3);
switch NewStruct(NewNum,1).fields
    case('Predict Bang') 
        set_param('RB_TB/Controller/O2_control_select', 'Value', '1')
    case('Bang-Bang')
        set_param('RB_TB/Controller/O2_control_select', 'Value', '2')
    case('Analogue')
        set_param('RB_TB/Controller/O2_control_select', 'Value', '3')            
    case('Control Off')
        set_param('RB_TB/Controller/O2_control_select', 'Value', '4')
end 

% end of O2controlMode.m