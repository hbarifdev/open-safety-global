%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% do_none_fault.m     v3.1d
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov
% 18 December 2006
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function do_none_fault(handles)
global param

set_param('RB_TB/Environment/Breathing gas mixture injection/fault_Oxygen Cylinder Empty', 'Value', '0')
% Oxygen Cylinder Switched Off  = fault of Oxygen Solenoid Stuck: '3'
% Oxygen First Stage Failure = fault of Oxygen Solenoid Stuck: '3'
set_param('RB_TB/Environment/Breathing gas mixture injection/fault_Oxygen First Stage Over Pressure', 'Value', '0')        
set_param('RB_TB/Environment/Breathing gas mixture injection/valve_mode', 'Value',...
    num2str(get(handles.O2NotCompValve,'Value')))     % restore after Fault: Oxygen First Stage Over Pressure
set_param('RB_TB/Environment/Breathing gas mixture injection/fault_Oxygen Hose Leaks', 'Value', '0')

% Reset faults: 
%- Oxygen Cylinder Switched Off
%- Oxygen First Stage Failure
%- Oxygen Solenoid Stuck Closed
%- Oxygen Solenoid Stuck Open
%- Oxygen Manual Injector Failure
O2controlMode(handles) 

set_param('RB_TB/Environment/Breathing gas mixture injection/fault_Wrong Gas in Oxygen cylinder', 'Value', '0')        
    
set_param('RB_TB/Environment/Diluent injection/fault_Diluent Cylinder Empty', 'Value', '0')
set_param('RB_TB/Environment/Diluent injection/fault_Diluent Cylinder Switched Off', 'Value', '0')
set_param('RB_TB/Environment/Diluent injection/fault_Diluent First Stage Over Pressure', 'Value', '0')
set_param('RB_TB/Environment/Diluent injection/fault_Diluent Hose Leaks', 'Value', '0')
set_param('RB_TB/Environment/Diluent injection/fault_Diluent Manual Injector Failure', 'Value', '0')  
set_param('RB_TB/Environment/Diluent injection/fault_Wrong Gas in Diluent Cylinder', 'Value', '0')    
    
set_param('RB_TB/Controller/add_bat_discharge', 'Value', '0')   % reset fault of Battery Low
set_param('RB_TB/Controller/capacity_bat', 'Value',...          % restore battery capacity after fault of Battery Failure
    num2str(str2num(get(handles.capacity_bat,'String'))*3600))  
set_param('RB_TB/Environment/discharge_bat', 'Value',...        % reset fault of Battery Bounce
    get(handles.discharge_bat,'String'))              
set_param('RB_TB/fault_Handset Failure', 'Value', '0')

% restore O2 sensors
set_param('RB_TB/Sensors/PPO2_1_state', 'Value', '0')
set_param('RB_TB/Sensors/PPO2_2_state', 'Value', '0')
set_param('RB_TB/Sensors/PPO2_3_state', 'Value', '0')
set_param('RB_TB/Sensors/PPO2_4_state', 'Value', '0')
set_param('RB_TB/Sensors/PPO2 sensor1/TS_PPO2_REC', 'gain', '1/1.5')
set_param('RB_TB/Sensors/PPO2 sensor2/TS_PPO2_REC', 'gain', '1/1.75')
set_param('RB_TB/Sensors/PPO2 sensor3/TS_PPO2_REC', 'gain', '1/2')
set_param('RB_TB/Sensors/PPO2 sensor4/TS_PPO2_REC', 'gain', '1/2.5')

set_param('RB_TB/Environment/fault_Water on O2 sensor face', 'Value', '0')
set_param('RB_TB/Environment/CO2 balance/SCRB_LT', 'Value',...  % restore scrubber Life-Time after fault of Scrubber Exhausted
    get(handles.lifetime_scrb,'String'))                        % hour
set_param('RB_TB/Environment/CO2 balance/K_G', 'gain', '0.00185')
set_param('RB_TB/Environment/CO2 balance/Scrubber Bypass_vol_ini', 'Value', '0')
set_param('RB_TB/Environment/CO2 balance/fault_Loop Food', 'Value', '0')

set(handles.RateAsc, 'string', '0')
if strcmp(param.units,'metric')
    set(handles.m_ft_asc_rate_max, 'String', '-110')    
    set(handles.RateAscSlider, 'Min', -110)
else
    set(handles.m_ft_asc_rate_max, 'String', '-360')
    set(handles.RateAscSlider, 'Min', -360)
end
set(handles.RateAscSlider, 'Value', 0)

% end of do_none_fault