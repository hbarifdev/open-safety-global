
%set(handles.PauseButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
a1 = 0.835294;
a2 = 0.815686;
a3 = 0.784314;
for i = 0:0.01:0.15
    a = [a1 a2+i a3]
    set(handles.PauseButton, 'BackgroundColor', a)
    i
end