%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% do_fault.m     v2.0 Beta A
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov
% 15 March 2006
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function do_fault(fault_name, param, handles)

switch fault_name
    case('None') 
        do_none_fault(handles)
    case('Oxygen Cylinder Empty')
        set_param('RB_TB/Environment/O2 bottle injection/fault_Oxygen Cylinder Empty', 'Value', '1')
    case('Oxygen Cylinder Switched Off')
        set_param('RB_TB/Controller/O2_control_select', 'Value', '4')
    case('Oxygen First Stage Failure') % total instantaneous loss of all O2
        set_param('RB_TB/Controller/O2_control_select', 'Value', '4')
    case('Oxygen First Stage Over Pressure') 
        % With an O2 solenoid injector, this sets the solenoid ON permanently.
        % With an orifice injector, it causes the O2 to be injected faster than it should be    
        set_param('RB_TB/Environment/O2 bottle injection/valve_mode', 'Value', '1')  % set not-compensated valve mode
        set_param('RB_TB/Environment/O2 bottle injection/fault_Oxygen First Stage Over Pressure', 'Value', '1')
    case('Oxygen House Leaks') % the content of the cylinder goes down fast (empty in 5 minutes)    
        set_param('RB_TB/Environment/O2 bottle injection/fault_Oxygen House Leaks', 'Value', '1')
    case('Oxygen Solenoid Stuck Open')
        set_param('RB_TB/Controller/O2_control_select', 'Value', '5')
    case('Oxygen Solenoid Stuck Closed')      
        set_param('RB_TB/Controller/O2_control_select', 'Value', '4')
    case('Oxygen Manual Injector Failure') % it fails shut
        set_param('RB_TB/Controller/O2_control_select', 'Value', '5')
    case('Wrong Gas in Oxygen cylinder') % O2 cylinder becomes DIL
        set_param('RB_TB/Environment/O2 bottle injection/fault_Wrong Gas in Oxygen cylinder', 'Value', '1')
    case('Diluent Cylinder Empty')
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent Cylinder Empty', 'Value', '1')
    case('Diluent Cylinder Switched Off')
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent Cylinder Switched Off', 'Value', '1')
    case('Diluent First Stage Failure') % total instantaneous loss of all DIL
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent Cylinder Switched Off', 'Value', '1')
    case('Diluent First Stage Over Pressure') % leaks dil into the loop
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent First Stage Over Pressure', 'Value', '1')
    case('Diluent House Leaks') % the content of the cylinder goes down fast (empty in 5 minutes)
        set_param('RB_TB/Environment/Diluent injection/Leak', 'Value', '2.5')        
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent House Leaks', 'Value', '1')
    case('Diluent Manual Injector Failure') % it fails shut
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent Manual Injector Failure', 'Value', '1')
    case('Wrong Gas in Diluent Cylinder') % DIL becomes air
        set_param('RB_TB/Environment/Diluent injection/fault_Wrong Gas in Diluent Cylinder', 'Value', '1')
    case('Alternate Air Source Free Flow') % Loss of dil in 2 minutes
        set_param('RB_TB/Environment/Diluent injection/Leak', 'Value', '6.25')    
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent House Leaks', 'Value', '1')
    case('Battery Low') % the time left while the electronics works is cut to 5 minutes
        NewVal = str2num(get(handles.capacity_bat,'String'))*3600 - param.discharge_bat - 300*str2num(get(handles.discharge_bat,'String'));
        set_param('RB_TB/Controller/add_bat_discharge', 'Value', num2str(NewVal))
    case('Battery Failure') % Total failure
        set_param('RB_TB/Controller/capacity_bat', 'Value', '1') % it must be > 0
    case('Battery Bounce') % Causes the electronics to reset and restart
        set_param('RB_TB/Environment/discharge_bat', 'Value', '5000') % mA,  Av. batttery discharge (electronic supply current is from 10 to 60 mA av. 10 secs   
    case('Handset Failure') % Cable is cut to the handset. All information in the handset is lost
        set_param('RB_TB/fault_Handset Failure', 'Value', '1')
    case('Handsets Switched off') % Cannot happen underwater. it just closes down the run.
        set_param('RB_TB/fault_Handset Failure', 'Value', '1')
    case('Loose Connection to Sensor') % one O2 sensor has zero output
        set_param('RB_TB/Sensors/fault_Loose Connection to Sensor', 'Value', '1')
    case('Single Cell Failure') % one O2 sensor is 5mV output
        set_param('RB_TB/Sensors/fault_Single Cell Failure', 'Value', '1')
    case('Two Cell Failure') % two O2 sensors are 5mV output
        set_param('RB_TB/Sensors/fault_Single Cell Failure', 'Value', '1')    
        set_param('RB_TB/Sensors/fault_Two Cell Failure', 'Value', '1')
    case('Condensation On Face') % O2 sensors is oscillating fluctuating low with a period of about 1 min
        set_param('RB_TB/Environment/fault_Condensation On Face', 'Value', '1')
    case('Pressure Unequalisation') % Fix the pressure in loop to the ambient then continue dive
        disp('Note: The Fault is not connected');
        set(handles.ModelTxtPanel,'String', ['>> The Fault is not connected']);
        wavplay(param.DING_sound.y,param.DING_sound.Fs)        
    case('Scrubber Exhausted') % PPCO2 climbs at 1% per minute
        set_param('RB_TB/Environment/CO2 balance/SCRB_LT', 'Value', num2str(param.sum_CO2/96))
    case('Scrubber Bypass') % PPCO2 climbs at 4% per minute
        set_param('RB_TB/Environment/CO2 balance/SCRB_LT', 'Value', num2str(param.sum_CO2/96))
        set_param('RB_TB/Environment/CO2 balance/K_G', 'gain', '0.0074')
    case('Loop Food') % PPCO2 becomes 10% (0.1)
        set_param('RB_TB/Environment/CO2 balance/SCRB_LT', 'Value', num2str(param.sum_CO2/96))  % SCRB is OFF
        set_param('RB_TB/Environment/CO2 balance/K_G', 'gain', '0.07')    
        set_param('RB_TB/Environment/CO2 balance/fault_Loop Food', 'Value', '1')
    case('BC Failure') % Diver is sinking (increasing depth)
        disp('Note: The Fault is not connected');
        set(handles.ModelTxtPanel,'String', ['>> The Fault is not connected']);
        wavplay(param.DING_sound.y,param.DING_sound.Fs)        
    case('Harness Failure') % Diver is on surface in 1 minute
        disp('Note: The Fault is not connected');
        set(handles.ModelTxtPanel,'String', ['>> The Fault is not connected']);
        wavplay(param.DING_sound.y,param.DING_sound.Fs)        
end


% end of do_fault.m