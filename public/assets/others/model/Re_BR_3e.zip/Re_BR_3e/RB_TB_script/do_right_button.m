%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% do_right_button.m     v3.0c
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov
% 03 May 2006
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function do_right_button(handles)
global sim_state param alarm

if ~strcmp(sim_state,'pause') && ~strcmp(sim_state,'run')

    if ~strcmp(param.date_mode,'change') && ~strcmp(param.predive,'on')
        param.scroll_cnt_opt = param.scroll_cnt_opt + 1;
    end
    if param.scroll_cnt_opt == 12;
        param.scroll_cnt_opt = 2;
        param.predive = 'off'; 
        param.predive_num = 0;
    end

    switch param.scroll_cnt_opt
        case 1
            system_self_test(handles)
            param.predive = 'off';
            param.predive_num = 0;
        case 2 
            if strcmp(param.predive, 'off')
                set(handles.txtPanel1,'String', ['  Open Revolution eCCR  ']);
                set(handles.txtPanel2,'String', ['<- Predive    Options ->']);
            else
                param.predive_num = param.predive_num + 1;
                switch param.predive_num
                    case 1
                        set(handles.txtPanel1,'String', ['Create neg pressure!    '])  
                        set(handles.txtPanel2,'String', ['                 Done ->'])  
                    case 2
                        % test 
                        t_1sec = timer('StartDelay', 1,'TimerFcn','disp('''')');  % set delay
                        t = timer('StartDelay', 0.5,'TimerFcn','disp('''')');  % set delay
                        set(handles.txtPanel1,'String', ['Fail: Not enough O2 flow'])  
                        set(handles.txtPanel2,'String', ['Try again. Suck harder! '])
                        start(t)
                        wait(t)
                        set(handles.txtPanel1,'String', ['Checking for no leaks ..'])  
                        for i = 1:15
                            set(handles.txtPanel2,'String', ['          Wait!       ' num2str(i)])
                            start(t_1sec)
                            wait(t_1sec)
                        end
                        set(handles.txtPanel1,'String', ['Fail: Loop not air-tight'])  
                        set(handles.txtPanel2,'String', ['        NO DIVE!        '])
                        start(t)
                        wait(t)
                        set(handles.txtPanel2,'String', ['Continuing the Demo ... '])
                        start(t)
                        wait(t)
                        set(handles.txtPanel1,'String', ['Now filling loop with O2'])  
                        for i = 1:30
                            set(handles.txtPanel2,'String', ['          Wait!       ' num2str(i)])
                            start(t_1sec)
                            wait(t_1sec)
                        end
                        set(handles.txtPanel1,'String', ['Fail: Not enough O2 flow'])  
                        set(handles.txtPanel2,'String', ['        NO DIVE!        '])
                        start(t)
                        wait(t)
                        set(handles.txtPanel2,'String', ['Continuing the Demo ... '])
                        start(t)
                        wait(t)
                        set(handles.txtPanel1,'String', ['Checking for no leaks ..'])  
                        for i = 1:15
                            set(handles.txtPanel2,'String', ['          Wait!       ' num2str(i)])
                            start(t_1sec)
                            wait(t_1sec)
                        end
                        set(handles.txtPanel2,'String', ['Dilution factor    2539'])
                        start(t_1sec)
                        wait(t_1sec)
                        set(handles.txtPanel1,'String', ['  : O2 Sensor Voltages  '])  
                        set(handles.txtPanel2,'String', ['A=98, B=46, C= 98, D= 0mV'])
                        start(t_1sec)
                        wait(t_1sec)  
                        
                        delete(t) % delate the DELAY timer
                        delete(t_1sec) % delate the DELAY timer
                        set(handles.txtPanel1,'String', ['Again make neg pressure!'])  
                        set(handles.txtPanel2,'String', ['                 Done ->'])  
                    case 3
                        set(handles.txtPanel1,'String', ['Neg pressure too weak   '])  
                        set(handles.txtPanel2,'String', ['Try again. Suck harder! '])  
                    case 4
                        set(handles.txtPanel1,'String', ['Now turn on DIL gas!    '])  
                        set(handles.txtPanel2,'String', ['                 Done ->'])  
                    case 5
                        set(handles.txtPanel1,'String', ['ADV being checked ......'])  
                        set(handles.txtPanel2,'String', ['                 Done ->']) 
                        
                        t_1sec = timer('StartDelay', 1,'TimerFcn','disp('''')');  % set delay
                        for i = 1:3
                            set(handles.txtPanel2,'String', ['          Wait!       ' num2str(i)])
                            start(t_1sec)
                            wait(t_1sec)
                        end                       
                        delete(t_1sec) % delate the DELAY timer                        
                        set(handles.txtPanel1,'String', ['Turn O2 back on!        '])  
                        set(handles.txtPanel2,'String', ['                 Done ->'])  
                    case 7
                        set(handles.txtPanel1,'String', ['Breathe loop before dive'])  
                        set(handles.txtPanel2,'String', ['<- Dive Now   Options ->'])  
                        param.predive = 'off';
                end
            end
        case 3 
            set(handles.txtPanel1,'String', ['Only basic display shown']);
            set(handles.txtPanel2,'String', ['<- Change        Next ->']);             
        case 4 
            set(handles.txtPanel1,'String', ['Dive Log                ']);
            set(handles.txtPanel2,'String', ['<- Select        Next ->']);             
        case 5 
            set(handles.txtPanel1,'String', ['Dive Planner            ']);
            set(handles.txtPanel2,'String', ['<- Select        Next ->']);             
        case 6 
            set(handles.txtPanel1,'String', ['PPO2 Setpoint = ' num2str(param.setPPO2)]) % from 0.7 up to 1.4
            set(handles.txtPanel2,'String', ['<- Change        Next ->'])
        case 7
            if strcmp(param.date_mode,'change')
                param.date_index = param.date_index + 1;
                if param.date_index == 6
                    param.date_mode = 'off'; 
                    param.date_index = 0;                    
                    set(handles.txtPanel2,'String', ['<- Change        Next ->'])                    
                end
                switch param.date_index
                    case 2
                        set(handles.txtPanel2,'String', ['<- Incr Month    Next ->']) 
                    case 3
                        set(handles.txtPanel2,'String', ['<- Incr Day      Next ->']) 
                    case 4
                        set(handles.txtPanel2,'String', ['<- Incr Hours    Next ->']) 
                    case 5
                        set(handles.txtPanel2,'String', ['<- Incr Minutes  Next ->']) 
                end
            else
                set(handles.txtPanel1,'String', ['Date:  ' param.date])
                set(handles.txtPanel2,'String', ['<- Change        Next ->'])
            end
        case 8
            set(handles.txtPanel1,'String', ['  Units are ' param.units])
            set(handles.txtPanel2,'String', ['<- Change        Next ->'])
        case 9
            set(handles.txtPanel1,'String', ['HUD set to Non-invasive '])
            set(handles.txtPanel2,'String', ['<- Change        Next ->'])           
        case 10
            set(handles.txtPanel1,'String', ['Backlight on for 30 secs'])
            set(handles.txtPanel2,'String', ['<- Change        Next ->'])          
        case 11
            set(handles.txtPanel1,'String', [' CNS is in ' param.CNSmode ' mode'])
            set(handles.txtPanel2,'String', ['<- Change        Next ->'])
    end
else
    alarm_size = size(alarm.message_up,2);
    if alarm_size > 24;
        alarm.message_up = alarm.message_up(1:alarm_size-24);
        alarm.message_down = alarm.message_down(1:alarm_size-24);        
        set(handles.txtPanel1,'String', [alarm.message_up(alarm_size-47:alarm_size-24)]);
        set(handles.txtPanel2,'String', [alarm.message_down(alarm_size-47:alarm_size-24)]);        
    end
    if alarm_size == 24
        alarm.message_up = '';
        alarm.message_down = '';        
        set(handles.txtPanel1,'String', ['                        ']);
        set(handles.txtPanel2,'String', ['                        ']);        
    end
end

% end of do_right_button.m
