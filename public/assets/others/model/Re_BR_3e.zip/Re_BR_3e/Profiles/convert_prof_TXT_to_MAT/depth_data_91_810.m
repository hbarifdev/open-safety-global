function [sys,x0,str,ts]=depth_data(t,x,u,flag)
%LIMINTM Limited integrator implementation.
%   Example M-file S-function implementing a continuous limited integrator
%   where the output is bounded by lower bound (LB) and upper bound (UB)
%   with initial conditions (XI).
%   
%   See sfuntmpl.m for a general S-function template.
%
%   See also SFUNTMPL.
    
%   Copyright 1990-2002 The MathWorks, Inc.
%   $Revision: 1.17 $



switch flag

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0         
    [sys,x0,str,ts] = mdlInitializeSizes;

%    disp(['Running depth_data_91_810']);
    
  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1
    sys = mdlDerivatives(t,x,u);

  %%%%%%%%%%%%%%%%%%%%%%%%
  % Update and Terminate %
  %%%%%%%%%%%%%%%%%%%%%%%%
  case {2,9}
    sys = []; % do nothing

  %%%%%%%%%%
  % Output %
  %%%%%%%%%%
  case 3
    sys = mdlOutputs(t,x,u); 

  otherwise
    error(['unhandled flag = ',num2str(flag)]);
end

% end limintm

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts] = mdlInitializeSizes(lb,ub,xi)

sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 0;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);
str = [];
x0  = [];
ts  = [0 0];   % sample time: [period, offset]

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Compute derivatives for continuous states.
%=============================================================================
%
function sys = mdlDerivatives(t,x,u)

sys = [];

% end mdlDerivatives

%
%=============================================================================
% mdlOutputs
% Return the output vector for the S-function
%=============================================================================
%
function sys = mdlOutputs(t,x,u)

data_in = [0	0;
30	3;
60	4;
90	5;
120	7;
150	8;
180	8.5;
210	8.5;
240	8.5;
270	9.5;
300	11.5;
330	17;
360	22.5;
390	27;
420	32;
450	34;
480	34;
510	37;
540	42.5;
570	51;
600	59;
630	63;
660	68;
690	71;
720	74;
750	76.5;
780	78;
810	91;
840	79;
870	80;
900	75;
930	72.5;
960	70.5;
990	67.7;
1020	65.5;
1050	64;
1080	62.5;
1110	60;
1140	57;
1170	54;
1200	51;
1230	49.7;
1260	49.7;
1290	51;
1320	50.5;
1350	49;
1380	46.7;
1410	44;
1440	42.5;
1470	40;
1500	39;
1530	38.5;
1560	37;
1590	35.5;
1620	35.5;
1650	35;
1680	35;
1710	35.5;
1740	34.5;
1770	32.5;
1800	31;
1830	30;
1860	28;
1890	27.5;
1920	27;
1950	26.5;
1980	26.5;
2010	25.5;
2040	24;
2070	22.5;
2100	22;
2130	22;
2160	22;
2190	19.5;
2220	18;
2250	15.5;
2280	13;
2310	13;
2340	13;
2370	11.5;
2400	9.5;
2430	9;
2460	9.5;
2490	9.5;
2520	9.5;
2550	9;
2580	9;
2610	8.5;
2640	8.5;
2670	8;
2700	7.5;
2730	8;
2760	8;
2790	8;
2820	8.5;
2850	8.5;
2880	8.5;
2910	8.5;
2940	8.5;
2970	8.5;
3000	8.5;
3030	8.5;
3060	8.5;
3090	8.5;
3120	7.5;
3150	7;
3180	7;
3210	7;
3240	7;
3270	7;
3300	7.5;
3330	7;
3360	7;
3390	7;
3420	7;
3450	7;
3480	7;
3510	6.5;
3540	6.5;
3570	6.5;
3600	7;
3630	7;
3660	7;
3690	7.5;
3720	7;
3750	7;
3780	7;
3810	7;
3840	7;
3870	7;
3900	7;
3930	7;
3960	7;
3990	6.5;
4020	6.5;
4050	6.5;
4080	6.5;
4110	6.5;
4140	6.5;
4170	6.5;
4200	6.5;
4230	6.5;
4260	6.5;
4290	6.5;
4320	5.7;
4350	3;
4380	0];

%data_in(:,1)=data_in(:,1)./100;

sys = interp1q(data_in(:,1), data_in(:,2), t);
%t 

% end mdlOutputs