%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% main_RB_TB.m     v3.1e
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov
% 12 March 2008
%
% calculates 
% - Bang-bang control;
% - the Behlmann ZH16-L (N2 and He) decompression parameters
% - rebreather environment and breathibg loop parameters
% - GUI dispay parameters
%
% the main module runs by GUI via the console. 
% The model runs RB_TB.mdl and sends the results to GUI 
% each clock 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

% ------------------------------------------------------------
function varargout = main_RB_TB(varargin)
 
% Begin initialization code - DO NOT EDIT 
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @main_RB_TB_OpeningFcn, ...
                   'gui_OutputFcn',  @main_RB_TB_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1}); 
end 
 
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else 
    gui_mainfcn(gui_State, varargin{:});
end

% ------------------------------------------------------------
% --- Executes just before main_RB_TB is made visible.
% ------------------------------------------------------------
function main_RB_TB_OpeningFcn(h, eventdata, handles, varargin)

model_open(handles) 
handles.output = h; 
guidata(h, handles);

% ------------------------------------------------------------
% --- Outputs from this function are returned to the command line.
% ------------------------------------------------------------
function varargout = main_RB_TB_OutputFcn(h, eventdata, handles)
% Get default command line output from handles structure
varargout{1} = handles.output;

% ------------------------------------------------------------
function model_open(handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define param structure 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global param alarm option

% load profile data 
NewCell = get(handles.profile_list, 'String'); 
NewNum = get(handles.profile_list, 'Value');    % line number 
NewStruct = cell2struct(NewCell,'fields',size(NewCell,1));
param.profile_name = NewStruct(NewNum,1).fields;
load(['../Profiles/' param.profile_name '.mat'], 'profile'); 

param.profile = profile;
param.t_Initial = 0; 

% load sound data 
load(['../Sounds/' 'DING_sound' '.mat'], 'y', 'Fs');
param.DING_sound.y = y;
param.DING_sound.Fs = Fs;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define the RT timer 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
out = timerfindall;      % Find timer objects used before
delete(out);            % Remove a timer object from memory 

% Create new timer object
rt_timer = timer('TimerFcn', 'do_mode', 'ExecutionMode', 'FixedRate'); 
rt_timer.Period = 1;               % Specifies the delay, in seconds, between executions
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% GUI Initial State
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
clock = 0; % bold symbols
disp_val(0, 0, 959, 'T.T.S', 3, 3,handles, clock);                % T.T.S, h:mm:ss
disp_val(0, 0, 95959, 'CEILING TIME', 5, 8, handles, clock);      % CEILING TIME, h:mm:ss 
disp_val(0, 0, 600, 'CEILING', 3, 11, handles, clock);            % CEILING,  m/ft
disp_val(0, 0, 600, 'DEPTH', 3, 14, handles, clock);              % DEPTH, m/ft
disp_val(0, 0, 95959, 'DIVE TIME', 5, 19, handles, clock);        % DIVE TIME, h:mm:ss
disp_val(0, 0, 100, 'CNS', 2, 21, handles, clock);                 % CNS, %
disp_val(0, -100, 100, 'ASC RATE', 2, 23, handles, clock);          % ASC RATE,  m/min   ft/min
disp_val(0, 0, 100, 'O2', 2, 25, handles, clock);                  % O2, %
disp_val(0, 0, 100, 'He', 2, 27, handles, clock);                  % He, %
disp_val(0, 0, 100, 'N2', 2, 29, handles, clock);                  % N2, %
disp_val(0, 0, 100, 'SCRB', 2, 31, handles, clock);             % SCRB, %
disp_val(0, 0, 100, 'BAT', 2, 33, handles, clock);              % BAT, %
disp_val(0, 0, 100, 'HUM', 2, 35, handles, clock);                % HUM, %
disp_val(0, 0, 45, 'TEMP', 2, 37, handles, clock);               % TEMP, C/F
disp_val(0, 0, 159, '123PPO2', 3, 40, handles, clock);            % 123PPO2, ATA
disp_val(0, 0, 3, 'PPCO2', 2, 42, handles, clock);                % PPCO2, ATA
disp_val(0, 0, 999, 'EqND', 3, 45, handles, clock);               % EqND, m/ft
disp_val(0, 0, 1200, 'DIL CILINDER', 4, 49, handles, clock);       % DIL CILINDER, BPASRI 
disp_val(0, 0, 1200, 'O2 CILINDER', 4, 53, handles, clock);        % O2 CILINDER, BPASRI   

cnc_O2_atm = 20.9476;               % cnc O2 sea level (101325 Pa, wed 15%) = 20.9476%;
cnc_CO2_atm = 0.0314;               % cnc CO2 sea level (101325 Pa, wed 15%) = 0.0314%;
cnc_N2_atm = 78.084;                % cnc N2 sea level (101325 Pa, wed 15%) = 78.084%;
cnc_He_atm = 0.000524;              % cnc He sea level (101325 Pa, wed 15%) = 0.000524;
cnc_res_atm = 0.9365;               % cnc Res sea level (101325 Pa, wed 15%) = 0.9365;
cnc_total_atm = cnc_O2_atm + cnc_CO2_atm + cnc_N2_atm + cnc_He_atm + cnc_res_atm;
% Note: 
% cnc_total_atm must be = 100%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Display atm parameters in GUI 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
set(handles.cnc_O2, 'String', num2str(round(100*cnc_O2_atm)/100)) 
set(handles.cnc_CO2, 'String', num2str(round(100*cnc_CO2_atm)/100))
set(handles.cnc_N2, 'String', num2str(round(100*cnc_N2_atm)/100))
set(handles.cnc_He, 'String', num2str(round(100*cnc_He_atm)/100))
set(handles.cnc_res, 'String', num2str(round(100*cnc_res_atm)/100))
set(handles.cnc_total, 'String', num2str(round(10*cnc_total_atm)/10))

if  isempty(find_system('Name', 'RB_TB')),
	open_system('RB_TB'); 
     
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Define ini model parameters of the RB_TB blocks    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    set_param('RB_TB/Environment/O2 balance/cnc_O2_atm', 'Value',...
        num2str(cnc_O2_atm/100))         % cnc O2 sea level (101325 Pa, wed 15%) = 20.9476%;
    set_param('RB_TB/Environment/CO2 balance/cnc_CO2_atm', 'Value',...
        num2str(cnc_CO2_atm/100))         % cnc CO2 sea level (101325 Pa, wed 15%) = 0.0314%;
    set_param('RB_TB/Controller/deco_N2/Palveola/cnc_N2_atm', 'Value',...
        num2str(cnc_N2_atm/100))         % cnc N2 sea level (101325 Pa, wed 15%) = 78.084%;
    set_param('RB_TB/Controller/deco_He/Palveola/cnc_He_atm', 'Value',...
        num2str(cnc_He_atm/100))         % cnc He sea level (101325 Pa, wed 15%) = 0.000524;
    set_param('RB_TB/Environment/Residual gas balance/cnc_res_atm', 'Value',...
        num2str(cnc_res_atm/100))         % cnc Res sea level (101325 Pa, wed 15%) = 0.9365;
   
    set_param('RB_TB/Controller/RT delay1', 'SampleTime', '0.1')        % RT_CLK = 0.1;
    set_param('RB_TB/Controller/RT delay2', 'SampleTime', '0.1')        % RT_CLK = 0.1;
    set_param('RB_TB/Controller/RT delay3', 'SampleTime', '0.1')        % RT_CLK = 0.1;    
    set_param('RB_TB/Controller/temp_breathing', 'Value', '33')         % temp_air_sea_level = 37;        
    set_param('RB_TB/Environment/temp_water_handset', 'Value', '24')    % temp_water_handset = 24;
    set_param('RB_TB/Environment/wet', 'Value', '0.99')                 % wet = 99% in the semiclosed rebreather;
    set_param('RB_TB/Controller/deco_N2/RQ', 'Value', '0.9')            % RQ = 0.9;    
  
    param.deco_rate_asc = -9/60;     % m/s
    % following two params must be equal to each other
    set_param('RB_TB/Controller/deco_N2/While_Iterator/rate_asc_deco', 'Value',...
        num2str(-6*param.deco_rate_asc))            % rate_asc_deco = 0.9; % -9 meter/min
    set_param('RB_TB/Controller/deco_He/While_Iterator/rate_asc_deco', 'Value',...
        num2str(-6*param.deco_rate_asc))            % rate_asc_deco = 0.9; % -9 meter/min
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Put  values from the GUI into the Block dialogs
    % and define model parameters    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    set_param('RB_TB/Environment/Breathing gas mixture injection/size_O2_bottle', 'Value',...
        get(handles.sizeO2bottle,'String'))     % (bar)
    set_param('RB_TB/Environment/Breathing gas mixture injection/pr_O2_bottle_ini', 'Value',...
        get(handles.prO2bottle,'String'))       % (bar)
    
    set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/size_dil_bottle1', 'Value',...
        get(handles.sizeDILbottle1,'String'))   % (litre)
    set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/size_dil_bottle2', 'Value',...
        get(handles.sizeDILbottle2,'String'))   % (litre)    
    set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/pr_dil_bottle1_ini', 'Value',...
        get(handles.prDILbottle1,'String'))     % (bar)
    set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/pr_dil_bottle2_ini', 'Value',...
        get(handles.prDILbottle2,'String'))     % (bar)
    set_param('RB_TB/Environment/Diluent injection/cnc_O2_dil_bottle1', 'Value',...
        get(handles.cncO2DILbottle1,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_O2_dil_bottle2', 'Value',...
        get(handles.cncO2DILbottle2,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle1', 'Value',...
        get(handles.cncHeDILbottle1,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle2', 'Value',...
        get(handles.cncHeDILbottle2,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle1', 'Value',...
        get(handles.cncN2DILbottle1,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle2', 'Value',...
        get(handles.cncN2DILbottle2,'String'))  % (%)
    set_param('RB_TB/Environment/Diluent injection/gas_mix_num', 'Value',...
        num2str(get(handles.GasMixPopupmenu,'Value')))           % 1, or 2
        
    set_param('RB_TB/Environment/Breathing gas mixture injection/cnc_O2_breathing_mixture_bottle', 'Value',...
        get(handles.cncO2_O2bottle,'String'))  % (%)
    set_param('RB_TB/Environment/Breathing gas mixture injection/cnc_He_breathing_mixture_bottle', 'Value',...
        get(handles.cncHe_O2bottle,'String'))  % (%)
    set_param('RB_TB/Environment/Breathing gas mixture injection/cnc_N2_breathing_mixture_bottle', 'Value',...
        get(handles.cncN2_O2bottle,'String'))  % (%)
    
    br_freq = str2num(get(handles.br_freq,'String'));   % (min-1)
    rate_met = str2num(get(handles.rate_met,'String')); % (l/min)
    set_param('RB_TB/Breathing/rate_metabolic', 'Amplitude', num2str(rate_met/60))
    set_param('RB_TB/Breathing/rate_metabolic', 'Bias', num2str(rate_met/60))    
    set_param('RB_TB/Breathing/rate_metabolic', 'Frequency', num2str(br_freq*pi/30))
    set_param('RB_TB/Environment/CO2 balance/rate_respiratory', 'Value',...
        get(handles.rate_resp,'String'))         % (l/min)

    set_param('RB_TB/Environment/BL_size/tidal_volume', 'Amplitude',...
        get(handles.TidalVol,'String'))
    set_param('RB_TB/Environment/BL_size/tidal_volume', 'Frequency', num2str(br_freq*pi/30))

    vol_BL_Dead = get(handles.VolBLDead,'String');
    set_param('RB_TB/Environment/BL_size/vol_dead','Value',vol_BL_Dead) % (litre) 
    set_param('RB_TB/Environment/BL_size/min_BL_size','Threshold',vol_BL_Dead) 
    vol_Cntrlng = get(handles.VolCntrlng,'String');
    set_param('RB_TB/Environment/BL_size/vol_cntrlng','Value',vol_Cntrlng) % (litre)
    max_BL_size = str2num(vol_BL_Dead)+str2num(vol_Cntrlng);
    set_param('RB_TB/Environment/BL_size/max_BL_size','Threshold',num2str(max_BL_size)) 
        
    set_param('RB_TB/Controller/capacity_bat', 'Value',...
        num2str(str2num(get(handles.capacity_bat,'String'))*3600))  % mAsecond 
    set_param('RB_TB/Environment/discharge_bat', 'Value',...
        get(handles.discharge_bat,'String'))        % mA     
    set_param('RB_TB/Environment/CO2 balance/SCRB_LT', 'Value',...
        get(handles.lifetime_scrb,'String'))        % hour       
    set_param('RB_TB/Controller/deco_mode', 'Value',...
        num2str(get(handles.presize_deco,'Value')+1))           % deco precize mode ON/OFF   
    set_param('RB_TB/Controller/CNS/CNS_mode', 'Value',...
        num2str(get(handles.CNC_control,'Value')))           % CNC mode ON/OFF 
        
    set_param('RB_TB/Environment/Breathing gas mixture injection/valve_mode', 'Value',...
        num2str(get(handles.O2NotCompValve,'Value')))     % mode of the O2 pressure reduction valve
    set_param('RB_TB/Environment/Breathing gas mixture injection/diam_orifice', 'Value',...
        num2str(get(handles.orifice_size,'String')))     % orifice size
    valve_pressure = str2num(get(handles.ADV,'String'))/1000;
    set_param('RB_TB/Environment/Diluent injection/Automatic Diluent Valve', 'InputValues', mat2str([-1000 valve_pressure 0.04 0.3 1000]))
    valve_pressure = str2num(get(handles.OPV,'String'))/1000; 
    set_param('RB_TB/Environment/Overpressure/OverPressure Valve', 'InputValues', mat2str([-1000 valve_pressure 0.04 0.3 1000]))
    set_param('RB_TB/Environment/Breathing gas mixture injection/pr_IM_O2_valve', 'Value',...
        get(handles.IMprO2valve,'String'))          % (bar)
    set_param('RB_TB/Sensors/Pressure_ambient Sensor/depth_range', 'Value',...
        get(handles.depth_max_edit,'String'))       % (bar)  
    
    % reset O2 and Dil manual injectors
    set(handles.O2_in_Manual, 'String', '75')
    set_param('RB_TB/Environment/Breathing gas mixture injection/O2_in_flow', 'Value', '75')
    set(handles.Dil_in_Manual, 'String', '75')
    set_param('RB_TB/Environment/Diluent injection/Dil_in_flow', 'Value', '75')
    set(handles.O2_button,'Value',0);
    set(handles.Dil_button,'Value',0);    
    set_param('RB_TB/Environment/Breathing gas mixture injection/O2_in_manual', 'Value', '0')
    set_param('RB_TB/Environment/Diluent injection/Dil_in_manual', 'Value', '0')    
 
    %set control mode
    NewCell = get(handles.O2control, 'String'); 
    NewNum = get(handles.O2control, 'Value');
    NewStruct = cell2struct(NewCell,'fields',3);
    switch NewStruct(NewNum,1).fields
        case('Predict Bang') 
            set_param('RB_TB/Controller/O2_control_select', 'Value', '1')
        case('Bang-Bang')
            set_param('RB_TB/Controller/O2_control_select', 'Value', '2')
        case('Analogue')
            set_param('RB_TB/Controller/O2_control_select', 'Value', '3')            
        case('Control Off')
            set_param('RB_TB/Controller/O2_control_select', 'Value', '4')
    end   
    
    % reset DCS_risk
    param.DCS = 0;   
    
    % load the latest option data
    load(['../RB_TB_script/' 'RB_option' '.mat'], 'option');

    param.setPPO2 = option.setPPO2; 

    set_param('RB_TB/Controller/PPO2_set', 'InputValues',['[' num2str([0 round(((param.setPPO2/0.7)*10-10)*10)/10+0.0001 1000]) ']'])
    set_param('RB_TB/Controller/PPO2_set', 'OutputValues',['[' num2str([0.7 param.setPPO2+0.0001 param.setPPO2+0.0002]) ']'])
    
    param.CNSmode = option.CNSmode;
    if strcmp(param.CNSmode, 'Conservative')
        param.CNSmode = 'Aggressive';
        set_param('RB_TB/Controller/CNS/add_PPO2', 'Value', '0.2')
    else
        param.CNSmode = 'Conservative';
        set_param('RB_TB/Controller/CNS/add_PPO2', 'Value', '0.3')                
    end
    
    param.date = option.date;    
    param.units = option.units;
    if strcmp(param.units, 'metric')
        
        set(handles.m_ft_depth,'String','m')
        set(handles.m_ft_ceiling, 'String', 'm')
        set(handles.m_ft_asc_rate, 'String', 'm/min')
        set(handles.m_ft_EqND, 'String', 'm')
        set(handles.m_ft_depth_down, 'String', '(m)')

        set(handles.RateAscSlider, 'Min', -110)
        set(handles.RateAscSlider, 'Max', 55) 
        set(handles.RateAscSlider, 'Value', 0)

        set(handles.m_ft_asc_rate_down, 'String', '(m/min)')
        set(handles.m_ft_asc_rate_max, 'String', '-110')
        set(handles.m_ft_des_rate_max, 'String', '55')

        set_param('RB_TB/Controller/ft_m_sw', 'Value', '0')

        %%%%%%%%%%%%%%%  C/F > C
        set(handles.C_F,'String','C')  
        set_param('RB_TB/Controller/C_F_sw', 'Value', '0')

        %%%%%%%%%%%%%%%  bar/psi > bar
        set(handles.bar_psi1, 'String','b')
        set(handles.bar_psi2, 'String','a')
        set(handles.bar_psi3, 'String','r')  

        set_param('RB_TB/Controller/bar_psi_sw', 'Value', '0')

    else
        set(handles.m_ft_depth,'String','ft')
        set(handles.m_ft_ceiling, 'String', 'ft')    
        set(handles.m_ft_asc_rate, 'String', 'ft/min')
        set(handles.m_ft_EqND, 'String', 'ft')
        set(handles.m_ft_depth_down, 'String', '(ft)')

        NewVal = round(600/0.3048); 
        set(handles.depth_max_edit, 'String', num2str(NewVal));
        set(handles.DepthSlider, 'Max', NewVal)
        set(handles.DepthSlider, 'Value', 0)        

        set(handles.RateAscSlider, 'Min', -360)
        set(handles.RateAscSlider, 'Max', 180) 
        set(handles.RateAscSlider, 'Value', 0)

        set(handles.m_ft_asc_rate_down, 'String', '(ft/min)')
        set(handles.m_ft_asc_rate_max, 'String', '-360')
        set(handles.m_ft_des_rate_max, 'String', '180')

        set_param('RB_TB/Controller/ft_m_sw', 'Value', '1')

        %%%%%%%%%%%%%%%  C/F > F
        set(handles.C_F,'String','F')          
        set_param('RB_TB/Controller/C_F_sw', 'Value', '1')

        %%%%%%%%%%%%%%%  bar/psi > psi
        set(handles.bar_psi1, 'String','p')
        set(handles.bar_psi2, 'String','s')
        set(handles.bar_psi3, 'String','i')  

        set_param('RB_TB/Controller/bar_psi_sw', 'Value', '1')
    end    
    param.CNSmode = option.CNSmode;    
    
    % params of the selftest    
    param.date_mode = 'off';    
    param.date_index = 0; 
    param.predive = 'off';
    param.predive_num = 0;
    param.scroll_cnt_opt = 0;

    set(handles.txtPanel1,'String', ['  Open Revolution eCCR  ']);
    set(handles.txtPanel2,'String', ['       Self Test ->']); 
    
    
    % reset faults and O2 control mode   
    do_none_fault(handles)
    
    % ALARM reset by right button ">>"
    alarm.message_up = ''; 
    alarm.message_down = '';     
    alarm.NoReturn = 0;   
    alarm.CNS = 0;
end

% ------------------------------------------------------------
% Callback of configuration
% ------------------------------------------------------------

function sizeO2bottle_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 3;     % default, (litre)
elseif NewVal< 1
    NewVal = 1;
elseif NewVal>20
    NewVal = 20;	
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Breathing gas mixture injection/size_O2_bottle', 'Value', num2str(NewVal))
    
% ------------------------------------------------------------
function prO2bottle_Callback(h, eventdata, handles)
 
NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 230;     % default, (bar)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 300
    NewVal = 300; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Breathing gas mixture injection/pr_O2_bottle_ini', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function cncO2DILbottle1_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 20;     % default, (%)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 100
    NewVal = 100; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Diluent injection/cnc_O2_dil_bottle1', 'Value', num2str(NewVal))

cnc_He_dil_bottle1 = str2num(get(handles.cncHeDILbottle1,'String'));
cnc_N2_dil_bottle1 = str2num(get(handles.cncN2DILbottle1,'String'));

if  (NewVal+cnc_He_dil_bottle1>100),	
    cnc_He_dil_bottle1 = 100 - NewVal;
    set(handles.cncHeDILbottle1,'String',cnc_He_dil_bottle1) 
    set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle1', 'Value', num2str(cnc_He_dil_bottle1))    
    cnc_N2_dil_bottle1 = 0;    
    set(handles.cncN2DILbottle1,'String',cnc_N2_dil_bottle1)    
else    
    cnc_N2_dil_bottle1 = 100 - NewVal - cnc_He_dil_bottle1;
    set(handles.cncN2DILbottle1,'String',cnc_N2_dil_bottle1)    
end

set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle1', 'Value', num2str(cnc_N2_dil_bottle1))

% ------------------------------------------------------------
function cncHeDILbottle1_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

cnc_O2_dil_bottle1 = str2num(get(handles.cncO2DILbottle1,'String'));
cnc_N2_dil_bottle1 = str2num(get(handles.cncN2DILbottle1,'String'));

if  isempty(NewVal) || isnan(NewVal) || (NewVal< 0) || (NewVal>100-cnc_O2_dil_bottle1),
	NewVal = 0;         % default (%)
    cnc_N2_dil_bottle1 = 100 - cnc_O2_dil_bottle1;
else
    cnc_N2_dil_bottle1 = 100 - cnc_O2_dil_bottle1 - NewVal;    
end

set(h,'String',NewVal)
set(handles.cncN2DILbottle1,'String',cnc_N2_dil_bottle1)
set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle1', 'Value', num2str(NewVal))
set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle1', 'Value', num2str(cnc_N2_dil_bottle1))

% ------------------------------------------------------------
function cncN2DILbottle1_Callback(h, eventdata, handles)

cnc_O2_dil_bottle1 = str2num(get(handles.cncO2DILbottle1,'String'));
cnc_He_dil_bottle1 = str2num(get(handles.cncHeDILbottle1,'String'));

NewVal = 100 - cnc_O2_dil_bottle1 - cnc_He_dil_bottle1;

set(h,'String',NewVal)       

% ------------------------------------------------------------
function prDILbottle1_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 230;     % default, (bar)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 300
    NewVal = 300; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/pr_dil_bottle1_ini', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function sizeDILbottle1_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 3;     % default, (litre)
elseif NewVal< 1
    NewVal = 1;     
elseif  NewVal > 20
    NewVal = 20; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/size_dil_bottle1', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function cncO2DILbottle2_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 32;     % default, (%)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 100
    NewVal = 100; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Diluent injection/cnc_O2_dil_bottle2', 'Value', num2str(NewVal))


cnc_He_dil_bottle2 = str2num(get(handles.cncHeDILbottle2,'String'));
cnc_N2_dil_bottle2 = str2num(get(handles.cncN2DILbottle2,'String'));

if  (NewVal+cnc_He_dil_bottle2>100),	
    cnc_He_dil_bottle2 = 100 - NewVal;
    set(handles.cncHeDILbottle2,'String',cnc_He_dil_bottle2) 
    set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle2', 'Value', num2str(cnc_He_dil_bottle2))    
    cnc_N2_dil_bottle2 = 0;    
    set(handles.cncN2DILbottle2,'String',cnc_N2_dil_bottle2)    
else    
    cnc_N2_dil_bottle2 = 100 - NewVal - cnc_He_dil_bottle2;
    set(handles.cncN2DILbottle2,'String',cnc_N2_dil_bottle2)    
end

set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle2', 'Value', num2str(cnc_N2_dil_bottle2))

% ------------------------------------------------------------
function cncHeDILbottle2_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

cnc_O2_dil_bottle2 = str2num(get(handles.cncO2DILbottle2,'String'));
cnc_N2_dil_bottle2 = str2num(get(handles.cncN2DILbottle2,'String'));

if  isempty(NewVal) || isnan(NewVal) || (NewVal< 0) || (NewVal>100-cnc_O2_dil_bottle2),
	NewVal = 0;         % default (%)
    cnc_N2_dil_bottle2 = 100 - cnc_O2_dil_bottle2;
else
    cnc_N2_dil_bottle2 = 100 - cnc_O2_dil_bottle2 - NewVal;    
end

set(h,'String',NewVal)
set(handles.cncN2DILbottle2,'String',cnc_N2_dil_bottle2)
set_param('RB_TB/Environment/Diluent injection/cnc_He_dil_bottle2', 'Value', num2str(NewVal))
set_param('RB_TB/Environment/Diluent injection/cnc_N2_dil_bottle2', 'Value', num2str(cnc_N2_dil_bottle2))

% ------------------------------------------------------------
function cncN2DILbottle2_Callback(h, eventdata, handles)

cnc_O2_dil_bottle2 = str2num(get(handles.cncO2DILbottle2,'String'));
cnc_He_dil_bottle2 = str2num(get(handles.cncHeDILbottle2,'String'));

NewVal = 100 - cnc_O2_dil_bottle2 - cnc_He_dil_bottle2;

set(h,'String',NewVal) 

% ------------------------------------------------------------
function prDILbottle2_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 230;     % default, (bar)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 300
    NewVal = 300; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/pr_dil_bottle2_ini', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function sizeDILbottle2_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 3;     % default, (litre)
elseif NewVal< 1
    NewVal = 1;     
elseif  NewVal > 20
    NewVal = 20; 
end

set(h,'String',NewVal)
set_param('RB_TB/Environment/Diluent injection/dil_bottle_pressure/size_dil_bottle2', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function cncO2_O2bottle_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 100;     % default, (%)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 100
    NewVal = 100; 
end

set(h,'String',NewVal) 
set_param('RB_TB/Environment/Breathing gas mixture injection/cnc_O2_breathing_mixture_bottle', 'Value', num2str(NewVal))

cnc_He_O2bottle = str2num(get(handles.cncHe_O2bottle,'String'));
cnc_N2_O2bottle = str2num(get(handles.cncN2_O2bottle,'String'));

if  (NewVal+cnc_He_O2bottle>100),	
    cnc_He_O2bottle = 100 - NewVal;
    set(handles.cncHe_O2bottle,'String',cnc_He_O2bottle) 
    set_param('RB_TB/Environment/Breathing gas mixture injection/cnc_He_breathing_mixture_bottle', 'Value', num2str(cnc_He_O2bottle))    
    cnc_N2_O2bottle = 0;    
    set(handles.cncN2_O2bottle,'String',cnc_N2_O2bottle)    
else    
    cnc_N2_O2bottle = 100 - NewVal - cnc_He_O2bottle;
    set(handles.cncN2_O2bottle,'String',cnc_N2_O2bottle)    
end

set_param('RB_TB/Environment/Breathing gas mixture injection/cnc_N2_breathing_mixture_bottle', 'Value', num2str(cnc_N2_O2bottle))
set_param('RB_TB/Environment/Breathing gas mixture injection/cnc_He_breathing_mixture_bottle', 'Value', num2str(cnc_He_O2bottle))

% ------------------------------------------------------------
function cncHe_O2bottle_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

cnc_O2_O2bottle = str2num(get(handles.cncO2_O2bottle,'String'));
cnc_N2_O2bottle = str2num(get(handles.cncN2_O2bottle,'String'));

if  isempty(NewVal) || isnan(NewVal) || (NewVal< 0) || (NewVal>100-cnc_O2_O2bottle),
	NewVal = 0;         % default (%)
    cnc_N2_O2bottle = 100 - cnc_O2_O2bottle;
else
    cnc_N2_O2bottle = 100 - cnc_O2_O2bottle - NewVal;    
end

set(h,'String',NewVal)
set(handles.cncN2_O2bottle,'String',cnc_N2_O2bottle)
set_param('RB_TB/Environment/Diluent injection/cnc_He_O2bottle', 'Value', num2str(NewVal))
set_param('RB_TB/Environment/Diluent injection/cnc_N2_O2bottle', 'Value', num2str(cnc_N2_O2bottle))

% ------------------------------------------------------------
function cncN2_O2bottle_Callback(h, eventdata, handles)

cnc_O2_O2bottle = str2num(get(handles.cncO2_O2bottle,'String'));
cnc_He_O2bottle = str2num(get(handles.cncHe_O2bottle,'String'));
NewVal = 100 - cnc_O2_O2bottle - cnc_He_O2bottle;

set(h,'String',NewVal) 

% ------------------------------------------------------------
% Callback of input dive parameters
% ------------------------------------------------------------
function RateAsc_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal); 

if get(handles.m_ft_depth, 'Value') == 0  
    if  isempty(NewVal) || isnan(NewVal)
        NewVal = get(handles.RateAscSlider,'Value'); 	
    elseif NewVal < -110
        NewVal = -110;     
    elseif  NewVal > 55
        NewVal = 55; 
    end 
else
    if  isempty(NewVal) || isnan(NewVal)
        NewVal = get(handles.RateAscSlider,'Value'); 	
    elseif NewVal < -360
        NewVal = -360;
    elseif  NewVal > 180
        NewVal = 180; 
    end 
end

NewVal = round(10*NewVal)/10;
set(h,'String',NewVal)
set(handles.RateAscSlider,'Value',NewVal)	
  
% ------------------------------------------------------------
function RateAscSlider_Callback(h, eventdata, handles)

NewVal = round(10*get(h,'Value'))/10; 
set(handles.RateAsc,'String',NewVal)

% ------------------------------------------------------------
function Depth_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

depthMAX = str2num(get(handles.depth_max_edit, 'String'));
if  isempty(NewVal) || isnan(NewVal)
	NewVal = get(handles.DepthSlider,'Value'); 	
elseif NewVal < 0
    NewVal = 0;     
elseif  NewVal > depthMAX
    NewVal = depthMAX; 
end

NewVal = round(10*NewVal)/10; 
set(h,'String',NewVal)
set(handles.DepthSlider,'Value',NewVal)

% ------------------------------------------------------------
function DepthSlider_Callback(h, eventdata, handles)

NewVal = round(10*get(h,'Value'))/10;

set(handles.Depth,'String',NewVal)

% ------------------------------------------------------------
function rate_resp_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
rate_resp = str2num(NewStrVal);

if  isempty(rate_resp) || isnan(rate_resp)
    rate_resp = 22.5; 	
elseif rate_resp < 0
    rate_resp = 0;     
elseif  rate_resp > 90
    rate_resp = 90; 
end

rate_resp = round(10*rate_resp)/10;
set(h,'String',rate_resp)

if get(handles.rb_standard,'Value') == 1
    
    rate_CO2 = round(rate_resp/2.5)/10;      % /25
    set(handles.rate_CO2,'String',rate_CO2)    
    rate_met = round(rate_CO2/0.009)/100;      % /0.9
    set(handles.rate_met,'String',rate_met)
    
    if rate_CO2 <= 0.4 
        br_freq = rate_CO2*25;
    elseif rate_CO2 <= 0.9
        br_freq = (15-10)*(rate_CO2-0.4)/(0.9-0.4) + 10;
    elseif rate_CO2 <= 1.6    
        br_freq = (20 - 15)*(rate_CO2-0.9)/(1.6 - 0.9) + 15;
    elseif rate_CO2 <= 2.5
        br_freq = (25 - 20)*(rate_CO2-1.6)/(2.5 - 1.6) + 20;
    elseif rate_CO2 <= 3
        br_freq = 25;            
    else
        br_freq = (30 - 25)*(rate_CO2-3)/(3.6 - 3) + 25;
    end

    br_freq = round(br_freq);      
    set(handles.br_freq,'String',br_freq)

    if rate_resp < 1.3
        TidalVol = 0;
    else
        TidalVol = round(10*rate_resp/br_freq)/10;
    end
    set(handles.TidalVol,'String',TidalVol)
else
    if rate_resp == 0
        rate_met = 0;     
        set(handles.rate_met,'String',num2str(rate_met)) 
        rate_CO2 = 0;
        set(handles.rate_CO2,'String',num2str(rate_CO2))
        br_freq = 0; 
        set(handles.br_freq,'String',num2str(br_freq))
        TidalVol = 0;
        set(handles.TidalVol,'String',num2str(TidalVol))
    else
        rate_met = str2num(get(handles.rate_met,'String'));
        rate_CO2 = str2num(get(handles.rate_CO2,'String'));        
        br_freq = str2num(get(handles.br_freq,'String'));   
        TidalVol = str2num(get(handles.TidalVol,'String'));
    end
end
set_param('RB_TB/Environment/CO2 balance/rate_respiratory', 'Value', num2str(rate_resp)) % l/min    
set_param('RB_TB/Breathing/rate_metabolic', 'Amplitude', num2str(rate_met/60))
set_param('RB_TB/Breathing/rate_metabolic', 'Bias', num2str(rate_met/60))
set_param('RB_TB/Breathing/rate_metabolic', 'Frequency', num2str(br_freq*pi/30))
set_param('RB_TB/Environment/BL_size/tidal_volume', 'Amplitude', num2str(TidalVol))
set_param('RB_TB/Environment/BL_size/tidal_volume', 'Frequency', num2str(br_freq*pi/30))
if rate_met == 0;
    CO2_factor = 0;
else
    CO2_factor = rate_CO2/rate_met;
end
set_param('RB_TB/Environment/CO2 balance/factor', 'Gain', num2str(CO2_factor))

% ------------------------------------------------------------
function rate_met_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
rate_met = str2num(NewStrVal);     % l/min

if get(handles.rb_standard,'Value') == 1
    if  isempty(rate_met) || isnan(rate_met)
        rate_met = 1; 	
    elseif rate_met < 0
        rate_met = 0;     
    elseif  rate_met > 4
        rate_met = 4; 
    end
    rate_met = round(100*rate_met)/100;
    set(h,'String',rate_met)
    
    CO2_factor = 0.9;
    rate_CO2 = round(10*rate_met*CO2_factor)/10;      % x0.9
    set(handles.rate_CO2,'String',num2str(rate_CO2))
    rate_resp = round(250*rate_CO2)/10;      % x25
    set(handles.rate_resp,'String',num2str(rate_resp))

    if rate_CO2 <= 0.4 
        br_freq = rate_CO2*25;
    elseif rate_CO2 <= 0.9
        br_freq = (15-10)*(rate_CO2-0.4)/(0.9-0.4) + 10;
    elseif rate_CO2 <= 1.6    
        br_freq = (20 - 15)*(rate_CO2-0.9)/(1.6 - 0.9) + 15;
    elseif rate_CO2 <= 2.5
        br_freq = (25 - 20)*(rate_CO2-1.6)/(2.5 - 1.6) + 20;
    elseif rate_CO2 <= 3
        br_freq = 25;            
    else
        br_freq = (30 - 25)*(rate_CO2-3)/(3.6 - 3) + 25;
    end

    br_freq = round(br_freq);
    set(handles.br_freq,'String',num2str(br_freq))

    if rate_met == 0
        TidalVol = 0;
    else
        TidalVol = round(10*rate_resp/br_freq)/10;
    end     
    set(handles.TidalVol,'String',num2str(TidalVol))
else
    if  isempty(rate_met) || isnan(rate_met)
        rate_met = 1; 	
    elseif rate_met < 0
        rate_met = 0;     
    elseif  rate_met > 6
        rate_met = 6; 
    end
    rate_met = round(100*rate_met)/100;
    set(h,'String',rate_met)    
    if rate_met == 0
        rate_resp = 0;     
        set(handles.rate_resp,'String',num2str(rate_resp))        
        rate_CO2 = 0;
        set(handles.rate_CO2,'String',num2str(rate_CO2))
        CO2_factor = 0;
        br_freq = 0; 
        set(handles.br_freq,'String',num2str(br_freq))
        TidalVol = 0;
        set(handles.TidalVol,'String',num2str(TidalVol))

    else
        rate_resp = str2num(get(handles.rate_resp,'String'));   
        br_freq = str2num(get(handles.br_freq,'String'));   
        TidalVol = str2num(get(handles.TidalVol,'String')); 
        CO2_factor = str2num(get(handles.rate_CO2,'String'))/rate_met;
        if CO2_factor > 1
            CO2_factor = 1;
            rate_CO2 = rate_met;
            set(handles.rate_CO2,'String',num2str(rate_CO2))            
        end
    end
end

set_param('RB_TB/Environment/CO2 balance/rate_respiratory', 'Value', num2str(rate_resp)) % l/min    
set_param('RB_TB/Breathing/rate_metabolic', 'Amplitude', num2str(rate_met/60))
set_param('RB_TB/Breathing/rate_metabolic', 'Bias', num2str(rate_met/60))
set_param('RB_TB/Breathing/rate_metabolic', 'Frequency', num2str(br_freq*pi/30)) %
set_param('RB_TB/Environment/BL_size/tidal_volume', 'Amplitude', num2str(TidalVol))
set_param('RB_TB/Environment/BL_size/tidal_volume', 'Frequency', num2str(br_freq*pi/30))
set_param('RB_TB/Environment/CO2 balance/factor', 'Gain', num2str(CO2_factor))

% ------------------------------------------------------------
function rate_CO2_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
rate_CO2 = str2num(NewStrVal);     % l/min

if  isempty(rate_CO2) || isnan(rate_CO2)
	rate_CO2 = 0.9; 	
elseif rate_CO2 < 0
    rate_CO2 = 0;     
elseif  rate_CO2 > 3.6
    rate_CO2 = 3.6; 
end

rate_CO2 = round(10*rate_CO2)/10;
set(h,'String',rate_CO2)

if get(handles.rb_standard,'Value') == 1
    rate_met = round(rate_CO2/0.009)/100;      % /0.9
    set(handles.rate_met,'String',rate_met)
    
    rate_resp = round(250*rate_CO2)/10;      % x25
    set(handles.rate_resp,'String',num2str(rate_resp))

    if rate_CO2 <= 0.4 
        br_freq = rate_CO2*25;
    elseif rate_CO2 <= 0.9
        br_freq = (15-10)*(rate_CO2-0.4)/(0.9-0.4) + 10;
    elseif rate_CO2 <= 1.6    
        br_freq = (20 - 15)*(rate_CO2-0.9)/(1.6 - 0.9) + 15;
    elseif rate_CO2 <= 2.5
        br_freq = (25 - 20)*(rate_CO2-1.6)/(2.5 - 1.6) + 20;
    elseif rate_CO2 <= 3
        br_freq = 25;            
    else
        br_freq = (30 - 25)*(rate_CO2-3)/(3.6 - 3) + 25;
    end

    br_freq = round(br_freq);
    set(handles.br_freq,'String',num2str(br_freq))

    if rate_CO2 == 0
        TidalVol = 0;
    else
        TidalVol = round(10*rate_resp/br_freq)/10;
    end       
    set(handles.TidalVol,'String',num2str(TidalVol))
else
    if rate_CO2 == 0
        rate_resp = 0;     
        set(handles.rate_resp,'String',num2str(rate_resp))        
        rate_met = 0;
        set(handles.rate_met,'String',num2str(rate_met))
        br_freq = 0; 
        set(handles.br_freq,'String',num2str(br_freq))
        TidalVol = 0;
        set(handles.TidalVol,'String',num2str(TidalVol))
    else
        rate_resp = str2num(get(handles.rate_resp,'String'));
        rate_met = str2num(get(handles.rate_met,'String'));        
        br_freq = str2num(get(handles.br_freq,'String'));   
        TidalVol = str2num(get(handles.TidalVol,'String'));  
    end
end

set_param('RB_TB/Environment/CO2 balance/rate_respiratory', 'Value', num2str(rate_resp)) % l/min    
set_param('RB_TB/Breathing/rate_metabolic', 'Amplitude', num2str(rate_met/60))
set_param('RB_TB/Breathing/rate_metabolic', 'Bias', num2str(rate_met/60))
set_param('RB_TB/Breathing/rate_metabolic', 'Frequency', num2str(br_freq*pi/30)) %
set_param('RB_TB/Environment/BL_size/tidal_volume', 'Amplitude', num2str(TidalVol))
set_param('RB_TB/Environment/BL_size/tidal_volume', 'Frequency', num2str(br_freq*pi/30))
if rate_met == 0;
    CO2_factor = 0;
else
    CO2_factor = rate_CO2/rate_met;
end
set_param('RB_TB/Environment/CO2 balance/factor', 'Gain', num2str(CO2_factor))

% ------------------------------------------------------------
function br_freq_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
br_freq = str2num(NewStrVal);     % l/min

if  isempty(br_freq) || isnan(br_freq)
	br_freq = 15; 	
elseif br_freq < 0
    br_freq = 0;     
elseif  br_freq > 30
    br_freq = 30; 
end

br_freq = round(br_freq);
set(h,'String',br_freq)

if get(handles.rb_standard,'Value') == 1
    if br_freq <= 10 
        rate_CO2 = br_freq/25;
    elseif br_freq <= 15
        rate_CO2 = (0.9 - 0.4)*(br_freq - 10)/(15 - 10) + 0.4;
    elseif br_freq <= 20    
        rate_CO2 = (1.6 - 0.9)*(br_freq - 15)/(20 - 15) + 0.9;
    elseif br_freq <= 25
        rate_CO2 = (2.5 - 1.6)*(br_freq - 20)/(25 - 20) + 1.6;
    else
        rate_CO2 = (3.6 - 2.5)*(br_freq - 25)/(30 - 25) + 2.5;
    end
    rate_CO2 = round(10*rate_CO2)/10; 
    set(handles.rate_CO2,'String',num2str(rate_CO2))
    
    rate_met = round(rate_CO2/0.009)/100;      % /0.9
    set(handles.rate_met,'String',rate_met)
    
    rate_resp = round(250*rate_CO2)/10;      % x25
    set(handles.rate_resp,'String',num2str(rate_resp))

    if rate_CO2 == 0
        TidalVol = 0;
    else
        TidalVol = round(10*rate_resp/br_freq)/10;
    end       
    set(handles.TidalVol,'String',num2str(TidalVol))
else
    if br_freq == 0
        rate_resp = 0; 
        set(handles.rate_resp,'String',num2str(rate_resp))        
        rate_met = 0;
        set(handles.rate_met,'String',num2str(rate_met))
        rate_CO2 = 0; 
        set(handles.rate_CO2,'String',num2str(rate_CO2))
        TidalVol = 0;
        set(handles.TidalVol,'String',num2str(TidalVol))
    else
        rate_resp = str2num(get(handles.rate_resp,'String'));   
        rate_met = str2num(get(handles.rate_met,'String'));
        rate_CO2 = str2num(get(handles.rate_CO2,'String'));        
        TidalVol = str2num(get(handles.TidalVol,'String'));  
    end
end

set_param('RB_TB/Environment/CO2 balance/rate_respiratory', 'Value', num2str(rate_resp)) % l/min    
set_param('RB_TB/Breathing/rate_metabolic', 'Amplitude', num2str(rate_met/60))
set_param('RB_TB/Breathing/rate_metabolic', 'Bias', num2str(rate_met/60))
set_param('RB_TB/Breathing/rate_metabolic', 'Frequency', num2str(br_freq*pi/30)) %
set_param('RB_TB/Environment/BL_size/tidal_volume', 'Amplitude', num2str(TidalVol))
set_param('RB_TB/Environment/BL_size/tidal_volume', 'Frequency', num2str(br_freq*pi/30))
if rate_met == 0;
    CO2_factor = 0;
else
    CO2_factor = rate_CO2/rate_met;
end
set_param('RB_TB/Environment/CO2 balance/factor', 'Gain', num2str(CO2_factor))

% ------------------------------------------------------------
function TidalVol_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
TidalVol = str2num(NewStrVal);     % l/min

if  isempty(TidalVol) || isnan(TidalVol)
	TidalVol = 1; 	
elseif TidalVol < 0
    TidalVol = 0;     
elseif  TidalVol > 3
    TidalVol = 3; 
end

TidalVol = round(10*TidalVol)/10;
set(h,'String',TidalVol)

if get(handles.rb_standard,'Value') == 1
    
    br_freq = TidalVol*10;
    set(handles.br_freq,'String',num2str(br_freq))
    
    rate_resp = br_freq*TidalVol;
    set(handles.rate_resp,'String',num2str(rate_resp))  
    
    rate_CO2 = round(rate_resp/2.5)/10;      % /25
    set(handles.rate_CO2,'String',rate_CO2)    

    rate_met = round(rate_CO2/0.009)/100;      % /0.9
    set(handles.rate_met,'String',rate_met)
else
    if TidalVol == 0
        rate_resp = 0; 
        set(handles.rate_resp,'String',num2str(rate_resp))        
        rate_met = 0;
        set(handles.rate_met,'String',num2str(rate_met))
        rate_CO2 = 0; 
        set(handles.rate_CO2,'String',num2str(rate_CO2))
        br_freq = 0;
        set(handles.br_freq,'String',num2str(br_freq))
    else
        rate_resp = str2num(get(handles.rate_resp,'String'));   
        rate_met = str2num(get(handles.rate_met,'String'));
        rate_CO2 = str2num(get(handles.rate_CO2,'String'));
        br_freq = str2num(get(handles.br_freq,'String'));   % (min-1)       
    end
end

set_param('RB_TB/Environment/CO2 balance/rate_respiratory', 'Value', num2str(rate_resp)) % l/min    
set_param('RB_TB/Breathing/rate_metabolic', 'Amplitude', num2str(rate_met/60))
set_param('RB_TB/Breathing/rate_metabolic', 'Bias', num2str(rate_met/60))
set_param('RB_TB/Breathing/rate_metabolic', 'Frequency', num2str(br_freq*pi/30)) %
set_param('RB_TB/Environment/BL_size/tidal_volume', 'Amplitude', num2str(TidalVol))
set_param('RB_TB/Environment/BL_size/tidal_volume', 'Frequency', num2str(br_freq*pi/30))
if rate_met == 0;
    CO2_factor = 0;
else
    CO2_factor = rate_CO2/rate_met;
end
set_param('RB_TB/Environment/CO2 balance/factor', 'Gain', num2str(CO2_factor))

% ------------------------------------------------------------
function rb_standard_Callback(hObject, eventdata, handles)

% ------------------------------------------------------------
function VolBLDead_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal)
    NewVal = 8; 	
elseif NewVal < 2
    NewVal = 2;     
elseif  NewVal > 20
    NewVal = 20; 
end

NewVal = round(10*NewVal)/10;
set(h,'String',NewVal)
set_param('RB_TB/Environment/BL_size/vol_dead', 'Value', num2str(NewVal))
set_param('RB_TB/Environment/BL_size/min_BL_size','Threshold',num2str(NewVal))

vol_Cntrlng = get(handles.VolCntrlng,'String');
max_BL_size = NewVal+str2num(vol_Cntrlng);
set_param('RB_TB/Environment/BL_size/max_BL_size','Threshold',num2str(max_BL_size))

% ------------------------------------------------------------
function VolCntrlng_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);     % l/min

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 6; 	
elseif NewVal < 3
    NewVal = 3;     
elseif  NewVal > 15
    NewVal = 15; 
end

NewVal = round(10*NewVal)/10;
set(h,'String',NewVal)
set_param('RB_TB/Environment/BL_size/vol_cntrlng', 'Value', num2str(NewVal))   

vol_BL_Dead = get(handles.VolBLDead,'String');
max_BL_size = str2num(vol_BL_Dead)+NewVal;
set_param('RB_TB/Environment/BL_size/max_BL_size','Threshold',num2str(max_BL_size))

% ------------------------------------------------------------
function GasMixPopupmenu_Callback(h, eventdata, handles)

NewVal = get(h,'Value');
set_param('RB_TB/Environment/Diluent injection/gas_mix_num', 'Value', num2str(NewVal))

% ------------------------------------------------------------
% Callback of GUI and model message panels
% ------------------------------------------------------------
function txtPanel1_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function txtPanel2_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function ModelTxtPanel_Callback(h, eventdata, handles)


% ------------------------------------------------------------
% Callback of not connected object
% ------------------------------------------------------------
function LeftButton_Callback(h, eventdata, handles)
do_left_button(handles)

% ------------------------------------------------------------
function RightButton_Callback(h, eventdata, handles)
do_right_button(handles)

% ------------------------------------------------------------
% Callback of Device Fault Simulation panel
% ------------------------------------------------------------
function DeviceFaultpopupmenu_Callback(h, eventdata, handles)
global param

NewCell = get(h, 'String'); 
NewNum = get(h, 'Value');
NewStruct = cell2struct(NewCell,'fields',33);
fault_name = NewStruct(NewNum,1).fields;

do_fault(fault_name, param, handles)

% ------------------------------------------------------------
% Callback of control
% ------------------------------------------------------------
function O2control_Callback(h, eventdata, handles)
O2controlMode(handles)

% ------------------------------------------------------------
function CO2control_Callback(h, eventdata, handles)
global param
disp('Note: CO2 control is not connected');
set(handles.ModelTxtPanel,'String', ['>> CO2 control is not connected']);
wavplay(param.DING_sound.y,param.DING_sound.Fs)

% ------------------------------------------------------------
% Callback of BAT and SCRB panels
% ------------------------------------------------------------
function capacity_bat_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(100*str2num(NewStrVal))/100; 

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 2200;     % default, (mAh)
elseif NewVal< 500
    NewVal = 500;     
elseif  NewVal > 6000
    NewVal = 6000; 
end

set(h,'String',NewVal)    
set_param('RB_TB/Controller/capacity_bat', 'Value', num2str(NewVal*3600)) % (mA)*(second)
 
% ------------------------------------------------------------
function discharge_bat_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 30;     % default, (mA)
elseif NewVal< 5
    NewVal = 5;     
elseif  NewVal > 100
    NewVal = 100; 
end

set(h,'String',NewVal)    
set_param('RB_TB/Environment/discharge_bat', 'Value', num2str(NewVal)) % mA 


% ------------------------------------------------------------
function lifetime_scrb_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(10*str2num(NewStrVal))/10; 

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 4.5;     % default, (hour)
elseif NewVal< 1
    NewVal = 1;     
elseif  NewVal > 99
    NewVal = 99; 
end

set(h,'String',NewVal)    
set_param('RB_TB/Environment/CO2 balance/SCRB_LT', 'Value', num2str(NewVal))

% ------------------------------------------------------------
% Callback of reduction valve panels
% ------------------------------------------------------------
function O2NotCompValve_Callback(h, eventdata, handles)
NewVal = get(h,'Value');
set_param('RB_TB/Environment/Breathing gas mixture injection/valve_mode', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function IMprO2valve_Callback(h, eventdata, handles) 

NewStrVal = get(h,'String');
NewVal = round(10*str2num(NewStrVal))/10; 

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 10;     % default, (litre)
elseif NewVal< 5
    NewVal = 5;     
elseif  NewVal > 50
    NewVal = 50; 
end

set(h,'String',NewVal)    

set_param('RB_TB/Environment/Breathing gas mixture injection/pr_IM_O2_valve', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function orifice_size_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal)
	NewVal = 400;     % default, (um)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 1000
    NewVal = 1000; 
end

% O2 flow through the orific must not be less than the metabolic rate
rate_metabolic = str2num(get(handles.rate_met,'String'));  % l/min
pr_intermediate_sea_level = str2num(get(handles.IMprO2valve,'String'));  % bar

orifice_metabolic = round(1000*sqrt(rate_metabolic/(pr_intermediate_sea_level*8.65))); % um

if NewVal < orifice_metabolic
    NewVal = orifice_metabolic;
    disp('Note: Orifice is increased to provide the sonic flow as the metabolic rate');
    set(handles.ModelTxtPanel,'String', ['>> Orifice is increased to provide the sonic flow as the metabolic rate']);    
end

set(h,'String',NewVal)    

set_param('RB_TB/Environment/Breathing gas mixture injection/diam_orifice', 'Value', num2str(NewVal))


% ------------------------------------------------------------
% Callback of profile objects
% ------------------------------------------------------------
function DepthInputProfile_Callback(h, eventdata, handles)
global param

NewVal = get(h,'Value');
if NewVal
    param.profile.time = param.profile.time + param.t_Initial;
end

% ------------------------------------------------------------
function DepthInputManual_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function DepthInputDeco_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function presize_deco_Callback(h, eventdata, handles)
NewVal = get(h,'Value');
set_param('RB_TB/Controller/deco_mode', 'Value', num2str(NewVal+1))   

% ------------------------------------------------------------
function CNC_control_Callback(h, eventdata, handles)
NewVal = get(h,'Value');
set_param('RB_TB/Controller/CNS/CNS_mode', 'Value', num2str(NewVal))   


% ------------------------------------------------------------
% Callback of Depth/Rate input for the manual mode
% ------------------------------------------------------------
function In_depth_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function In_rate_Callback(h, eventdata, handles)

% ------------------------------------------------------------
% Callback of sim mode panel
% ------------------------------------------------------------
function SimModeRT_Callback(h, eventdata, handles)
global sim_state param pause_knob_state

if strcmp(sim_state,'run') 
    sim_state = 'pause';    
    pause_knob_state = 'pressed';       
    set(handles.RunButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
    set(handles.ResetButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
    wavplay(param.DING_sound.y,param.DING_sound.Fs)     
end

% ------------------------------------------------------------
function SimModeAc_Callback(h, eventdata, handles)
global sim_state param pause_knob_state
 
if strcmp(sim_state,'run') 
    % stop RT mode
    rt_timer = timerfind;  
    if strcmp(get(rt_timer, 'Running'),'on') 
        stop(rt_timer);  
    end
    sim_state = 'pause';        
    pause_knob_state = 'pressed';     
    set(handles.RunButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
    set(handles.ResetButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
    wavplay(param.DING_sound.y,param.DING_sound.Fs)     
end 

% ------------------------------------------------------------
% Callback of RUN, PAUSE, STOP buttons
% ------------------------------------------------------------
function RunButton_Callback(h, eventdata, handles)
global param GUIparams sim_state alarm pause_knob_state

set_param('RB_TB/stop_sim', 'Value', '0') 
if ~strcmp(sim_state,'pause')
    if param.predive_num == 7
        param.predive_num = 0;
        set(handles.txtPanel1,'String', ['                        '])
        set(handles.txtPanel2,'String', ['                        '])
    else
        if isempty(findstr(alarm.message_up,'Diving without checks!!!'))
            alarm.message_up   = [alarm.message_up   'Diving without checks!!!'];
            alarm.message_down = [alarm.message_down '                        '];
            set(handles.txtPanel1,'String', ['Diving without checks!!!']);
            set(handles.txtPanel2,'String', ['                        ']);
        end
    end
end


param.scroll_cnt_opt = 0;

set(handles.RunButton, 'BackgroundColor', [0.9608 0.9569 0.9529])
set(handles.PauseButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
pause_knob_state = 'free';    
set(handles.ResetButton, 'BackgroundColor', [0.835294 0.815686 0.784314])

GUIparams = handles;   

if strcmp(sim_state,'reset')    
    param.t_Initial = 0;
end

sim_state = 'run'; 

if get(handles.SimModeRT,'Value') == 1   
    % RT sim mode
    rt_timer = timerfind;
    rt_timer.TasksToExecute = 36000;  % Specifies max possible number of clocks  
    
    if strcmp(get(rt_timer, 'Running'),'off')
        start(rt_timer)    % start timer
    end
else  
    % accelerated sim mode            
    while strcmp(sim_state,'run') 
        do_mode         
    end 
end       


% ------------------------------------------------------------
function PauseButton_Callback(h, eventdata, handles)
global sim_state pause_knob_state

set(handles.RunButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
set(handles.ResetButton, 'BackgroundColor', [0.835294 0.815686 0.784314])

rt_timer = timerfind;  
if strcmp(get(rt_timer, 'Running'),'on') 
    stop(rt_timer);   
end

if ~strcmp(sim_state, 'reset')
    sim_state = 'pause';        
    pause_knob_state = 'pressed';    
end

% ------------------------------------------------------------
function ResetButton_Callback(h, eventdata, handles)
global sim_state param alarm

set(handles.RunButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
set(handles.PauseButton, 'BackgroundColor', [0.835294 0.815686 0.784314])
set(handles.ResetButton, 'BackgroundColor', [0.9608 0.9569 0.9529])

set_param('RB_TB/stop_sim', 'Value', '1') 

sim_state = 'reset'; 

rt_timer = timerfind;
if strcmp(get(rt_timer, 'Running'),'on')
    stop(rt_timer);      
end

set(handles.ModelTxtPanel,'String', ['>> RESET']);
param.scroll_cnt_opt = 0;
set(handles.txtPanel1,'String', ['  Open Revolution eCCR  ']);
set(handles.txtPanel2,'String', ['       Self Test ->']);

% define ini of DCS_risk
param.DCS = 0;

param.date_mode = 'off';    % date mode of the selftest 

% Reset HANDSET
clock = 0; % bold symbols
disp_val(0, 0, 959, 'T.T.S', 3, 3,handles, clock);                % T.T.S, h:mm:ss
disp_val(0, 0, 95959, 'CEILING TIME', 5, 8, handles, clock);      % CEILING TIME, h:mm:ss 
disp_val(0, 0, 600, 'CEILING', 3, 11, handles, clock);            % CEILING,  m/ft
disp_val(0, 0, 600, 'DEPTH', 3, 14, handles, clock);              % DEPTH, m/f
disp_val(0, 0, 95959, 'DIVE TIME', 5, 19, handles, clock);        % DIVE TIME, h:mm:ss
disp_val(0, 0, 100, 'CNS', 2, 21, handles, clock);                 % CNS, %
disp_val(0, -100, 100, 'ASC RATE', 2, 23, handles, clock);          % ASC RATE,  m/min   ft/min
disp_val(0, 0, 100, 'O2', 2, 25, handles, clock);                  % O2, %
disp_val(0, 0, 100, 'He', 2, 27, handles, clock);                  % He, %
disp_val(0, 0, 100, 'N2', 2, 29, handles, clock);                  % N2, %
disp_val(0, 0, 100, 'SCRB', 2, 31, handles, clock);             % SCRB, %
disp_val(0, 0, 100, 'BAT', 2, 33, handles, clock);              % BAT, %
disp_val(0, 0, 100, 'HUM', 2, 35, handles, clock);                % HUM, %
disp_val(0, 0, 45, 'TEMP', 2, 37, handles, clock);               % TEMP, C/F
disp_val(0, 0, 159, '123PPO2', 3, 40, handles, clock);            % 123PPO2, ATA
disp_val(0, 0, 3, 'PPCO2', 2, 42, handles, clock);                % PPCO2, ATA
disp_val(0, 0, 999, 'EqND', 3, 45, handles, clock);               % EqND, m/ft
disp_val(0, 0, 1200, 'DIL CILINDER', 4, 49, handles, clock);       % DIL CILINDER, BPASRI 
disp_val(0, 0, 1200, 'O2 CILINDER', 4, 53, handles, clock);        % O2 CILINDER, BPASRI   

set(handles.RateAscSlider, 'Value', 0)

set(handles.LED_O2, 'BackgroundColor', [1 1 1]) % GUI PPO2 LCD
set(handles.LED_CO2, 'BackgroundColor', [1 1 1 ]) % GUI PPCO2 LCD
param.date_mode  = 'off';
param.predive = 'off';

param.t_Initial = 0;

% reset depth
set(handles.Depth,'String','0')

% reset ALARMS
alarm.message_up = ''; 
alarm.message_down = '';     
alarm.NoReturn = 0;    

load(['../Profiles/' param.profile_name '.mat'], 'profile'); 
param.profile = profile;

% ------------------------------------------------------------
function varargout = HelpButton_Callback(h, eventdata, handles)
HelpPath = which('RB_TB_help.html');
web(HelpPath); 

 
% ------------------------------------------------------------
% Callback of "pause" panel
% ------------------------------------------------------------
function pause_depth_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function pause_depth_edit_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(10*str2num(NewStrVal))/10; 

GUI_Depth_Slider_Max = get(handles.DepthSlider, 'Max');
if  isempty(NewVal) || isnan(NewVal) 
	NewVal = 0;     % default, (m)
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > GUI_Depth_Slider_Max
    NewVal = GUI_Depth_Slider_Max; 
end

set(h,'String',NewVal)    

% ------------------------------------------------------------
function pause_time_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function pause_time_edit_h_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal) 
	NewVal = 0;    
elseif NewVal< 0
    NewVal = 0;     
elseif  NewVal > 9
    NewVal = 9;
end

set(h,'String',NewVal)

% ------------------------------------------------------------
function pause_time_edit_mm_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal) 
    set(h,'String','00')
elseif NewVal< 0
    set(h,'String','00')
elseif  NewVal > 59
    set(h,'String','59')
elseif  ~(NewVal < 0) && ~(NewVal > 9)
    set(h,'String',['0' num2str(NewVal)])
else
    set(h,'String', NewVal)    
end

% ------------------------------------------------------------
function pause_time_edit_ss_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal) 
    set(h,'String','00')
elseif NewVal< 0
    set(h,'String','00')
elseif  NewVal > 59
    set(h,'String','59')
elseif  ~(NewVal < 0) && ~(NewVal > 9)
    set(h,'String',['0' num2str(NewVal)])
else
    set(h,'String', NewVal)    
end

% ------------------------------------------------------------
function depth_max_edit_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = round(10*str2num(NewStrVal))/10; 

if  isempty(NewVal) || isnan(NewVal) 
	NewVal = 40;    
elseif NewVal< 40
    NewVal = 40;     
elseif  NewVal > 600
    NewVal = 600;
end

set(h,'String',NewVal)
set_param('RB_TB/Sensors/Pressure_ambient Sensor/depth_range', 'Value',num2str(NewVal)) 

depth = str2num(get(handles.Depth, 'String'));

if (depth > NewVal) 
    set(handles.Depth,'String',NewVal)
    set(handles.DepthSlider,'Value',NewVal)    
    set(handles.DepthSlider, 'Max', NewVal);    
else
    set(handles.DepthSlider, 'Max', NewVal); 
end

depth = str2num(get(handles.pause_depth_edit, 'String'));

if (depth > NewVal) 
    set(handles.pause_depth_edit,'String',NewVal)
end

% ------------------------------------------------------------
% Callback of "record" panel
% ------------------------------------------------------------
function record_depth_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.depth = [];
    param.record.depth_time = [];
end

% ------------------------------------------------------------
function record_plot_Callback(h, eventdata, handles)
global param

if get(handles.record_depth,'Value') == 1 && size(param.record.depth,2) > 1;
    figure    
    plot(param.record.depth_time ./60, -param.record.depth, 'r', 'linewidth',2');       
    xlabel('Time, min');
    ylabel('Depth, m');
    title(['Depth against Time']);
    grid on
else
    disp('Note: no accumulated data')
    set(handles.ModelTxtPanel,'String', ['>> no accumulated data']);        
end    

% ------------------------------------------------------------
function record_file_name_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function record_save_Callback(h, eventdata, handles)
global param 

if get(handles.record_depth,'Value') == 1 && size(param.record.depth,2) > 1;
    profile = param.record;
    file_name = get(handles.record_file_name,'String');
    if  isempty(file_name)
        save(['../Profiles/' 'empty_name' '.mat'], 'profile'); 
    else
        save(['../Profiles/' file_name '.mat'], 'profile'); 
    end
else
    disp('Note: no accumulated data')
    set(handles.ModelTxtPanel,'String', ['>> no accumulated data']);
end    


% ------------------------------------------------------------
% Callback of "plotting" panel
% ------------------------------------------------------------
function plot_TTS_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.TTS = [];
    param.record.TTS_time = [];
end

% ------------------------------------------------------------
function plot_push_TTS_Callback(h, eventdata, handles)
global param

if get(handles.plot_TTS,'Value') == 1 && size(param.record.TTS,2) > 1;
    plotting(param.record.TTS_time, param.record.TTS, 'TTS','min')    
else
    disp(['Note: no TTS data'])
    set(handles.ModelTxtPanel,'String', ['>> no TTS data']);        
end    

% ------------------------------------------------------------
function plot_ceil_t_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.ceil_t = [];
    param.record.ceil_t_time = [];
end

% ------------------------------------------------------------
function plot_push_ceil_t_Callback(h, eventdata, handles)
global param

if get(handles.plot_ceil_t,'Value') == 1 && size(param.record.ceil_t,2) > 1;
    plotting(param.record.ceil_t_time, param.record.ceil_t, 'Ceilling time', 's')
else
    disp(['Note: no ceilling time data'])
    set(handles.ModelTxtPanel,'String', ['>> no ceilling time data']);        
end    

% ------------------------------------------------------------
function plot_ceil_d_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.ceil_d = [];
    param.record.ceil_d_time = [];
end

% ------------------------------------------------------------
function plot_push_ceil_d_Callback(h, eventdata, handles)
global param

if get(handles.plot_ceil_d,'Value') == 1 && size(param.record.ceil_d,2) > 1;
    plotting(param.record.ceil_d_time, param.record.ceil_d, 'Ceilling depth', 'm')
else
    disp(['Note: no ceilling depth data'])
    set(handles.ModelTxtPanel,'String', ['>> no ceilling depth data']);        
end    

% ------------------------------------------------------------
function plot_CNS_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.CNS = [];
    param.record.CNS_time = [];
end

% ------------------------------------------------------------
function plot_push_CNS_Callback(h, eventdata, handles)
global param

if get(handles.plot_CNS,'Value') == 1 && size(param.record.CNS,2) > 1;
    plotting(param.record.CNS_time, param.record.CNS, 'CNS', '%')
else
    disp(['Note: no CNS data'])
    set(handles.ModelTxtPanel,'String', ['>> no CNS data']);        
end    
% ------------------------------------------------------------
function plot_FO2_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.cnc_O2 = [];
    param.record.cnc_O2_time = [];
end

% ------------------------------------------------------------
function plot_push_FO2_Callback(h, eventdata, handles)
global param

if get(handles.plot_FO2,'Value') == 1 && size(param.record.cnc_O2,2) > 1;
    plotting(param.record.cnc_O2_time, param.record.cnc_O2, 'O2 concentration', '%')
else
    disp(['Note: no O2 concentration data'])
    set(handles.ModelTxtPanel,'String', ['>> no O2 concentration data']);        
end    

% ------------------------------------------------------------
function plot_FHe_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.cnc_He = [];
    param.record.cnc_He_time = [];
end

% ------------------------------------------------------------
function plot_push_FHe_Callback(h, eventdata, handles)
global param

if get(handles.plot_FHe,'Value') == 1 && size(param.record.cnc_He,2) > 1;
    plotting(param.record.cnc_He_time, param.record.cnc_He, 'He concentration', '%')
else
    disp(['Note: no He concentration data'])
    set(handles.ModelTxtPanel,'String', ['>> no He concentration data']);        
end    

% ------------------------------------------------------------
function plot_FN2_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.cnc_N2 = [];
    param.record.cnc_N2_time = [];
end

% ------------------------------------------------------------
function plot_push_FN2_Callback(h, eventdata, handles)
global param

if get(handles.plot_FN2,'Value') == 1 && size(param.record.cnc_N2,2) > 1;
    plotting(param.record.cnc_N2_time, param.record.cnc_N2, 'N2 concentration', '%')
else
    disp(['Note: no N2 concentration data'])
    set(handles.ModelTxtPanel,'String', ['>> no N2 concentration data']);        
end    

% ------------------------------------------------------------
function plot_hum_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.hum = [];
    param.record.hum_time = [];
end

% ------------------------------------------------------------
function plot_push_hum_Callback(h, eventdata, handles)
global param

if get(handles.plot_hum,'Value') == 1 && size(param.record.hum,2) > 1;
    plotting(param.record.hum_time, param.record.hum, 'Humidity', '%')
else
    disp(['Note: no humidity data'])
    set(handles.ModelTxtPanel,'String', ['>> no humidity data']);        
end    

% ------------------------------------------------------------
function plot_temp_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.temp = [];
    param.record.temp_time = [];
end

% ------------------------------------------------------------
function plot_push_temp_Callback(h, eventdata, handles)
global param

if get(handles.plot_temp,'Value') == 1 && size(param.record.temp,2) > 1;
    plotting(param.record.temp_time, param.record.temp, 'Temperature', 'deg')
else
    disp(['Note: no temperature data'])
    set(handles.ModelTxtPanel,'String', ['>> no temperature data']);        
end    

% ------------------------------------------------------------
function plot_PPO2_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.PPO2 = [];
    param.record.PPO2_time = [];
end

% ------------------------------------------------------------
function plot_push_PPO2_Callback(h, eventdata, handles)
global param

if get(handles.plot_PPO2,'Value') == 1 && size(param.record.PPO2,2) > 1;
    plotting(param.record.PPO2_time, param.record.PPO2./100, 'PPO2', 'ATA')
    
    if get(handles.record_depth,'Value') == 1 && size(param.record.depth,2) > 1;
        figure1 = figure;%('Color',[1 1 1],'Position',[1 scrsz(4)/2 scrsz(3)/1 scrsz(4)/1.2]);

        %% Create axes1
        axes1 = axes(...
          'Position',[0.1 0.15 0.78 0.75],...
          'YColor','red',...
          'Parent',figure1);
        hold(axes1,'all');

        %% Create axes2  ( 'YGrid','on',... )
        axes2 = axes(...
          'Position',[0.1 0.15 0.78 0.75],...
          'Color','none',...
          'YColor','blue',...  
          'YAxisLocation','right',...
          'Parent',figure1);
        hold(axes2,'all');

        time_PPO2 = param.record.PPO2_time./60; 
        PPO2 = param.record.PPO2/100;
        time_depth = param.record.depth_time./60;     
        depth = -param.record.depth*3.28084;
        plot(time_PPO2,PPO2,'Color', 'r','LineWidth',2,'Parent',axes1);
        plot(time_depth,depth,'Color', 'b','LineWidth',2,'Parent',axes2);
        grid
        xlabel(axes1,'Time, min');
        ylabel(axes1,'PPO2, ATA');
        ylabel(axes2,'Depth, ffw');
        title('PPO2 and Depth against Time') 
    end
else
    disp(['Note: no PPO2 data'])
    set(handles.ModelTxtPanel,'String', ['>> no PPO2 data']);        
end    

% ------------------------------------------------------------
function plot_PPCO2_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.PPCO2 = [];
    param.record.PPCO2_time = [];
end

% ------------------------------------------------------------
function plot_push_PPCO2_Callback(h, eventdata, handles)
global param

if get(handles.plot_PPCO2,'Value') == 1 && size(param.record.PPCO2,2) > 1;
    plotting(param.record.PPCO2_time, param.record.PPCO2./100, 'PPCO2', 'ATA')
else
    disp(['Note: no PPCO2 data'])
    set(handles.ModelTxtPanel,'String', ['>> no PPCO2 data']);        
end    

% ------------------------------------------------------------
function plot_EqN_Callback(h, eventdata, handles)
global param

if get(h,'Value') == 1
    param.record.EqN = [];
    param.record.EqN_time = [];
end

% ------------------------------------------------------------
function plot_push_EqN_Callback(h, eventdata, handles)
global param

if get(handles.plot_EqN,'Value') == 1 && size(param.record.EqN,2) > 1;
    plotting(param.record.EqN_time, param.record.EqN, 'EqN', 'm')
else
    disp(['Note: no EqN data'])
    set(handles.ModelTxtPanel,'String', ['>> no EqN data']);        
end

% ------------------------------------------------------------
function plot_BL_size_Callback(h, eventdata, handles) 
global param

if get(h,'Value') == 1
    param.record.BL_size = [];
    param.record.BL_size_time = [];
end

% ------------------------------------------------------------
function plot_push_BL_size_Callback(h, eventdata, handles)
global param

if get(handles.plot_BL_size,'Value') == 1 && size(param.record.BL_size,2) > 1;
    plotting(param.record.BL_size_time, param.record.BL_size, 'BL size', 'litre')    
else
    disp(['Note: no BL size data'])
    set(handles.ModelTxtPanel,'String', ['>> no BL size data']);        
end  


% ------------------------------------------------------------
% Callback of "cnc: O2 He N2 CO2 res Total" panel
% ------------------------------------------------------------
function cnc_O2_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function cnc_He_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function cnc_N2_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function cnc_CO2_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function cnc_res_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function cnc_total_Callback(h, eventdata, handles)

% ------------------------------------------------------------
function pr_BL_Callback(h, eventdata, handles)


% ------------------------------------------------------------
% Callback of "profiles" panel
% ------------------------------------------------------------
function profile_list_Callback(h, eventdata, handles)
global param
NewCell = get(h, 'String'); 
NewNum = get(h, 'Value');           % line number 
NewStruct = cell2struct(NewCell,'fields',size(NewCell,1));
param.profile_name = NewStruct(NewNum,1).fields;
load(['../Profiles/' param.profile_name '.mat'], 'profile');
param.profile = profile;

% ------------------------------------------------------------
function profile_plot_Callback(h, eventdata, handles)
global param

figure    
plot(param.profile.time ./60, -param.profile.depth, 'r', 'linewidth',2');       
xlabel('Time, min');
ylabel('Depth, m');
title(['Profile of ../Profiles/' strrep(param.profile_name,'_',' ') '.mat']);
grid on


% ------------------------------------------------------------
% Callback of Automatic Diluent Valve (ADV) and Overpressure Valve (OPV)
% ------------------------------------------------------------
function ADV_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal) 
	NewVal = 25;    % default, (mbar)
elseif NewVal< 10
    NewVal = 10;     
elseif  NewVal > 39
    NewVal = 39;
end

set(h,'String',NewVal)
NewVal = NewVal/1000;
set_param('RB_TB/Environment/Diluent injection/Automatic Diluent Valve', 'InputValues', mat2str([-1000 NewVal 0.04 0.3 1000]))


% ------------------------------------------------------------
function OPV_Callback(h, eventdata, handles)

NewStrVal = get(h,'String');
NewVal = round(str2num(NewStrVal)); 

if  isempty(NewVal) || isnan(NewVal) 
	NewVal = 25;    % default, (mbar)
elseif NewVal< 10
    NewVal = 10;     
elseif  NewVal > 39
    NewVal = 39;
end

set(h,'String',NewVal)

NewVal = NewVal/1000;
set_param('RB_TB/Environment/Overpressure/OverPressure Valve', 'InputValues', mat2str([-1000 NewVal 0.04 0.3 1000]))


% ------------------------------------------------------------
% Callback of "LEDs" panel
% ------------------------------------------------------------
function LEDmode_O2_Callback(h, eventdata, handles)

function LEDmode_CO2_Callback(h, eventdata, handles)

function LEDmode_Callback(h, eventdata, handles)
global param
disp('Note: LED mode selector is not connected');
set(handles.ModelTxtPanel,'String', ['>> LED mode selector is not connected']);
wavplay(param.DING_sound.y,param.DING_sound.Fs)

% ------------------------------------------------------------
% Manual injection panel
% ------------------------------------------------------------
function O2_in_Manual_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal) 
	NewVal = 75;        % l/min
elseif NewVal< 6
    NewVal = 6;     
elseif  NewVal > 75
    NewVal = 75;
end

set(h,'String',NewVal)
set_param('RB_TB/Environment/Breathing gas mixture injection/O2_in_flow', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function O2_button_Callback(h, eventdata, handles)
% O2 income of 20% of tidal volume per second
NewVal = get(h,'Value');
set_param('RB_TB/Environment/Breathing gas mixture injection/O2_in_manual', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function Dil_in_Manual_Callback(h, eventdata, handles)
NewStrVal = get(h,'String');
NewVal = str2num(NewStrVal);

if  isempty(NewVal) || isnan(NewVal) 
	NewVal = 75;        % l/min
elseif NewVal< 6
    NewVal = 6;     
elseif  NewVal > 75
    NewVal = 75;
end

set(h,'String',NewVal)
set_param('RB_TB/Environment/Diluent injection/Dil_in_flow', 'Value', num2str(NewVal))

% ------------------------------------------------------------
function Dil_button_Callback(h, eventdata, handles)
% Dil income manual flow is ADV flow max
NewVal = get(h,'Value');
set_param('RB_TB/Environment/Diluent injection/Dil_in_manual', 'Value', num2str(NewVal))


% end of main_RB_TB.m


