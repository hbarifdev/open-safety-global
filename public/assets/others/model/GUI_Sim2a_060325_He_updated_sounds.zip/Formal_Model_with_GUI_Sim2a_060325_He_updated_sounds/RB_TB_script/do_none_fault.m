%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% do_none_fault.m     v2.0 Beta A
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov
% 15 March 2006
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function do_none_fault(handles)

set_param('RB_TB/Environment/O2 bottle injection/fault_Oxygen Cylinder Empty', 'Value', '0')
% Oxygen Cylinder Switched Off  = fault of Oxygen Solenoid Stuck: '3'
% Oxygen First Stage Failure = fault of Oxygen Solenoid Stuck: '3'
set_param('RB_TB/Environment/O2 bottle injection/fault_Oxygen First Stage Over Pressure', 'Value', '0')        
set_param('RB_TB/Environment/O2 bottle injection/valve_mode', 'Value',...
    num2str(get(handles.O2NotCompValve,'Value')))     % restore after Fault: Oxygen First Stage Over Pressure
set_param('RB_TB/Environment/O2 bottle injection/fault_Oxygen House Leaks', 'Value', '0')

% Reset faults: 
%- Oxygen Cylinder Switched Off
%- Oxygen First Stage Failure
%- Oxygen Solenoid Stuck Closed
%- Oxygen Solenoid Stuck Open
%- Oxygen Manual Injector Failure
O2controlMode(handles) 

set_param('RB_TB/Environment/O2 bottle injection/fault_Wrong Gas in Oxygen cylinder', 'Value', '0')        
    
set_param('RB_TB/Environment/Diluent injection/fault_Diluent Cylinder Empty', 'Value', '0')
set_param('RB_TB/Environment/Diluent injection/fault_Diluent Cylinder Switched Off', 'Value', '0')
set_param('RB_TB/Environment/Diluent injection/fault_Diluent First Stage Over Pressure', 'Value', '0')
set_param('RB_TB/Environment/Diluent injection/fault_Diluent House Leaks', 'Value', '0')
set_param('RB_TB/Environment/Diluent injection/fault_Diluent Manual Injector Failure', 'Value', '0')  
set_param('RB_TB/Environment/Diluent injection/fault_Wrong Gas in Diluent Cylinder', 'Value', '0')    
    
set_param('RB_TB/Controller/add_bat_discharge', 'Value', '0')   % reset fault of Battery Low
set_param('RB_TB/Controller/capacity_bat', 'Value',...          % restore battery capacity after fault of Battery Failure
    num2str(str2num(get(handles.capacity_bat,'String'))*3600))  
set_param('RB_TB/Environment/discharge_bat', 'Value',...        % reset fault of Battery Bounce
    get(handles.discharge_bat,'String'))              
set_param('RB_TB/fault_Handset Failure', 'Value', '0')
set_param('RB_TB/Sensors/fault_Loose Connection to Sensor', 'Value', '0')    
set_param('RB_TB/Sensors/fault_Single Cell Failure', 'Value', '0')
set_param('RB_TB/Sensors/fault_Two Cell Failure', 'Value', '0')
set_param('RB_TB/Environment/fault_Condensation On Face', 'Value', '0')
set_param('RB_TB/Environment/CO2 balance/SCRB_LT', 'Value',...  % restore scrubber Life-Time after fault of Scrubber Exhausted
    get(handles.lifetime_scrb,'String'))                        % hour
set_param('RB_TB/Environment/CO2 balance/K_G', 'gain', '0.00185')
set_param('RB_TB/Environment/CO2 balance/fault_Loop Food', 'Value', '0')

% end of do_none_fault