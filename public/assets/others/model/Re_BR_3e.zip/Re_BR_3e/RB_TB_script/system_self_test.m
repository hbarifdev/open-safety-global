%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% system_self_test.m     v3.0c
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov
% 18 December 2006
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Self cTest routine for entire CCR. Calls Sensors and Actuators for their values.
%% Pass self_test the range of cTest numbers to be run, and it runs each of them and
%% reports cResult to text LCD.
%% Use the .h file to group tests sensibly.
%% Rather than have scores of subroutines, each routine is part of a case statement.
%%
%%
%% The routine is split into groups of normal and circuit tests, as otherwise there
%% is not enough memory in one psect to link the code.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function system_self_test(handles)
global param

% Reset HANDSET
clock = 0; % bold symbols
disp_val(0, 0, 959, 'T.T.S', 3, 3,handles, clock);                % T.T.S, h:mm:ss
disp_val(0, 0, 95959, 'CEILING TIME', 5, 8, handles, clock);      % CEILING TIME, h:mm:ss 
disp_val(0, 0, 600, 'CEILING', 3, 11, handles, clock);            % CEILING,  m/ft
disp_val(0, 0, 600, 'DEPTH', 3, 14, handles, clock);              % DEPTH, m/f
disp_val(0, 0, 95959, 'DIVE TIME', 5, 19, handles, clock);        % DIVE TIME, h:mm:ss
disp_val(0, 0, 100, 'CNS', 2, 21, handles, clock);                 % CNS, %
disp_val(0, -100, 100, 'ASC RATE', 2, 23, handles, clock);          % ASC RATE,  m/min   ft/min
disp_val(0, 0, 100, 'O2', 2, 25, handles, clock);                  % O2, %
disp_val(0, 0, 100, 'He', 2, 27, handles, clock);                  % He, %
disp_val(0, 0, 100, 'N2', 2, 29, handles, clock);                  % N2, %
disp_val(0, 0, 100, 'SCRB', 2, 31, handles, clock);             % SCRB, %
disp_val(0, 0, 100, 'BAT', 2, 33, handles, clock);              % BAT, %
disp_val(0, 0, 100, 'HUM', 2, 35, handles, clock);                % HUM, %
disp_val(0, 0, 45, 'TEMP', 2, 37, handles, clock);               % TEMP, C/F
disp_val(0, 0, 159, '123PPO2', 3, 40, handles, clock);            % 123PPO2, ATA
disp_val(0, 0, 3, 'PPCO2', 2, 42, handles, clock);                % PPCO2, ATA
disp_val(0, 0, 999, 'EqND', 3, 45, handles, clock);               % EqND, m/ft
disp_val(0, 0, 1200, 'DIL CILINDER', 4, 49, handles, clock);       % DIL CILINDER, BPASRI 
disp_val(0, 0, 1200, 'O2 CILINDER', 4, 53, handles, clock);        % O2 CILINDER, BPASRI   

set(handles.LED_O2, 'BackgroundColor', [1 1 1]) % GUI PPO2 LCD
set(handles.LED_CO2, 'BackgroundColor', [1 1 1 ]) % GUI PPCO2 LCD
param.date_mode  = 'off';
param.predive = 'off';

set(handles.txtPanel2,'String', ['                                '])   %% Remove anything from line 2 before writing line 1
set(handles.txtPanel1,'String', ['--- System Self Test ---'])   % Inform user starting self test. No abort.
set(handles.txtPanel2,'String', [' Firmware Version 1.1.2 ']) % Write the code version

t = timer('StartDelay', 0.5,'TimerFcn','disp('''')');  % set delay

for ucTest_num = 1:21
    switch(ucTest_num)	      
        case 1  %tst_batteries:  
		%% "Battery Terminal Voltage";
		%% "A=X.XX, B=X.XX, C=X.XX V";
        %battery_1 : return(3201); //mV
        %battery_2 : return(3460); //mV
        %battery_3 : return(3100); //mV
        set(handles.txtPanel1,'String', ['1: Battery Voltages .. '])
        set(handles.txtPanel2,'String', ['A=3.20, B=3.46, C=3.10 V']) 
        start(t)
        wait(t)        
  	 case 2 %tst_power_monitor
		%% "Standby Current         ";
		%% "Active Current          ";
		%% "Brownout Monitors OK    ";
		%% "Watchdogs OK            ";
        set(handles.txtPanel1,'String', ['2: Power Monitor ..... '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Standby Current     4 mA'])
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Active Current     60 mA'])
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Watchdog Events        0'])
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Brownout_Events        0'])
        start(t)
        wait(t)
    case 3  %tst_link
        set(handles.txtPanel1,'String', ['3: Link to/from Handset'])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Comms Link Status:    15'])
        start(t)
        wait(t)    
    case 4  %tst_display
        set(handles.txtPanel1,'String', ['4: Displays all ON     '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['########################'])
        start(t)
        wait(t)    
    case 5  %tst_HUD 
        set(handles.txtPanel1,'String', ['5: Head Up Display ON  '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        set(handles.LED_O2, 'BackgroundColor', [1 0 0]) % GUI PPO2 LCD
        set(handles.LED_CO2, 'BackgroundColor', [1 0 0]) % GUI PPCO2 LCD
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['                        '])
        start(t)
        wait(t)    
    case 6  %tst_speaker
        set(handles.txtPanel1,'String', ['6: Speaker Active      '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['                        '])
        %% send a tone or crackle to speaker 
        wavplay(param.DING_sound.y,param.DING_sound.Fs)        
    case 7  %tst_alarms
        set(handles.txtPanel1,'String', ['7: Buzzer Activated    '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['                        '])
        start(t)
        wait(t)    
    case 8  %tst_o2_sensors
	    % Doing:
	    % "o2 Sensor Output Voltage";
	    % "A   , B   , C   , D     ";
	    % "Sensor cal will be later";        
        set(handles.txtPanel1,'String', ['8: O2 Sensor Voltages  '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['A= 8, B=16, C= 8, D= 0mV'])
        start(t)
        wait(t)    
    case 9  %tst_o2_contents
        set(handles.txtPanel1,'String', ['9: O2 Cylinder Pressure'])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['O2 pressure:  ' get(handles.prO2bottle,'String') 'bar'])
        start(t)
        wait(t)    
    case 10  %tst_dil_contents
        set(handles.txtPanel1,'String', ['10: DIL Gas Pressure .. '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        switch(str2num(get(handles.GasMix,'String')))
            case 1
                set(handles.txtPanel2,'String', ['DIL pressure:  ' get(handles.prDILbottle1,'String') 'bar'])
            case 2
                set(handles.txtPanel2,'String', ['DIL pressure:  ' get(handles.prDILbottle2,'String') 'bar'])
            case 3
                set(handles.txtPanel2,'String', ['DIL pressure:  ' get(handles.prDILbottle3,'String') 'bar'])
        end
        start(t)
        wait(t)    
   case 11  %tst_co2_sensor
        set(handles.txtPanel1,'String', ['11: Primary CO2 Sensor  '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['PPCO2 level:      0.000%'])
        start(t)
        wait(t)    
   case 12  %tst_he_sensor
        set(handles.txtPanel1,'String', ['12: Helium Sensor ..... '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Helium content:       0%'])
        start(t)
        wait(t)    
   case 13  %tst_pressure_ambient
        set(handles.txtPanel1,'String', ['13: Pressure sensors .. '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Ambient:  ' get(handles.prAmbient_ini,'String') 'mbar'])
        start(t)
        wait(t)    
   case 14  %tst_moisture
        set(handles.txtPanel1,'String', ['14: Moisture sensors .. '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Moisture level:      10%'])
        start(t)
        wait(t)    
   case 15  %tst_humidity
        set(handles.txtPanel1,'String', ['15: Humidity sensors ... '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Relative Humidity:  ' num2str(100*str2num(get_param('RB_TB/Environment/wet_ini', 'Value'))) '%'])
        start(t)
        wait(t)    
  case 16  %tst_temperature
        set(handles.txtPanel1,'String', ['16: Temp sensors ...    '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Temperature:  ' get_param('RB_TB/Environment/temp_water_handset', 'Value') 'C'])
        start(t)
        wait(t)    
   case 17  %tst_scrubber_inlet
        set(handles.txtPanel1,'String', ['17: Flow sensor A ....  '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Inlet Pressure: 1010mbar'])
        start(t)
        wait(t)    
   case 18  %tst_scrubber_outlet
        set(handles.txtPanel1,'String', ['18: Flow sensor B ....  '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Outlet Pressure:1010mbar'])
        start(t)
        wait(t)    
   case 19  %tst_scrubber_outlet
        set(handles.txtPanel1,'String', ['19: Scrubber sensors .. '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Scrubber A:         100%'])
        start(t)
        wait(t)    
        set(handles.txtPanel2,'String', ['Scrubber B:         100%'])
        start(t)
        wait(t)    
   case 20  %tst_aso
        set(handles.txtPanel1,'String', ['20: Auto Shutoff Valve  '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Auto Shutoff Valve .. OK'])
        start(t)
        wait(t)    
   case 21  %tst_wet_contacts
        set(handles.txtPanel1,'String', ['21: Wet contacts .....  '])
        set(handles.txtPanel2,'String', ['                        '])   %% Remove anything from line 2 before writing line 1
        start(t)
        wait(t)
        set(handles.txtPanel2,'String', ['Wet Contact Status:   10'])
        start(t)
        wait(t)    
          
        set(handles.txtPanel1,'String', ['System is functioning OK'])
        set(handles.txtPanel2,'String', ['Now do the predive check'])
        start(t)
        wait(t)    
        start(t)
        wait(t)   
        set(handles.txtPanel1,'String', ['  Open Revolution eCCR  ']);
        set(handles.txtPanel2,'String', ['<- Predive    Options ->']); 
        param.scroll_cnt_opt = 2;
    end
end 
delete(t) % delate the DELAY timer