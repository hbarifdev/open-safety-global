%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% do_fault.m     v3.1d
% Matlab v7.0 (R14) SP 1
% Alex Deas, Bob Davidov
% 23 October 2006
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

function do_fault(fault_name, param, handles)

switch fault_name
    case('None') 
        do_none_fault(handles)
    case('Oxygen Cylinder Empty')
        set_param('RB_TB/Environment/O2 bottle injection/fault_Oxygen Cylinder Empty', 'Value', '1')
    case('Oxygen Cylinder Switched Off')
        set_param('RB_TB/Controller/O2_control_select', 'Value', '4')
    case('Oxygen First Stage Failure') % total instantaneous loss of all O2
        set_param('RB_TB/Controller/O2_control_select', 'Value', '4')
    case('Oxygen First Stage Over Pressure') 
        % With an O2 solenoid injector, this sets the solenoid ON permanently.
        % With an orifice injector, it causes the O2 to be injected faster than it should be    
        set_param('RB_TB/Environment/O2 bottle injection/valve_mode', 'Value', '1')  % set not-compensated valve mode
        set_param('RB_TB/Environment/O2 bottle injection/fault_Oxygen First Stage Over Pressure', 'Value', '1')
    case('Oxygen Hose Leaks') % the content of the cylinder goes down fast (empty in 5 minutes)    
        set_param('RB_TB/Environment/O2 bottle injection/fault_Oxygen Hose Leaks', 'Value', '1')
    case('Oxygen Solenoid Stuck Open')
        set_param('RB_TB/Controller/O2_control_select', 'Value', '5')
    case('Oxygen Solenoid Stuck Closed')      
        set_param('RB_TB/Controller/O2_control_select', 'Value', '4')
    case('Oxygen Manual Injector Failure') % it fails shut
        set_param('RB_TB/Controller/O2_control_select', 'Value', '5')
    case('Wrong Gas in Oxygen cylinder') % O2 cylinder becomes DIL
        set_param('RB_TB/Environment/O2 bottle injection/fault_Wrong Gas in Oxygen cylinder', 'Value', '1')
    case('Diluent Cylinder Empty')
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent Cylinder Empty', 'Value', '1')
    case('Diluent Cylinder Switched Off')
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent Cylinder Switched Off', 'Value', '1')
    case('Diluent First Stage Failure') % total instantaneous loss of all DIL
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent Cylinder Switched Off', 'Value', '1')
    case('Diluent First Stage Over Pressure') % leaks dil into the loop
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent First Stage Over Pressure', 'Value', '1')
    case('Diluent Hose Leaks') % the content of the cylinder goes down fast (empty in 5 minutes)
        set_param('RB_TB/Environment/Diluent injection/Leak', 'Value', '2.5')        
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent Hose Leaks', 'Value', '1')
    case('Diluent Manual Injector Failure') % it fails shut
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent Manual Injector Failure', 'Value', '1')
    case('Wrong Gas in Diluent Cylinder') % DIL becomes air
        set_param('RB_TB/Environment/Diluent injection/fault_Wrong Gas in Diluent Cylinder', 'Value', '1')
    case('Alternate Air Source Free Flow') % Loss of dil in 2 minutes
        set_param('RB_TB/Environment/Diluent injection/Leak', 'Value', '6.25')    
        set_param('RB_TB/Environment/Diluent injection/fault_Diluent Hose Leaks', 'Value', '1')
    case('Battery Low') % the time left while the electronics works is cut to 5 minutes
        NewVal = str2num(get(handles.capacity_bat,'String'))*3600 - param.discharge_bat - 300*str2num(get(handles.discharge_bat,'String'));
        set_param('RB_TB/Controller/add_bat_discharge', 'Value', num2str(NewVal))
    case('Battery Failure') % Total failure
        set_param('RB_TB/Controller/capacity_bat', 'Value', '1') % it must be > 0
    case('Battery Bounce') % Causes the electronics to reset and restart
        set_param('RB_TB/Environment/discharge_bat', 'Value', '5000') % mA,  Av. batttery discharge (electronic supply current is from 10 to 60 mA av. 10 secs   
    case('Handset Failure') % Cable is cut to the handset. All information in the handset is lost
        set_param('RB_TB/fault_Handset Failure', 'Value', '1')
    case('Handsets Switched off') % Cannot happen underwater. it just closes down the run.
        set_param('RB_TB/fault_Handset Failure', 'Value', '1')    
    case('O2 Sensor loose connector') % one O2 sensor has zero output
        set_param('RB_TB/Sensors/PPO2_1_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_1', 'Value', '0')        
    case('O2 Single Cell 5mV fixed') % one O2 sensor is 5mV output        
        set_param('RB_TB/Sensors/PPO2_2_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_2', 'Value', '2984')        
    case('O2 Two Cells 5mV Fixed') % two O2 sensor is 5mV output
        set_param('RB_TB/Sensors/PPO2_2_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_2', 'Value', '2984')
        set_param('RB_TB/Sensors/PPO2_3_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_3', 'Value', '2984')
    case('O2 Three Cells 5mV Fixed') % three O2 sensor is 5mV output
        set_param('RB_TB/Sensors/PPO2_2_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_2', 'Value', '2984')
        set_param('RB_TB/Sensors/PPO2_3_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_3', 'Value', '2984')
        set_param('RB_TB/Sensors/PPO2_4_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_4', 'Value', '2984')
    case('O2 All Cells 5mV Fixed') % four O2 sensor is 5mV output
        set_param('RB_TB/Sensors/PPO2_2_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_2', 'Value', '2984')
        set_param('RB_TB/Sensors/PPO2_3_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_3', 'Value', '2984')
        set_param('RB_TB/Sensors/PPO2_4_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_4', 'Value', '2984')
        set_param('RB_TB/Sensors/PPO2_1_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_1', 'Value', '2984')
    case('O2 Single Cell slow 30s') % time constant is 30s
        set_param('RB_TB/Sensors/PPO2 sensor4/TS_PPO2_REC', 'gain', '1/30')
    case('O2 Two Cells slow 30s,5m') % time constants are 30s and 5 min
        set_param('RB_TB/Sensors/PPO2 sensor4/TS_PPO2_REC', 'gain', '1/30')
        set_param('RB_TB/Sensors/PPO2 sensor1/TS_PPO2_REC', 'gain', '1/30')
    case('O2 Three Cells slow 30s,30s,5m') % time constants are 30s, 30s and 5 min
        set_param('RB_TB/Sensors/PPO2 sensor4/TS_PPO2_REC', 'gain', '1/30')
        set_param('RB_TB/Sensors/PPO2 sensor1/TS_PPO2_REC', 'gain', '1/30')
        set_param('RB_TB/Sensors/PPO2 sensor2/TS_PPO2_REC', 'gain', '1/300')
    case('O2 All Cells slow 30s,30s,5m,5m') % time constants are 30s, 30s, 5 min and 5 min
        set_param('RB_TB/Sensors/PPO2 sensor4/TS_PPO2_REC', 'gain', '1/30')
        set_param('RB_TB/Sensors/PPO2 sensor1/TS_PPO2_REC', 'gain', '1/30')
        set_param('RB_TB/Sensors/PPO2 sensor2/TS_PPO2_REC', 'gain', '1/300')
        set_param('RB_TB/Sensors/PPO2 sensor3/TS_PPO2_REC', 'gain', '1/300')
    case('O2 Single Cell 20mV limit') % one O2 sensor is 20mV output
        set_param('RB_TB/Sensors/PPO2_4_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_3', 'Value', '11936')
    case('O2 Two Cells 20mV limit') % two O2 sensor is 20mV output
        set_param('RB_TB/Sensors/PPO2_4_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_3', 'Value', '11936')
        set_param('RB_TB/Sensors/PPO2_1_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_4', 'Value', '11936')
    case('O2 Three Cells 20mV limit') % three O2 sensor is 20mV output
        set_param('RB_TB/Sensors/PPO2_4_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_3', 'Value', '11936')
        set_param('RB_TB/Sensors/PPO2_1_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_4', 'Value', '11936')
        set_param('RB_TB/Sensors/PPO2_2_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_1', 'Value', '11936')
    case('O2 All Cells 20mV limit') % four O2 sensor is 20mV output           
        set_param('RB_TB/Sensors/PPO2_4_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_3', 'Value', '11936')
        set_param('RB_TB/Sensors/PPO2_1_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_4', 'Value', '11936')
        set_param('RB_TB/Sensors/PPO2_2_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_1', 'Value', '11936')
        set_param('RB_TB/Sensors/PPO2_3_state', 'Value', '1')
        set_param('RB_TB/Sensors/output_PPO2_2', 'Value', '11936')
    case('Water on an O2 sensor face') % O2 sensors is oscillating fluctuating low with a period of about 1 min
        set_param('RB_TB/Environment/fault_Water on O2 sensor face', 'Value', '1')
    case('Pressure Not Equalised') % Fix the pressure in loop to the ambient then continue dive
        disp('Note: The Fault is not connected');
        set(handles.ModelTxtPanel,'String', ['>> The Fault is not connected']);
        wavplay(param.DING_sound.y,param.DING_sound.Fs)        
    case('Scrubber Exhausted') % PPCO2 climbs at 1% per minute
        set_param('RB_TB/Environment/CO2 balance/SCRB_LT', 'Value', num2str(param.sum_CO2/96))
    case('Scrubber Bypass') % PPCO2 climbs at 4% per minute
        set_param('RB_TB/Environment/CO2 balance/SCRB_LT', 'Value', num2str(param.sum_CO2/96))
        set_param('RB_TB/Environment/CO2 balance/K_G', 'gain', '0.0074')
        set_param('RB_TB/Environment/CO2 balance/Scrubber Bypass_vol_ini', 'Value', num2str(0.4*str2num(get(handles.VolTidal,'String')))) %PPCO2 in this situation should become 0.40       
    case('Loop Food') % PPCO2 becomes 10% (0.1)
        set_param('RB_TB/Environment/CO2 balance/SCRB_LT', 'Value', num2str(param.sum_CO2/96))  % SCRB is OFF
        set_param('RB_TB/Environment/CO2 balance/K_G', 'gain', '0.07')    
        set_param('RB_TB/Environment/CO2 balance/fault_Loop Food', 'Value', '1')
    case('BC Failure') % Diver is sinking (increasing depth)
        disp('Note: The Fault is not connected');
        set(handles.ModelTxtPanel,'String', ['>> The Fault is not connected']);
        wavplay(param.DING_sound.y,param.DING_sound.Fs)        
    case('Harness Failure') % Diver is on surface in 1 minute        
        set(handles.DepthInputManual, 'value', 1)
        max_asc = -round(str2num(get(handles.Depth, 'string'))*10)/10;
        set(handles.In_rate, 'value', 1) 
        set(handles.RateAsc, 'string', num2str(max_asc))        
        if max_asc < str2num(get(handles.m_ft_asc_rate_max, 'string'))
            set(handles.m_ft_asc_rate_max, 'string', num2str(max_asc))            
            set(handles.RateAscSlider, 'Min', max_asc)
            set(handles.RateAscSlider, 'Value', max_asc)
        end
        set(handles.RateAscSlider, 'Value', max_asc)
end


% end of do_fault.m