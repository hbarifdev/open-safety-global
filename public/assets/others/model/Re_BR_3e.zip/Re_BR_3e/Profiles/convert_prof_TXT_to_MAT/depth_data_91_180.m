%-----------------------------------------------------------------------------------------------
%   Design unit : VALVE_CONTROL
%   Filename: depth_data_des_asc.m
%
%   Description: Diving table data for the breathing loop simulink model.
%                Profile of the depth. 
%
%	 Limitations:
%
%   Author: Bob Davidov
%           Deep Life Ltd.
%
%   Simulator: MatLAB 7.01 R14 SP1
%
%   Version 1.1 by 20 October 2005, original release
%----------------------------------------------------------------------------------------------
  
% 
% profile of the depth

function [sys,x0,str,ts]=depth_data_des_asc(t,x,u,flag)
%LIMINTM Limited integrator implementation.
%   M-file S-function implementing a continuous changing of the depth
%   
%   See sfuntmpl.m for a general S-function template.
%   Copyright 1990-2002 The MathWorks, Inc.
%   $Revision: 1.17 $

switch flag

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0         
    [sys,x0,str,ts] = mdlInitializeSizes;

%    disp(['Running depth_data_91_180']);

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1
    sys = mdlDerivatives(t,x,u);

  %%%%%%%%%%%%%%%%%%%%%%%%
  % Update and Terminate %
  %%%%%%%%%%%%%%%%%%%%%%%%
  case {2,9}
    sys = []; % do nothing

  %%%%%%%%%%
  % Output %
  %%%%%%%%%%
  case 3
    sys = mdlOutputs(t,x,u); 

  otherwise
    error(['unhandled flag = ',num2str(flag)]);
end

% end limintm

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts] = mdlInitializeSizes(lb,ub,xi)

sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 0;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);
str = [];
x0  = [];
ts  = [0 0];   % sample time: [period, offset]

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Compute derivatives for continuous states.
%=============================================================================
%
function sys = mdlDerivatives(t,x,u)

sys = [];

% end mdlDerivatives

%
%=============================================================================
% mdlOutputs
% Return the output vector for the S-function
%=============================================================================
%
function sys = mdlOutputs(t,x,u)

data_in = [0	0;     
7	3;
13	4;
20	5;
27	7;
33	8;
40	8.5;
47	8.5;
53	8.5;
60	9.5;    % 10m at 61.75s
67	11.5;
73	17;
80	22.5;
87	27;
93	32;
100	34;
107	34;
113	37;
120	42.5;
127	51;
133	59;
140	63;
147	68;
153	71;
160	74;
167	76.5;
173	78;
180	91;     % the depth is 91m at 180sec. 
210	82;
240	80;
270	75;
300	72.5;
330	70.5;
360	67.7;
390	65.5;
420	64;
450	62.5;
480	60;
510	57;
540	54;
570	51;
600	51;
630	51;
660	51;
690 50.5;
720	49;
750	46.7;
780 44;
810	42.5;
840	40;
870	39;
900	38.5;
930	37;
960	35.5;
990	35.5;
1020	35;
1050	35;
1080	35;
1110	34.5;
1140	32.5;
1170	31;
1200	30;
1230	28;
1260	27.5;
1290	27;
1320	26.5;
1350	26.5;
1380	25.5;
1410	24;
1440	22.5;
1470	22;
1500	22;
1530	22;
1560	19.5;
1590	18;
1620	15.5;
1650	13;
1680	13;
1710	13;
1740	11.5;
1770	9.5;
1800	9.5;
1830	9.5;
1860	9.5;
1890	9.5;
1920	9;
1950	9;
1980	8.5;
2010	8.5;
2040	8;
2070	8;
2100	8;
2130	8;
2160	8;
2190	8;
2220	8;
2250	8;
2280	8;
2310	8;
2340	8;
2370	8;
2400	8;
2430	8;
2460	8;
2490	7.5;
2520	7;
2550	7;
2580	7;
2610	7;
2640	7;
2670	7;
2700	7;
2730	7;
2760	7;
2790	7;
2820	7;
2850	7;
2880	7;
2910	7;
2940	7;
2970	7;
3000	7;
3030	7;
3060	7;
3090	7;
3120	7;
3150	7;
3180	7;
3210	7;
3240	7;
3270	7;
3300	7;
3330	7;
3360	6.5;
3390	6.5;
3420	6.5;
3450	6.5;
3480	6.5;
3510	6.5;
3540	6.5;
3570	6.5;
3600	6.5;
3630	6.5;
3660	6.5;
3690	5.7;
3720	3;
3750	0];

%data_in(:,1)=data_in(:,1)./100;

sys = interp1q(data_in(:,1), data_in(:,2), t);
%t 

% end mdlOutputs